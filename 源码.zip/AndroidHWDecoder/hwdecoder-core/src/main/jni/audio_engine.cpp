#include "audio_engine.h"

#include <SLES/OpenSLES.h>
#include <SLES/OpenSLES_Android.h>
#include <SLES/OpenSLES_AndroidConfiguration.h>

#include <unistd.h>
#include <cmath>
#include <cstring>
#include <vector>

namespace hwd {

int64_t AudioEngine::nowNs() {
    return std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();
}

AudioEngine::AudioEngine() {
    mLimiter.setCeiling(0.92f);
}

AudioEngine::~AudioEngine() {
    destroy();
}

void AudioEngine::destroy() {
    mRunning = false;
    if (mPlayerObj != nullptr) {
        if (mPlay != nullptr) {
            (*mPlay)->SetPlayState(mPlay, SL_PLAYSTATE_STOPPED);
        }
        if (mQueue != nullptr) {
            (*mQueue)->Clear(mQueue);
        }
        (*mPlayerObj)->Destroy(mPlayerObj);
        mPlayerObj = nullptr;
        mPlay = nullptr;
        mQueue = nullptr;
    }
    if (mOutputMixObj != nullptr) {
        (*mOutputMixObj)->Destroy(mOutputMixObj);
        mOutputMixObj = nullptr;
    }
    if (mEngineObj != nullptr) {
        (*mEngineObj)->Destroy(mEngineObj);
        mEngineObj = nullptr;
        mEngine = nullptr;
    }
    for (auto& b : mMixBuffer) {
        delete[] b;
        b = nullptr;
    }
    mConfigured = false;
}

bool AudioEngine::configure(int sampleRate, int channels, int bufferFrames, bool lowLatency) {
    destroy();

    mSampleRate = sampleRate > 0 ? sampleRate : 48000;
    mChannels = channels > 0 && channels <= 8 ? channels : 2;
    mBufFrames = bufferFrames > 0 ? bufferFrames : 960;
    if (mBufFrames < 240) mBufFrames = 240;
    if (mBufFrames > 8192) mBufFrames = 8192;

    mMixScratch.resize(static_cast<size_t>(mBufFrames) * mChannels);
    for (int i = 0; i < 2; i++) {
        mMixBuffer[i] = new int16_t[static_cast<size_t>(mBufFrames) * mChannels];
    }

    // ---- 创建引擎 ----
    if (slCreateEngine(&mEngineObj, 0, nullptr, 0, nullptr, nullptr) != SL_RESULT_SUCCESS) {
        return false;
    }
    if ((*mEngineObj)->Realize(mEngineObj, SL_BOOLEAN_FALSE) != SL_RESULT_SUCCESS) {
        return false;
    }
    if ((*mEngineObj)->GetInterface(mEngineObj, SL_IID_ENGINE, &mEngine) != SL_RESULT_SUCCESS) {
        return false;
    }

    // ---- 输出混音器 ----
    if ((*mEngine)->CreateOutputMix(mEngine, &mOutputMixObj, 0, nullptr, nullptr) != SL_RESULT_SUCCESS) {
        return false;
    }
    if ((*mOutputMixObj)->Realize(mOutputMixObj, SL_BOOLEAN_FALSE) != SL_RESULT_SUCCESS) {
        return false;
    }

    // ---- 数据源：缓冲队列 ----
    SLDataLocator_AndroidSimpleBufferQueue locBufQueue = {
            SL_ANDROID_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE, 2};

    SLuint32 channelMask = 0;
    switch (mChannels) {
        case 1: channelMask = SL_SPEAKER_FRONT_CENTER; break;
        case 2: channelMask = SL_SPEAKER_FRONT_LEFT | SL_SPEAKER_FRONT_RIGHT; break;
        case 3: channelMask = SL_SPEAKER_FRONT_LEFT | SL_SPEAKER_FRONT_RIGHT
                              | SL_SPEAKER_FRONT_CENTER; break;
        case 4: channelMask = SL_SPEAKER_FRONT_LEFT | SL_SPEAKER_FRONT_RIGHT
                              | SL_SPEAKER_BACK_LEFT | SL_SPEAKER_BACK_RIGHT; break;
        case 6: channelMask = SL_SPEAKER_FRONT_LEFT | SL_SPEAKER_FRONT_RIGHT
                              | SL_SPEAKER_FRONT_CENTER | SL_SPEAKER_LOW_FREQUENCY
                              | SL_SPEAKER_SIDE_LEFT | SL_SPEAKER_SIDE_RIGHT; break;
        default: channelMask = SL_SPEAKER_FRONT_LEFT | SL_SPEAKER_FRONT_RIGHT; break;
    }

    SLDataFormat_PCM formatPcm = {
            SL_DATAFORMAT_PCM,
            static_cast<SLuint32>(mChannels),
            static_cast<SLuint32>(mSampleRate * 1000), // milliHz
            SL_PCMSAMPLEFORMAT_FIXED_16,
            16,
            channelMask,
            SL_BYTEORDER_LITTLEENDIAN};

    SLDataSource audioSrc = {&locBufQueue, &formatPcm};

    SLDataLocator_OutputMix locOutMix = {SL_DATALOCATOR_OUTPUTMIX, mOutputMixObj};
    SLDataSink audioSnk = {&locOutMix, nullptr};

    // ---- 创建播放器 ----
    const SLInterfaceID ids[] = {
            SL_IID_ANDROIDSIMPLEBUFFERQUEUE,
            SL_IID_ANDROIDCONFIGURATION,
            SL_IID_VOLUME};
    const SLboolean req[] = {SL_BOOLEAN_TRUE, SL_BOOLEAN_TRUE, SL_BOOLEAN_FALSE};

    if ((*mEngine)->CreateAudioPlayer(mEngine, &mPlayerObj, &audioSrc, &audioSnk,
                                      3, ids, req) != SL_RESULT_SUCCESS) {
        return false;
    }

    // 低延迟配置必须在 Realize 之前
    SLAndroidConfigurationItf configItf = nullptr;
    if ((*mPlayerObj)->GetInterface(mPlayerObj, SL_IID_ANDROIDCONFIGURATION,
                                    &configItf) == SL_RESULT_SUCCESS) {
#if defined(SL_ANDROID_KEY_PERFORMANCE_MODE)
        SLuint32 mode = lowLatency
                ? SL_ANDROID_PERFORMANCE_LOW_LATENCY
                : SL_ANDROID_PERFORMANCE_POWER_SAVING;
        (*configItf)->SetConfiguration(configItf, SL_ANDROID_KEY_PERFORMANCE_MODE,
                                       &mode, sizeof(mode));
#endif
    }

    if ((*mPlayerObj)->Realize(mPlayerObj, SL_BOOLEAN_FALSE) != SL_RESULT_SUCCESS) {
        return false;
    }
    if ((*mPlayerObj)->GetInterface(mPlayerObj, SL_IID_PLAY, &mPlay) != SL_RESULT_SUCCESS) {
        return false;
    }
    if ((*mPlayerObj)->GetInterface(mPlayerObj, SL_IID_ANDROIDSIMPLEBUFFERQUEUE,
                                    &mQueue) != SL_RESULT_SUCCESS) {
        return false;
    }

    // ---- DSP 初始化 ----
    mEqLow.init(mChannels);
    mEqMid.init(mChannels);
    mEqHigh.init(mChannels);
    mEqLow.setLowShelf(mSampleRate, 120.0, 0.707, 0.0);
    mEqMid.setPeaking(mSampleRate, 1000.0, 1.1, 0.0);
    mEqHigh.setHighShelf(mSampleRate, 8000.0, 0.707, 0.0);
    mEqLow.setBypass(true);
    mEqMid.setBypass(true);
    mEqHigh.setBypass(true);
    mLimiter.setCeiling(0.92f);

    // ---- 重采样器与输入保持缓冲（预留 8x 变速余量）----
    mWsola.init(mChannels, 512, 128, 128);
    size_t holdCap = static_cast<size_t>(mBufFrames) * 8 + 1024;
    mInHold.resize(holdCap * mChannels);
    mMixScratch.resize(static_cast<size_t>(mBufFrames) * mChannels);
    mWsola.reset();

    mRing.clear();
    mPulledInFrames = 0;
    mEnqueuedOutFrames = 0;
    mPlayedOutFrames = 0;
    mHoldFrames = 0;
    mUnderruns = 0;
    mBufIndex = 0;

    // ---- 注册回调并开始 ----
    if ((*mQueue)->RegisterCallback(mQueue, bqCallback, this) != SL_RESULT_SUCCESS) {
        return false;
    }
    mRunning = true;
    mConfigured = true;

    if ((*mPlay)->SetPlayState(mPlay, SL_PLAYSTATE_PLAYING) != SL_RESULT_SUCCESS) {
        return false;
    }
    mStarted = true;

    // 预填两个静音缓冲，保持队列常驻
    for (int i = 0; i < 2; i++) {
        std::memset(mMixBuffer[i], 0,
                    static_cast<size_t>(mBufFrames) * mChannels * sizeof(int16_t));
        (*mQueue)->Enqueue(mQueue, mMixBuffer[i],
                           static_cast<SLuint32>(mBufFrames) * mChannels * sizeof(int16_t));
    }
    // 预填静音的播放时长计入时间基准（不计入媒体帧）
    {
        std::lock_guard<std::mutex> lk(mTimeLock);
        mQueueTimes.clear();
        mHorizonNs = nowNs() + static_cast<int64_t>(
                2.0 * mBufFrames / static_cast<double>(mSampleRate) * 1e9);
        mPausedAtNs = 0;
        mPlayedOutFrames = 0;
        mPlayedPartialFrames = 0.0;
    }
    return true;
}

void AudioEngine::start() {
    if (mPlay == nullptr || !mConfigured) return;
    (*mPlay)->SetPlayState(mPlay, SL_PLAYSTATE_PLAYING);
    mStarted = true;
    mRunning = true;
    // 恢复播放：把暂停时长顺延到所有批次的预计播完时刻，
    // 否则暂停期间流逝的时间会被误计为播放进度
    std::lock_guard<std::mutex> lk(mTimeLock);
    if (mPausedAtNs > 0) {
        int64_t shift = nowNs() - mPausedAtNs;
        if (shift < 0) shift = 0;
        for (auto& e : mQueueTimes) e.first += shift;
        if (mHorizonNs > 0) mHorizonNs += shift;
        mPausedAtNs = 0;
    }
}

void AudioEngine::pause() {
    if (mPlay == nullptr) return;
    if (mStarted.exchange(false)) {
        (*mPlay)->SetPlayState(mPlay, SL_PLAYSTATE_PAUSED);
        std::lock_guard<std::mutex> lk(mTimeLock);
        mPausedAtNs = nowNs();
    }
}

void AudioEngine::stop() {
    mRunning = false;
    if (mPlay != nullptr) {
        (*mPlay)->SetPlayState(mPlay, SL_PLAYSTATE_STOPPED);
    }
    if (mStarted.exchange(false)) {
        std::lock_guard<std::mutex> lk(mTimeLock);
        mPausedAtNs = nowNs();
    }
}

void AudioEngine::flush() {
    if (mPlay != nullptr) {
        (*mPlay)->SetPlayState(mPlay, SL_PLAYSTATE_PAUSED);
    }
    if (mQueue != nullptr) {
        (*mQueue)->Clear(mQueue);
    }
    mRing.clear();
    mWsola.reset();
    mPulledInFrames = 0;
    mEnqueuedOutFrames = 0;
    mHoldFrames = 0;
    mUnderruns = 0;
    mBufIndex = 0;
    std::lock_guard<std::mutex> lk(mTimeLock);
    mQueueTimes.clear();
    mHorizonNs = 0;
    mPausedAtNs = 0;
    mPlayedOutFrames = 0;
    mPlayedPartialFrames = 0.0;
}

void AudioEngine::setVolume(float gain) {
    mGain.store(gain < 0.0f ? 0.0f : (gain > 8.0f ? 8.0f : gain), std::memory_order_relaxed);
}

void AudioEngine::setSpeed(float speed) {
    mSpeed.store(speed < 0.1f ? 0.1f : (speed > 8.0f ? 8.0f : speed), std::memory_order_relaxed);
}

void AudioEngine::setPitchPreserve(bool preserve) {
    bool changed = preserve != mPitchPreserve.load(std::memory_order_relaxed);
    mPitchPreserve.store(preserve, std::memory_order_relaxed);
    if (changed) {
        mWsola.reset();
        mHoldFrames = 0;
    }
}

void AudioEngine::setEq(int band, float gainDb) {
    float g = gainDb < -12.0f ? -12.0f : (gainDb > 12.0f ? 12.0f : gainDb);
    switch (band) {
        case 0: mEqLowDb.store(g, std::memory_order_relaxed); break;
        case 1: mEqMidDb.store(g, std::memory_order_relaxed); break;
        case 2: mEqHighDb.store(g, std::memory_order_relaxed); break;
        default: break;
    }
    mEqDirty = true;
}

float AudioEngine::bufferMs() const {
    // 设备侧两个缓冲
    float devMs = 2.0f * mBufFrames / mSampleRate * 1000.0f;
    return devMs;
}

/**
 * 推进播放进度：把「预计播完时刻 <= now」的批次累加为已播帧，
 * 当前正在播放的批次按时间比例折算部分进度。
 * 暂停中（mStarted == false）不推进——恢复播放时由 start() 顺延时刻基准。
 */
void AudioEngine::advancePlayed() {
    std::lock_guard<std::mutex> lk(mTimeLock);
    if (!mStarted.load(std::memory_order_relaxed)) return;
    int64_t now = nowNs();
    while (!mQueueTimes.empty() && mQueueTimes.front().first <= now) {
        mPlayedOutFrames += mQueueTimes.front().second;
        mQueueTimes.pop_front();
    }
    if (!mQueueTimes.empty()) {
        int64_t finish = mQueueTimes.front().first;
        int frames = mQueueTimes.front().second;
        double batchNs = static_cast<double>(frames) * 1e9
                / static_cast<double>(mSampleRate);
        double start = static_cast<double>(finish) - batchNs;
        double frac = (static_cast<double>(now) - start) / batchNs;
        if (frac < 0.0) frac = 0.0;
        if (frac > 1.0) frac = 1.0;
        mPlayedPartialFrames = frac * frames;
    } else {
        mPlayedPartialFrames = 0.0;
    }
}

int64_t AudioEngine::mediaPositionFrames() {
    advancePlayed();
    std::lock_guard<std::mutex> lk(mTimeLock);
    // 已播放媒体帧 = 已交付重采样 - 保持缓冲中 - 设备队列中未播(折算媒体帧)
    int64_t pulled = mPulledInFrames.load(std::memory_order_relaxed);
    int64_t hold = mHoldFrames.load(std::memory_order_relaxed);
    int64_t enq = mEnqueuedOutFrames.load(std::memory_order_relaxed);
    double played = static_cast<double>(mPlayedOutFrames) + mPlayedPartialFrames;
    double remaining = static_cast<double>(enq) - played;
    if (remaining < 0.0) remaining = 0.0;
    float speed = mSpeed.load(std::memory_order_relaxed);
    double inDevice = remaining * static_cast<double>(speed);
    double pos = static_cast<double>(pulled - hold) - inDevice;
    return pos > 0.0 ? static_cast<int64_t>(pos) : 0;
}

int64_t AudioEngine::playedFramesPublic() const {
    std::lock_guard<std::mutex> lk(mTimeLock);
    return mPlayedOutFrames;
}

int AudioEngine::underruns() const {
    return mUnderruns.load(std::memory_order_relaxed);
}

int AudioEngine::holdFrames() const {
    return static_cast<int>(mHoldFrames.load(std::memory_order_relaxed));
}

int AudioEngine::write(const float* data, int samples) {
    int done = 0;
    while (done < samples) {
        if (!mRunning.load(std::memory_order_relaxed)) break;
        size_t k = mRing.push(data + done, samples - done);
        done += static_cast<int>(k);
        if (k == 0) {
            usleep(1500); // 2ms 让渡，避免忙等
        }
    }
    return done;
}

void AudioEngine::bqCallback(SLAndroidSimpleBufferQueueItf /*bq*/, void* ctx) {
    static_cast<AudioEngine*>(ctx)->pump();
}

void AudioEngine::pump() {
    if (!mRunning.load(std::memory_order_relaxed)) return;

    // 1. EQ 参数变更应用
    if (mEqDirty.exchange(false)) {
        if (mEqLowDb.load() == 0.0f) mEqLow.setBypass(true);
        else { mEqLow.setBypass(false); mEqLow.setLowShelf(mSampleRate, 120.0, 0.707, mEqLowDb.load()); }
        if (mEqMidDb.load() == 0.0f) mEqMid.setBypass(true);
        else { mEqMid.setBypass(false); mEqMid.setPeaking(mSampleRate, 1000.0, 1.1, mEqMidDb.load()); }
        if (mEqHighDb.load() == 0.0f) mEqHigh.setBypass(true);
        else { mEqHigh.setBypass(false); mEqHigh.setHighShelf(mSampleRate, 8000.0, 0.707, mEqHighDb.load()); }
    }

    // 2. 从环形缓冲补充输入到保持缓冲（尽量填满）
    int outFrames = mBufFrames;
    int ch = mChannels;
    int holdCap = static_cast<int>(mInHold.size()) / ch;
    int space = holdCap - static_cast<int>(mHoldFrames.load(std::memory_order_relaxed));
    if (space > 0) {
        int got = static_cast<int>(mRing.pop(
                mInHold.data() + static_cast<size_t>(mHoldFrames.load(std::memory_order_relaxed)) * ch,
                static_cast<size_t>(space) * ch));
        if (got > 0) {
            mHoldFrames.fetch_add(got / ch, std::memory_order_relaxed);
            mPulledInFrames.fetch_add(got / ch, std::memory_order_relaxed);
        }
    }

    // 3. 重采样变速（WSOLA 不变调 / 线性）
    float* out = mMixScratch.data();
    float speed = mSpeed.load(std::memory_order_relaxed);
    int hold = static_cast<int>(mHoldFrames.load(std::memory_order_relaxed));
    int produced = 0;
    if (hold > 0) {
        if (mPitchPreserve.load(std::memory_order_relaxed) && std::fabs(speed - 1.0f) > 0.01f) {
            int consumed = 0;
            produced = mWsola.process(mInHold.data(), hold, out, outFrames, speed, ch, consumed);
            if (consumed > 0) {
                int remain = hold - consumed;
                if (remain > 0) {
                    std::memmove(mInHold.data(),
                                 mInHold.data() + static_cast<size_t>(consumed) * ch,
                                 static_cast<size_t>(remain) * ch * sizeof(float));
                }
                mHoldFrames.store(remain, std::memory_order_relaxed);
            }
        } else {
            // 线性路径（speed==1 时等价直通）
            int need = static_cast<int>(outFrames * speed) + 2;
            int use = hold < need ? hold : need;
            produced = LinearResampler::process(mInHold.data(), use, out, outFrames, speed, ch);
            if (produced > outFrames) produced = outFrames;
            int consumed = static_cast<int>(produced * speed);
            if (consumed > hold) consumed = hold;
            int remain = hold - consumed;
            if (remain > 0) {
                std::memmove(mInHold.data(),
                             mInHold.data() + static_cast<size_t>(consumed) * ch,
                             static_cast<size_t>(remain) * ch * sizeof(float));
            }
            mHoldFrames.store(remain, std::memory_order_relaxed);
        }
    }

    if (produced < outFrames) {
        mUnderruns.fetch_add(1, std::memory_order_relaxed);
        std::fill(out + static_cast<size_t>(produced) * ch,
                  out + static_cast<size_t>(outFrames) * ch, 0.0f);
    }

    // 4. EQ
    mEqLow.process(out, static_cast<size_t>(outFrames) * ch);
    mEqMid.process(out, static_cast<size_t>(outFrames) * ch);
    mEqHigh.process(out, static_cast<size_t>(outFrames) * ch);

    // 5. 增益放大 + 软限幅
    float gain = mGain.load(std::memory_order_relaxed);
    if (gain != 1.0f) {
        size_t total = static_cast<size_t>(outFrames) * ch;
        for (size_t i = 0; i < total; i++) {
            out[i] *= gain;
        }
    }
    mLimiter.process(out, static_cast<size_t>(outFrames) * ch);

    // 6. float -> int16 并入队
    int16_t* dst = mMixBuffer[mBufIndex];
    mBufIndex ^= 1;
    size_t total = static_cast<size_t>(outFrames) * ch;
    for (size_t i = 0; i < total; i++) {
        float v = out[i] * 32767.0f;
        if (v > 32767.0f) v = 32767.0f;
        else if (v < -32768.0f) v = -32768.0f;
        dst[i] = static_cast<int16_t>(v);
    }
    {
        // 记录本批预计播完时刻（FIFO 顺序，承接上一批的 horizon）
        std::lock_guard<std::mutex> lk(mTimeLock);
        int64_t now = nowNs();
        if (mHorizonNs < now) mHorizonNs = now;
        mHorizonNs += static_cast<int64_t>(
                static_cast<double>(outFrames) / static_cast<double>(mSampleRate) * 1e9);
        mQueueTimes.emplace_back(mHorizonNs, outFrames);
        // 队列积压保护：异常情况下丢弃过期的时刻记录
        while (mQueueTimes.size() > 64) mQueueTimes.pop_front();
    }
    mEnqueuedOutFrames.fetch_add(outFrames, std::memory_order_relaxed);

    (*mQueue)->Enqueue(mQueue, dst,
                       static_cast<SLuint32>(outFrames) * ch * sizeof(int16_t));
}

} // namespace hwd
