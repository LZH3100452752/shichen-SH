package com.hwdecoder;

import android.view.Surface;

/**
 * 解码器配置。所有参数均有默认值，使用 Builder 按需覆盖。
 */
public final class DecoderConfig {

    /** 音频输出后端。AUTO = 优先 AudioTrack，失败自动切换 OpenSL ES。 */
    public enum AudioBackend { AUTO, AUDIO_TRACK, OPEN_SL_ES }

    /** Seek 策略：KEY_FRAME_FAST 快（可能轻微回退）；PRECISE 精确（多解码几帧）。 */
    public enum SeekMode { KEY_FRAME_FAST, PRECISE }

    private final String mSource;
    private final Surface mSurface;

    // ---- 视频 ----
    private final int mMaxVideoWidth;      // 0 = 按 Surface 自适应
    private final int mMaxVideoHeight;
    private final boolean mHardwareOnly;   // 强制只用硬件解码
    private final boolean mSoftwareFallback; // 硬解失败自动转软解
    private final int mMaxFrameDropMs;     // 落后超过该阈值直接丢帧
    private final int mMaxHoldMs;          // 超前超过该阈值直接渲染，避免流水线停顿

    // ---- 音频 ----
    private final float mVolume;           // 线性增益 0.0 ~ 8.0（0% ~ 800%）
    private final int mAudioBufferMs;      // 输出缓冲时长
    private final boolean mLowLatencyAudio;// 低延迟输出模式
    private final AudioBackend mAudioBackend;
    private final boolean mPitchPreserve;  // 变速保持音调（WSOLA）
    private final int mPreBufferMs;        // 起播预缓冲时长

    // ---- DSP 链路 ----
    private final boolean mEnableDsp;      // EQ / 动态 / 音量放大 / 限幅
    private final boolean mLoudnessNorm;   // 响度归一化（R128-lite）
    private final float mLoudnessTargetLufs;

    // ---- 其它 ----
    private final long mStatsIntervalMs;
    private final boolean mAutoPlay;
    private final SeekMode mSeekMode;
    private final float mSpeed;
    private final boolean mBigCoreBinding;       // 解码线程绑定大核
    private final boolean mPauseOnBecomingNoisy; // 耳机拔出自动暂停
    private final boolean mLoopList;             // 播放列表循环

    private DecoderConfig(Builder b) {
        mSource = b.mSource;
        mSurface = b.mSurface;
        mMaxVideoWidth = b.mMaxVideoWidth;
        mMaxVideoHeight = b.mMaxVideoHeight;
        mHardwareOnly = b.mHardwareOnly;
        mSoftwareFallback = b.mSoftwareFallback;
        mMaxFrameDropMs = b.mMaxFrameDropMs;
        mMaxHoldMs = b.mMaxHoldMs;
        mVolume = b.mVolume;
        mAudioBufferMs = b.mAudioBufferMs;
        mLowLatencyAudio = b.mLowLatencyAudio;
        mAudioBackend = b.mAudioBackend;
        mPitchPreserve = b.mPitchPreserve;
        mPreBufferMs = b.mPreBufferMs;
        mEnableDsp = b.mEnableDsp;
        mLoudnessNorm = b.mLoudnessNorm;
        mLoudnessTargetLufs = b.mLoudnessTargetLufs;
        mStatsIntervalMs = b.mStatsIntervalMs;
        mAutoPlay = b.mAutoPlay;
        mSeekMode = b.mSeekMode;
        mSpeed = b.mSpeed;
        mBigCoreBinding = b.mBigCoreBinding;
        mPauseOnBecomingNoisy = b.mPauseOnBecomingNoisy;
        mLoopList = b.mLoopList;
    }

    public String getSource() { return mSource; }
    public Surface getSurface() { return mSurface; }
    public int getMaxVideoWidth() { return mMaxVideoWidth; }
    public int getMaxVideoHeight() { return mMaxVideoHeight; }
    public boolean isHardwareOnly() { return mHardwareOnly; }
    public boolean isSoftwareFallback() { return mSoftwareFallback; }
    public int getMaxFrameDropMs() { return mMaxFrameDropMs; }
    public int getMaxHoldMs() { return mMaxHoldMs; }
    public float getVolume() { return mVolume; }
    public int getAudioBufferMs() { return mAudioBufferMs; }
    public boolean isLowLatencyAudio() { return mLowLatencyAudio; }
    public AudioBackend getAudioBackend() { return mAudioBackend; }
    public boolean isPitchPreserve() { return mPitchPreserve; }
    public int getPreBufferMs() { return mPreBufferMs; }
    public boolean isEnableDsp() { return mEnableDsp; }
    public boolean isLoudnessNorm() { return mLoudnessNorm; }
    public float getLoudnessTargetLufs() { return mLoudnessTargetLufs; }
    public long getStatsIntervalMs() { return mStatsIntervalMs; }
    public boolean isAutoPlay() { return mAutoPlay; }
    public SeekMode getSeekMode() { return mSeekMode; }
    public float getSpeed() { return mSpeed; }
    public boolean isBigCoreBinding() { return mBigCoreBinding; }
    public boolean isPauseOnBecomingNoisy() { return mPauseOnBecomingNoisy; }
    public boolean isLoopList() { return mLoopList; }

    public static Builder builder() { return new Builder(); }

    public static final class Builder {
        private String mSource;
        private Surface mSurface;
        private int mMaxVideoWidth;
        private int mMaxVideoHeight;
        private boolean mHardwareOnly;
        private boolean mSoftwareFallback = true;
        private int mMaxFrameDropMs = 120;
        private int mMaxHoldMs = 250;
        private float mVolume = 1.0f;
        private int mAudioBufferMs = 80;
        private boolean mLowLatencyAudio;
        private AudioBackend mAudioBackend = AudioBackend.AUTO;
        private boolean mPitchPreserve = true;
        private int mPreBufferMs = 250;
        private boolean mEnableDsp = true;
        private boolean mLoudnessNorm;
        private float mLoudnessTargetLufs = -16f;
        private long mStatsIntervalMs = 1000;
        private boolean mAutoPlay = true;
        private SeekMode mSeekMode = SeekMode.KEY_FRAME_FAST;
        private float mSpeed = 1.0f;
        private boolean mBigCoreBinding = true;
        private boolean mPauseOnBecomingNoisy = true;
        private boolean mLoopList;

        /** 数据源：本地文件路径、http(s) 链接或 content:// Uri 字符串 */
        public Builder source(String source) { mSource = source; return this; }

        /** 视频渲染 Surface（SurfaceView / TextureView / SurfaceTexture） */
        public Builder surface(Surface surface) { mSurface = surface; return this; }

        /** 限制解码分辨率（超出则使用硬件缩放，降低功耗与带宽） */
        public Builder maxVideoSize(int w, int h) { mMaxVideoWidth = w; mMaxVideoHeight = h; return this; }

        /** 强制只使用硬件解码 */
        public Builder hardwareOnly(boolean b) { mHardwareOnly = b; return this; }

        /** 硬解初始化/运行失败时自动切换软解 */
        public Builder softwareFallback(boolean b) { mSoftwareFallback = b; return this; }

        /** 丢帧阈值（ms）：视频落后超过该值直接丢弃，保证音画同步与流畅 */
        public Builder frameDropThresholdMs(int ms) { mMaxFrameDropMs = ms; return this; }

        /** 最大等待渲染时长（ms） */
        public Builder maxHoldMs(int ms) { mMaxHoldMs = ms; return this; }

        /** 音量（线性增益，1.0=100%，最大 8.0=800%，配合限幅防爆音） */
        public Builder volume(float gain) { mVolume = clamp(gain, 0f, 8f); return this; }

        /** 音频输出缓冲时长（ms） */
        public Builder audioBufferMs(int ms) { mAudioBufferMs = clampInt(ms, 20, 500); return this; }

        /** 低延迟音频 */
        public Builder lowLatencyAudio(boolean b) { mLowLatencyAudio = b; return this; }

        public Builder audioBackend(AudioBackend backend) { mAudioBackend = backend; return this; }

        /** 变速时保持音调（WSOLA 时间缩放，默认开启；关闭则音调随倍速变化） */
        public Builder pitchPreserve(boolean b) { mPitchPreserve = b; return this; }

        /** 起播预缓冲时长（ms）：解码线程先累积该时长再启动输出，避免起播卡顿/欠载 */
        public Builder preBufferMs(int ms) { mPreBufferMs = clampInt(ms, 0, 2000); return this; }

        /** 是否启用 DSP 链路（EQ / 动态处理 / 音量放大 / 限幅） */
        public Builder enableDsp(boolean b) { mEnableDsp = b; return this; }

        /** 响度归一化（R128-lite，目标默认 -16 LUFS） */
        public Builder loudnessNorm(boolean b, float targetLufs) { mLoudnessNorm = b; mLoudnessTargetLufs = targetLufs; return this; }

        /** 性能统计回调间隔（ms），<=0 关闭 */
        public Builder statsIntervalMs(long ms) { mStatsIntervalMs = ms; return this; }

        /** prepare 后自动播放 */
        public Builder autoPlay(boolean b) { mAutoPlay = b; return this; }

        public Builder seekMode(SeekMode mode) { mSeekMode = mode; return this; }

        /** 初始倍速（0.25 ~ 8.0） */
        public Builder speed(float s) { mSpeed = clamp(s, 0.25f, 8f); return this; }

        /** 解码线程绑定大核（默认开启，高倍速/低延迟场景的算力保障） */
        public Builder bigCoreBinding(boolean b) { mBigCoreBinding = b; return this; }

        /** 耳机拔出/音频设备断开时自动暂停（默认开启） */
        public Builder pauseOnBecomingNoisy(boolean b) { mPauseOnBecomingNoisy = b; return this; }

        /** 播放列表循环播放（默认关闭） */
        public Builder loopList(boolean b) { mLoopList = b; return this; }

        public DecoderConfig build() { return new DecoderConfig(this); }

        private static float clamp(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
        private static int clampInt(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
    }
}
