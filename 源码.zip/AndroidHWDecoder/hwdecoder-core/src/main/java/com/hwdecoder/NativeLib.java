package com.hwdecoder;

/**
 * JNI 桥：OpenSL ES 低延迟音频引擎（原生实现）。
 * 功能：float PCM 环形缓冲、原生增益放大 + 软限幅、3 段 EQ、
 * 原生线性重采样变速、低延迟性能模式、underrun 统计。
 */
public final class NativeLib {

    static {
        System.loadLibrary("hwdecoder");
    }

    private NativeLib() {}

    /** @return 引擎句柄，0 表示失败 */
    public static native long nativeCreateEngine();

    public static native void nativeDestroyEngine(long handle);

    /**
     * 配置并启动引擎。
     *
     * @return 是否成功
     */
    public static native boolean nativeConfigure(long handle, int sampleRate, int channels,
                                                   int bufferFrames, boolean lowLatency);

    public static native void nativeStart(long handle);

    public static native void nativePause(long handle);

    public static native void nativeStop(long handle);

    /** 清空缓冲（seek 时调用） */
    public static native void nativeFlush(long handle);

    /**
     * 写入 float PCM（阻塞直到全部写入或停止）。
     *
     * @return 写入帧数
     */
    public static native int nativeWrite(long handle, float[] data, int off, int len);

    /** 设置音量增益（线性，0.0 ~ 8.0） */
    public static native void nativeSetVolume(long handle, float gain);

    /** 设置倍速（0.25 ~ 4.0，原生重采样） */
    public static native void nativeSetSpeed(long handle, float speed);

    /** 设置 EQ：band 0=低频, 1=中频, 2=高频（dB，-12 ~ +12） */
    public static native void nativeSetEq(long handle, int band, float gainDb);

    /** 输出缓冲时长（ms） */
    public static native float nativeGetBufferMs(long handle);

    /** 已播放帧数（1x 空间） */
    public static native long nativeGetPlayedFrames(long handle);

    /** 已播放媒体帧（变速时依然精确，用于进度显示） */
    public static native long nativeGetMediaPositionFrames(long handle);

    /** 变速是否保持音调（WSOLA） */
    public static native void nativeSetPitchPreserve(long handle, boolean preserve);

    /** underrun 次数 */
    public static native int nativeGetUnderruns(long handle);

    /** 设备 CPU 核心数（用于线程策略） */
    public static native int nativeGetCpuCount();

    /** 大核 CPU id 列表（按频率降序） */
    public static native int[] nativeGetBigCoreIds();

    /** 将当前线程绑定到大核（round-robin 选取一个） */
    public static native void nativeBindThreadToBigCore();

    /** 将当前线程绑定到指定 CPU */
    public static native void nativeBindThreadToCpu(int cpu);
}
