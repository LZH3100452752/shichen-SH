package com.hwdecoder.audio;

import com.hwdecoder.NativeLib;

/**
 * 基于 OpenSL ES（NDK）的音频输出。
 * <p>
 * 适用场景：低延迟模式、需要原生 DSP 链路（增益放大/限幅/EQ/重采样变速）时。
 * 播放位置通过「已入队帧数 - 设备缓冲估算」推导，精度略低于 AudioTrack，
 * 因此时钟同步上以 AudioTrack 后端为优先。
 */
public final class OpenSLOutput implements AudioOutput {

    private long mEngine;
    private int mSampleRate;
    private int mChannels;
    private long mBasePtsUs;
    private boolean mStarted;

    public OpenSLOutput() {}

    @Override
    public int open(int sampleRate, int channels, int bufferMs, boolean lowLatency) {
        mSampleRate = sampleRate;
        mChannels = channels;
        int bufferFrames = sampleRate * bufferMs / 1000;
        mEngine = NativeLib.nativeCreateEngine();
        if (mEngine == 0) return RESULT_ERROR_INIT;
        if (!NativeLib.nativeConfigure(mEngine, sampleRate, channels, bufferFrames, lowLatency)) {
            NativeLib.nativeDestroyEngine(mEngine);
            mEngine = 0;
            return RESULT_ERROR_INIT;
        }
        return RESULT_OK;
    }

    @Override
    public int write(float[] data, int off, int len, long ptsUs) {
        if (mEngine == 0) return RESULT_ERROR_WRITE;
        int frames = len / mChannels;
        if (frames <= 0) return 0;
        if (mBasePtsUs == 0 && !mStarted) {
            mBasePtsUs = ptsUs;
        }
        int written = NativeLib.nativeWrite(mEngine, data, off, len);
        return written / mChannels;
    }

    @Override
    public long getPlaybackPositionUs() {
        if (mEngine == 0 || mSampleRate <= 0) return 0;
        long playedFrames = NativeLib.nativeGetMediaPositionFrames(mEngine);
        return mBasePtsUs + playedFrames * 1_000_000L / mSampleRate;
    }

    @Override
    public int getBufferedMs() {
        if (mEngine == 0) return 0;
        return (int) NativeLib.nativeGetBufferMs(mEngine);
    }

    @Override
    public boolean managesOwnBuffering() {
        return true; // 原生引擎有环形缓冲与静音预填充
    }

    @Override
    public int getUnderruns() {
        if (mEngine == 0) return 0;
        return NativeLib.nativeGetUnderruns(mEngine);
    }

    @Override
    public void flush() {
        if (mEngine == 0) return;
        NativeLib.nativeFlush(mEngine);
        mBasePtsUs = 0;
    }

    @Override
    public void start() {
        if (mEngine == 0) return;
        NativeLib.nativeStart(mEngine);
        mStarted = true;
    }

    @Override
    public void pause() {
        if (mEngine == 0) return;
        NativeLib.nativePause(mEngine);
        mStarted = false;
    }

    @Override
    public void setSpeed(float speed) {
        if (mEngine == 0) return;
        NativeLib.nativeSetSpeed(mEngine, speed);
    }

    @Override
    public void setPitchPreserve(boolean preserve) {
        if (mEngine == 0) return;
        NativeLib.nativeSetPitchPreserve(mEngine, preserve);
    }

    @Override
    public void drain() {
        // 原生引擎自行管理保持缓冲，无需 Java 侧排空
    }

    public void setVolume(float gain) {
        if (mEngine == 0) return;
        NativeLib.nativeSetVolume(mEngine, gain);
    }

    public void setEq(int band, float gainDb) {
        if (mEngine == 0) return;
        NativeLib.nativeSetEq(mEngine, band, gainDb);
    }

    @Override
    public void close() {
        if (mEngine != 0) {
            NativeLib.nativeStop(mEngine);
            NativeLib.nativeDestroyEngine(mEngine);
            mEngine = 0;
        }
    }
}
