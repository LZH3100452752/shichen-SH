# AndroidHWDecoder — 高性能 Android 硬件解码播放器

一个**功能完整、深度优化**的 Android 硬件解码器/播放器框架。基于 `MediaCodec` 硬件编解码 + `Surface` 零拷贝渲染 + `AudioTrack`/`OpenSL ES` 双音频后端，全流程 float 域音频处理，支持**音量放大（最高 800%）**、10 段均衡器、动态压缩、响度归一化、**0.25x~8x 高倍速流畅播放（变速不变调）**、多音轨、A-B 循环、单帧步进、截图、频谱可视化与性能统计。

- 纯 Framework API + NDK，**零第三方依赖**，可完全离线构建
- minSdk 21（Android 5.0），覆盖 99% 以上存量设备
- 支持 armeabi-v7a / arm64-v8a / x86 / x86_64
- **双模块结构**：`hwdecoder-core`（解码器核心库，可独立集成到任意播放器）+ `app`（演示 App）

> **要集成到自己的播放器软件？** 请阅读 **[INTEGRATION.md](INTEGRATION.md)**（集成指南：源码拷贝 / Library Module / aar / 场景化接入 / 注意事项）。

---

## 一、功能特性

### 解码能力
| 类别 | 支持格式（取决于设备硬解） |
|------|------|
| 视频 | H.264 (AVC)、H.265 (HEVC)、VP8、VP9、AV1、MPEG-4 |
| 音频 | AAC、MP3、Opus、FLAC、AMR-NB/WB、Vorbis、PCM |
| 容器 | MP4、MKV、WebM、TS、3GP、FLV、MP3 等（MediaExtractor 支持即支持） |
| 数据源 | 本地路径、`http(s)` 网络流、`content://` Uri |

### 播放功能
- 播放 / 暂停 / 停止 / seek（关键帧快 seek + 精确 seek 双模式）
- **倍速播放 0.25x ~ 8.0x**：解封装层抽帧 + WSOLA 波形叠加变速不变调，高倍速依旧流畅
- 音画同步（音频主时钟 + 持续校准，长播不漂移）
- 自适应丢帧策略（阈值随倍速 × 帧间隔动态放宽），卡顿时优先保同步与流畅
- 播放列表：单曲循环 / 列表循环 / 顺序播放，自动切歌
- **A-B 循环**：两点式区间循环，进度 ticker 实时回绕
- **单帧步进**：暂停态逐帧查看，步进后自动对齐时钟
- Surface 热切换（SurfaceView ↔ TextureView，API 23+ 无重启切换）
- **起播预缓冲门控**：先解码 ~150~250ms 再启动输出设备与主时钟，起播不卡顿、不吞帧
- 后台/切 Activity 自动暂停，**耳机拔出自动暂停**（`ACTION_AUDIO_BECOMING_NOISY`），生命周期安全释放

### 音频处理（DSP 链，全 float 域）
1. **声道路由**：立体声 / 声道交换 / 仅左 / 仅右 / 单声道混合
2. **音量放大**：0 ~ 800% 线性增益，每样本增益斜坡（无咔哒声），tanh 软限幅（放大不爆音）
3. **10 段均衡器**：31.25Hz ~ 16kHz，peaking/shelf Biquad，不依赖系统音效框架（无 ROM 差异）
4. **动态处理器**：软膝压缩器 + 峰值限幅，压制爆音、统一响度
5. **响度归一化**：EBU R128 K-weighting 测量 + 增益骑行，解决片源忽大忽小
6. 两个音频后端：**AudioTrack**（float PCM、低延迟模式、Java 侧 WSOLA）与 **OpenSL ES**（原生 DSP 链路 + 原生 WSOLA + 原生变速），可自动回退

### 轨道与画质
- **多音轨枚举与切换**：`getTrackList()` 列出全部轨道（语言/声道/采样率），`selectAudioTrack()` 播放中切换并保留进度
- **HDR 检测**：识别 Transfer ST2084（PQ）/ HLG，回调 `onVideoHdrChanged`
- **单帧截图**：PixelCopy 从 SurfaceView / TextureView 抓帧，返回 Bitmap 回调

### 可视化与统计
- **频谱可视化**：1024 点迭代 Radix-2 FFT + Hann 窗 + 24 段对数频段 + 平滑，`getSpectrumAnalyzer()` 实时取幅值
- 实时统计：解码帧率、丢帧率、**高倍速抽帧数**、码率、音频缓冲水位、underrun 次数、编解码器名称、软硬解标识
- 性能浮层展示（演示 App 内置，含频谱 ASCII 条）

---

## 二、架构设计

```
┌─────────────────────────────────────────────────────────────┐
│                        HWDecoder                             │
│      （门面：状态机 / 时钟 / 播放列表 / A-B循环 / 轨道 / 调度） │
└───────────────┬──────────────────────────┬──────────────────┘
                │                          │
        ┌───────▼────────┐        ┌────────▼─────────┐
        │  VideoDecoder  │        │   AudioDecoder   │
        │ (大核绑定线程)  │        │  (大核绑定线程)   │
        ├────────────────┤        ├──────────────────┤
        │ MediaExtractor │        │  MediaExtractor  │
        │  ★高倍速抽帧   │        │ MediaCodec 硬解 │
        │ MediaCodec 硬解 │        │ DSP 链(float)   │
        │ Surface 零拷贝  │        │  ★起播预缓冲门控 │
        │ 渲染门控/单帧步进│        │  ★WSOLA 变速    │
        └───────┬────────┘        └────────┬─────────┘
                │ Surface                  │ AudioOutput
                ▼                          ▼
        ┌───────────────┐      ┌─────────────────────────┐
        │ SurfaceView   │      │ AudioTrackOutput        │
        │ (直接上屏)     │      │ OpenSLOutput(JNI 原生)   │
        └───────────────┘      └─────────────────────────┘
```

**关键设计决策：**

1. **双线程 + 双 Extractor**：音视频各持有独立 `MediaExtractor` 与解码线程，彻底避免解封装争抢与锁竞争；音频线程天然成为主时钟源。
2. **float 域音频流水线**：解码即请求 `ENCODING_PCM_FLOAT`（API 24+），DSP 与音量放大全程 float，只在最终输出时做一次 int16 转换 + 限幅，放大音质远优于先量化再放大。
3. **同步模式 MediaCodec + 独立线程**：相比异步回调，同步模式对 buffer 生命周期的控制更确定，兼容性更好（API 21+ 统一路径），性能同等。
4. **零拷贝视频通路**：解码输出直接 `releaseOutputBuffer(render=true)` 到 Surface，无 CPU 回读、无 glTexImage 拷贝。
5. **高倍速三重卸载**（详见第六节）：解封装层抽帧从源头降低解码负载；呈现等待期间持续喂输入保持流水线饱和；丢帧/保持阈值随倍速 × 帧间隔自适应放宽。
6. **起播预缓冲门控**：音频侧先解码 ~150ms（或缓冲水位达标 / 300ms 超时）才启动输出设备与主时钟；视频侧渲染门控同步打开，起播即流畅，杜绝吞帧与爆音。
7. **大核亲和性绑定**：通过 `/sys/devices/system/cpu/cpuN/cpufreq/cpuinfo_max_freq` 识别大核，解码线程 JNI `sched_setaffinity` 绑定，高倍率重负载下帧率更稳。
8. **WSOLA 变速不变调**：Hann 窗 + 波形相似度（归一化互相关）搜索 + overlap-add，变速时音调不变、无机械感；Java 与 C++（OpenSL 路径）双实现，输出侧统一按变速倍率折算播放进度。

---

## 三、目录结构

```
AndroidHWDecoder/
├── hwdecoder-core/                  # ★ 硬件解码器核心库（独立 library module，零 UI 依赖）
│   ├── build.gradle                 # com.android.library
│   ├── consumer-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml      # 仅权限声明
│       ├── java/com/hwdecoder/
│       │   ├── HWDecoder.java              # 门面：状态机/播放列表/调度
│       │   ├── HWDecoderListener.java      # 事件回调接口
│       │   ├── DecoderConfig.java          # 配置（Builder 模式）
│       │   ├── PlayerState.java            # 状态机枚举
│       │   ├── MediaClock.java             # AV 主时钟（暂停/变速/校准）
│       │   ├── VideoDecoder.java           # 视频硬解单元（抽帧/丢帧/seek/Surface热切换）
│       │   ├── AudioDecoder.java           # 音频硬解单元（DSP/预缓冲/时钟校准）
│       │   ├── CodecSelector.java          # 解码器选择与软硬解回退
│       │   ├── StatsCollector.java         # 性能统计
│       │   ├── PlayList.java               # 播放列表
│       │   ├── FloatRingBuffer.java        # SPSC 无锁环形缓冲
│       │   ├── AudioProcessorChain.java    # DSP 链
│       │   ├── BiquadFilter.java           # 双二阶滤波器
│       │   ├── VolumeBooster.java          # 音量放大 + 软限幅
│       │   ├── Equalizer.java              # 10 段均衡器
│       │   ├── DynamicsProcessor.java      # 压缩/限幅
│       │   ├── LoudnessNormalizer.java     # 响度归一化
│       │   ├── ChannelRouter.java          # 声道路由
│       │   ├── SpectrumAnalyzer.java       # FFT 频谱可视化
│       │   ├── TrackInfo.java              # 轨道信息
│       │   ├── NativeLib.java              # JNI 桥
│       │   ├── audio/AudioOutput.java      # 音频输出接口
│       │   ├── audio/AudioTrackOutput.java # AudioTrack 后端（含 WSOLA）
│       │   ├── audio/OpenSLOutput.java     # OpenSL ES 后端
│       │   └── audio/WsolaResampler.java   # WSOLA 变速不变调（Java 版）
│       └── jni/                            # 原生层（C++17）
│           ├── CMakeLists.txt
│           ├── native-lib.cpp              # JNI 入口（含大核识别/绑定）
│           ├── audio_engine.h/.cpp         # OpenSL ES 低延迟引擎（播放进度 FIFO 推算）
│           ├── dsp.h                       # Biquad/软限幅/WSOLA 重采样
│           └── ring_buffer.h               # SPSC 无锁环形缓冲
├── app/                          # 演示 App（验证效果用，集成时可删除）
│   └── src/main/java/com/hwdecoder/demo/MainActivity.java
├── INTEGRATION.md                # ★ 集成到自己播放器的指南
└── README.md
```

---

## 四、构建

**环境**：Android Studio Hedgehog+ / AGP 8.5+ / NDK r26+（含 CMake 3.22.1）

```bash
# 方式一：Android Studio 直接打开 AndroidHWDecoder 目录，Run

# 方式二：命令行
cd AndroidHWDecoder
./gradlew assembleDebug                    # 调试包
./gradlew assembleRelease                  # 发布包
./gradlew :hwdecoder-core:assembleRelease  # 单独打出核心库 aar（集成用）
```

首次构建需要联网拉取 AGP（Gradle 插件）；**源码本身零第三方依赖**，拉取完成后可完全离线构建。

---

## 五、快速接入

```java
// 1. 创建
HWDecoder decoder = new HWDecoder(context);
decoder.setListener(new HWDecoderListener() {
    @Override public void onPrepared(int w, int h, long durationUs) { }
    @Override public void onProgress(long posUs, long durUs) { }
    @Override public void onError(int code, String msg) { }
    @Override public void onStats(StatsCollector.Stats s) { /* 性能浮层 */ }
    @Override public void onVideoHdrChanged(boolean hdr) { /* HDR 标识 */ }
});

// 2. 配置数据源（SurfaceView 的 Surface）
decoder.setDataSource(DecoderConfig.builder()
        .source("/sdcard/movie.mp4")   // 或 http(s) URL / content:// Uri
        .surface(surfaceView.getHolder().getSurface())
        .volume(2.5f)                  // 音量放大到 250%
        .audioBufferMs(80)
        .enableDsp(true)
        .loudnessNorm(true, -16f)
        .speed(1.0f)                   // 初始倍速
        .pitchPreserve(true)           // 变速不变调
        .preBufferMs(250)              // 起播预缓冲
        .bigCoreBinding(true)          // 大核绑定
        .pauseOnBecomingNoisy(true)    // 耳机拔出自动暂停
        .statsIntervalMs(1000)
        .build());

// 3. 异步准备（内部自动完成硬解选择，失败自动回退软解）
decoder.prepareAsync();

// 4. 控制
decoder.start();            // 播放
decoder.pause();            // 暂停
decoder.seekTo(60_000_000); // seek 到 60s
decoder.setSpeed(4.0f);     // 4 倍速（自动抽帧 + WSOLA 不变调）
decoder.setVolume(4.0f);    // 音量放大到 400%

// 5. 实时调音
Equalizer eq = decoder.getEqualizer();
if (eq != null) eq.setBandGain(3, 4.5f);   // 250Hz +4.5dB

// 6. 释放（Activity onDestroy）
decoder.release();
```

Surface 变更时调用 `decoder.setSurface(newSurface)` 与 `decoder.setSurfaceSize(w, h)` 即可，API 23+ 无重启切换。

---

## 六、性能优化详解

### 基础优化
| 优化项 | 实现 |
|--------|------|
| 硬件解码零拷贝 | 输出直渲染 Surface，无 CPU 回读 |
| 线程优先级 | 视频线程 `THREAD_PRIORITY_URGENT_DISPLAY`，音频线程 `THREAD_PRIORITY_URGENT_AUDIO`，Codec `KEY_PRIORITY=0` 实时优先级 |
| 无锁音频缓冲 | SPSC 环形缓冲（序号法），解码线程与输出线程零锁竞争 |
| 零分配热路径 | `BufferInfo`/PCM 缓冲复用，解码循环不产生 GC 压力 |
| float 音频流水 | 一次 float→int16 转换，减少量化损失与转换次数 |
| 自适应丢帧 | 迟到 > 阈值直接丢帧，保同步与流畅；阈值随倍速 × 帧间隔 EMA 动态放宽 |
| 精确呈现调度 | 粗 `sleep` + 忙等混合，帧按时上屏 |
| 解码分辨率限制 | 超限时请求硬件缩放到目标分辨率，降低功耗/带宽/发热 |
| 音频主时钟 | 以实际播放位置持续校准，杜绝长播漂移 |
| 低延迟音频 | `PERFORMANCE_MODE_LOW_LATENCY` + `KEY_LOW_LATENCY` 提示 |
| seek 优化 | 关键帧快 seek；精确 seek 按目标帧丢弃；seek 期间暂停时钟对齐 |
| 音频缓冲调优 | 缓冲时长可调（20~500ms），默认 80ms 平衡延迟与抗抖动 |
| 原生变速 | OpenSL 后端线性重采样变速，避免设备重采样器差异 |

### 高倍速流畅专项（0.25x ~ 8x）
| 优化项 | 实现 |
|--------|------|
| **解封装层抽帧** | 倍速 > 1.05x 时 `extractor.advance()` 跳过不解码：8 倍速只解 ~1/8 帧，从源头卸载解码负载 |
| **等待期间持续喂输入** | 呈现等待切片为「喂输入 + 2ms sleep + 忙等」，解码器全程饱和，避免流水线饥饿 |
| **阈值自适应放宽** | 丢帧阈值 = max(配置, 倍速 × 帧间隔)，保持阈值 = max(配置, 2.5 × 倍速 × 帧间隔)，高倍速不再误丢好帧 |
| **WSOLA 变速不变调** | Hann 窗 + 波形相似度搜索 + overlap-add；Java/C++ 双实现，音调不变、无机械感 |
| **起播预缓冲门控** | 先解码 ~150ms（或缓冲达标/300ms 超时）再启动输出设备与主时钟，起播不卡不吞帧 |
| **大核亲和性绑定** | `/sys/.../cpuinfo_max_freq` 识别大核，JNI `sched_setaffinity` 绑定解码线程，重负载帧率更稳 |
| **进度按变速折算** | 输出侧统一按 `speed` 折算播放进度（OpenSL FIFO 入队时刻推算 + AudioTrack 基址），倍速下 seek 条/时间显示依旧准确 |

**调优建议：**
- 低端机卡顿：`maxVideoSize(1280, 720)` 限制解码分辨率；`frameDropThresholdMs(80)` 更激进丢帧
- 弱网/高码率流：`audioBufferMs(150~250)` 增大抗抖动缓冲
- 音质优先：`enableDsp(true)` + 响度归一化，音量放大后由限幅器收敛
- 功耗优先：`lowLatencyAudio(false)`，使用 POWER_SAVING 性能模式
- 4x 以上刷剧/听课：保持 `pitchPreserve(true)`（默认），人声音调不变；若追求极限帧率可关闭，改由设备重采样

---

## 七、兼容性设计

- **API 21+ 全功能**：同步模式 MediaCodec、`ENCODING_PCM_FLOAT`（API 21+ 可用）
- **软硬解自动回退**：按 `CodecSelector` 候选列表逐一尝试，硬解崩溃/不支持自动切换
- **芯片问题规避**：内置已知问题组合黑名单（如部分 MTK HEVC 硬解），可扩展
- **content:// Uri**：自动走 `Context` 重载，规避部分 ROM 字符串重载缺陷
- **Surface 生命周期**：API 23+ `setOutputSurface` 热切换，低版本自动重启解码器
- **音频设备异常**：AudioTrack 打开失败自动切换 OpenSL ES 后端
- **缺失音轨容错**：选中音轨不存在时回调 `onAudioTrackAbsent`，不影响视频继续播放
- **耳机拔出**：注册 `ACTION_AUDIO_BECOMING_NOISY` 广播，自动暂停（`pauseOnBecomingNoisy` 可关）

---

## 八、已知限制与后续路线

- 网络流为渐进式播放（无自适应码率 ABR 切换），已内置缓冲水位统计可供上层决策
- 未内置字幕渲染与 DRM（Widevine）支持
- 可扩展方向：ExoPlayer 式自适应码率、MediaCodec 异步回调模式、视频后处理（OpenGL ES 锐化/降噪）

---

## 九、许可

MIT License，可自由用于商业项目。
