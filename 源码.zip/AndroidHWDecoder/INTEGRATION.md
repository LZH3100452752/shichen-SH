# 集成指南：把 HWDecoder 接入你自己的播放器

本指南面向**把硬件解码器集成到自己播放器软件**的开发者。核心解码器是一个独立的库模块（`hwdecoder-core`），与演示 App 完全解耦，没有任何 UI 依赖。

---

## 一、工程结构：哪些是解码器，哪些是演示

```
AndroidHWDecoder/
├── hwdecoder-core/            ←★★★ 硬件解码器核心（你要集成的就是它）★★★
│   ├── build.gradle           （com.android.library，零第三方依赖）
│   └── src/main/
│       ├── AndroidManifest.xml（仅权限声明）
│       ├── java/com/hwdecoder/
│       │   ├── HWDecoder.java          # 门面：状态机/时钟/播放列表/调度
│       │   ├── DecoderConfig.java      # 配置（Builder）
│       │   ├── HWDecoderListener.java  # 回调
│       │   ├── PlayerState.java        # 状态机
│       │   ├── VideoDecoder.java       # 视频硬解单元（抽帧/丢帧/seek/Surface热切换）
│       │   ├── AudioDecoder.java       # 音频硬解单元（DSP/预缓冲/时钟校准）
│       │   ├── MediaClock.java         # AV 主时钟
│       │   ├── CodecSelector.java      # 硬解选择/软解回退
│       │   ├── StatsCollector.java     # 性能统计
│       │   ├── PlayList.java           # 播放列表（可选）
│       │   ├── AudioProcessorChain.java / BiquadFilter.java / Equalizer.java
│       │   ├── VolumeBooster.java / DynamicsProcessor.java / LoudnessNormalizer.java
│       │   ├── ChannelRouter.java      # 声道路由
│       │   ├── SpectrumAnalyzer.java   # FFT 频谱可视化
│       │   ├── TrackInfo.java          # 轨道信息
│       │   ├── NativeLib.java          # JNI 桥（含大核识别/绑定）
│       │   └── audio/                  # 音频输出后端（AudioTrack / OpenSL ES / WSOLA）
│       └── jni/                        # 原生库（C++17，OpenSL ES + DSP + WSOLA）
└── app/                        ← 演示 App（验证解码器用，集成时可整体删除）
    └── java/com/hwdecoder/demo/MainActivity.java
```

**解码器核心不依赖任何 Activity/View/资源**，你可以整体拷贝，也可以按需裁剪。

---

## 二、集成方式 A：源码拷贝（最灵活，推荐）

适合：自己的工程是单模块，或想把代码并入现有模块。

### 步骤

1. **拷贝 Java 源码**：把 `hwdecoder-core/src/main/java/com/hwdecoder/` 整个目录拷到你工程的源码目录下（**保持包名 `com.hwdecoder` 不变**，否则 JNI 注册名会失效）。

2. **拷贝原生代码**：把 `hwdecoder-core/src/main/jni/` 拷到你的模块下，并在模块 `build.gradle` 中开启 CMake：

   ```gradle
   android {
       defaultConfig {
           minSdk 21
           externalNativeBuild {
               cmake {
                   cppFlags "-std=c++17 -O3"
                   arguments "-DANDROID_STL=c++_static"
               }
           }
       }
       externalNativeBuild {
           cmake {
               path "src/main/jni/CMakeLists.txt"   // 按你的实际路径调整
               version "3.22.1"
           }
       }
   }
   ```

3. **加权限**（网络播放需要）：

   ```xml
   <uses-permission android:name="android.permission.INTERNET" />
   ```

4. **按需裁剪**（都可以安全删除，删除后对应功能不可用）：
   - 不需要音量放大/音效 → 删 `Equalizer`、`DynamicsProcessor`、`LoudnessNormalizer`、`AudioProcessorChain`，并把 `AudioDecoder` 中 DSP 链构建段改为直通（保留 `VolumeBooster` 即可继续放大）
   - 不需要播放列表 → 删 `PlayList.java`
   - 不需要性能统计 → 删 `StatsCollector.java`，把 `HWDecoder` 中相关调用去掉
   - 不需要 OpenSL ES 后端 → 删 `audio/OpenSLOutput.java`、`jni/` 全部、`NativeLib.java`
   - 不需要频谱/声道路由/音轨 → 删 `SpectrumAnalyzer` / `ChannelRouter` / `TrackInfo` 及 `HWDecoder` 中对应调用

---

## 三、集成方式 B：作为 Library Module 依赖（最省事）

适合：多模块工程，或想把解码器打成 aar 复用。

1. 把整个 `hwdecoder-core/` 目录拷到你的工程根目录；
2. 在 `settings.gradle` 中注册：

   ```gradle
   include ':app', ':hwdecoder-core'
   ```

3. 在播放器模块的 `build.gradle` 中依赖：

   ```gradle
   dependencies {
       implementation project(':hwdecoder-core')
   }
   ```

4. 直接 `import com.hwdecoder.HWDecoder;` 使用（包名保持 `com.hwdecoder`）。

> 想发布 aar：对 `hwdecoder-core` 执行 `./gradlew :hwdecoder-core:assembleRelease`，产物在 `hwdecoder-core/build/outputs/aar/`。

---

## 四、在你的播放器中调用（最小可用代码）

### 1. 初始化与 Surface 对接

解码器通过 Surface 上屏，SurfaceView / TextureView / SurfaceTexture 均可：

```java
public class MyPlayerActivity extends Activity implements SurfaceHolder.Callback {

    private HWDecoder mDecoder;
    private SurfaceView mSurfaceView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.my_player_layout);
        mSurfaceView = findViewById(R.id.surface_view);
        mSurfaceView.getHolder().addCallback(this);

        mDecoder = new HWDecoder(this);
        mDecoder.setListener(new HWDecoderListener() {
            @Override public void onPrepared(int w, int h, long durationUs) {
                // 元数据就绪，可以显示时长、起播
            }
            @Override public void onProgress(long posUs, long durUs) {
                // 更新进度条（250ms 一次）
            }
            @Override public void onStateChanged(PlayerState state) { }
            @Override public void onError(int code, String msg) { }
            @Override public void onCompletion() { }
            @Override public void onVideoHdrChanged(boolean hdr) { /* HDR/SDR 标识 */ }
        });
    }

    /** 打开并播放一个视频 */
    private void play(String url) {
        DecoderConfig config = DecoderConfig.builder()
                .source(url)                                   // 本地路径 / http(s) / content://
                .surface(mSurfaceView.getHolder().getSurface()) // 渲染目标
                .volume(1.0f)                                   // 100% 音量，可到 8.0f（800%）
                .autoPlay(true)
                .speed(1.0f)                                    // 初始倍速
                .pitchPreserve(true)                            // 变速不变调
                .preBufferMs(250)                               // 起播预缓冲
                .bigCoreBinding(true)                           // 大核绑定
                .pauseOnBecomingNoisy(true)                     // 耳机拔出自动暂停
                .build();
        mDecoder.setDataSource(config);
        mDecoder.prepareAsync();   // 异步：内部自动选硬解，失败自动回退软解
    }

    // ---- Surface 生命周期：变化时通知解码器（API 23+ 无重启热切换）----
    @Override public void surfaceCreated(SurfaceHolder h) {
        mDecoder.setSurface(h.getSurface());
    }
    @Override public void surfaceChanged(SurfaceHolder h, int f, int w, int hgt) {
        mDecoder.setSurface(h.getSurface());
        mDecoder.setSurfaceSize(w, hgt);   // 用于解码分辨率自适应限制
    }
    @Override public void surfaceDestroyed(SurfaceHolder h) { }

    // ---- Activity 生命周期 ----
    @Override protected void onPause() {
        super.onPause();
        if (mDecoder.isPlaying()) mDecoder.pause();   // 退后台自动暂停
    }
    @Override protected void onDestroy() {
        super.onDestroy();
        mDecoder.release();                            // 必须调用，释放 MediaCodec/AudioTrack
        mDecoder = null;
    }
}
```

### 2. 播放控制 API 一览

| 操作 | API |
|------|-----|
| 播放 / 暂停 / 切换 | `start()` / `pause()` / `togglePlayPause()` |
| 跳转 | `seekTo(us)` / `seekToPercent(0.5f)` |
| 音量放大 | `setVolume(4.0f)`（1.0=100%，最大 8.0=800%） |
| 倍速 | `setSpeed(1.5f)`（0.25~8.0，自动抽帧 + WSOLA 不变调） |
| 变速不变调开关 | `setPitchPreserve(true)` / `isPitchPreserve()` |
| 状态/进度 | `getState()` / `getPositionUs()` / `getDurationUs()` |
| 均衡器 | `getEqualizer().setBandGain(band, db)` |
| 性能统计 | `HWDecoderListener.onStats(...)` |
| 多曲播放 | `setPlayList(sources, baseConfig)` + `next()` / `previous()` |
| 重载当前源（保留位置） | `reloadSource(source, seekToUs, autoPlay)` |

### 3. 高倍速播放（0.25x ~ 8x）

```java
decoder.setSpeed(4.0f);              // 4 倍速：解封装抽帧 + WSOLA 不变调
decoder.setPitchPreserve(true);      // 默认开；关闭则用设备重采样（更省电、音调会变）
```

内部行为（无需调用方干预）：
- 倍速 > 1.05x 时视频在解封装层按 `round(speed)` 抽帧，8 倍速只解 ~1/8 帧；
- 丢帧/保持阈值随倍速 × 帧间隔自适应放宽；
- 音频经 WSOLA 时间缩放，音调不变；播放进度按变速倍率折算，seek 条与时间显示依旧准确。

### 4. 多音轨切换

```java
// 枚举全部轨道（视频 + 音频，含语言/声道/采样率）
List<TrackInfo> tracks = decoder.getTrackList();
for (TrackInfo t : tracks) {
    if (t.type == TrackInfo.TYPE_AUDIO) Log.d(TAG, t.describe());
}

// 播放中切换音轨（保留当前播放位置）
int ok = decoder.selectAudioTrack(trackIndex);
// 切换失败/音轨缺失时回调 onAudioTrackAbsent()
```

### 5. A-B 循环与单帧步进

```java
// A-B 循环（进度 ticker 到 B 自动回 A）
decoder.setLoopRange(aUs, bUs);
decoder.clearLoopRange();
decoder.isLooping();

// 单帧步进（暂停态逐帧查看，步进后自动对齐时钟）
decoder.stepFrame();   // 结果回调 onFrameStepped(ptsUs)
```

### 6. 截图与频谱

```java
// 截图（SurfaceView / TextureView 均可，PixelCopy 异步抓帧）
decoder.captureFrame(surfaceView, new HWDecoder.CaptureCallback() {
    @Override public void onCaptured(Bitmap bitmap) { /* 保存/分享 */ }
    @Override public void onError(String message) { }
});

// 频谱可视化（AudioDecoder 侧持续推送解码数据）
SpectrumAnalyzer sa = decoder.getSpectrumAnalyzer();
if (sa != null) {
    float[] bands = new float[sa.getBandCount()];   // 24 段对数频段，0~1 已平滑
    sa.getBands(bands);                             // 可在 onStats/UI 线程调用
}
```

### 7. 声道路由

```java
decoder.setChannelMode(ChannelRouter.MODE_MONO);   // 立体声/交换/仅左/仅右/单声道
int mode = decoder.getChannelMode();
```

### 8. 后台播放（Service）

解码器本身不绑定 Activity，把 `HWDecoder` 放进 Service 即可：Surface 通过 `SurfaceView` 由前台 Activity 提供（或通知栏常驻时释放 Surface 仅播音频）。注意 `release()` 必须在 Service onDestroy 调用。

---

## 五、典型集成场景

### 场景 A：自研播放器，整体替换播放内核
直接用门面 `HWDecoder`（上文代码即完整方案）。它内部自带解封装（MediaExtractor）+ 双路硬解 + 音视频同步 + 音频输出，**不依赖你工程里任何其他播放组件**。

### 场景 B：已有 ExoPlayer / ijkplayer，想借用本解码器
本解码器是独立自包含的播放管线（自带自己的 MediaExtractor 与输出），与 ExoPlayer 的组件模型不同，**不建议混用两条管线同时解封装同一路流**（会双倍解码耗电）。两种正确用法：
1. **替换**：整体换成本解码器（场景 A）；
2. **旁路增强**：保留原播放器，仅在需要「音量放大/音效处理」时，用本工程的 **DSP 链**（`AudioProcessorChain` + `VolumeBooster` + `Equalizer`）处理原播放器输出的 PCM——把 `AudioDecoder` 删除，只保留 DSP 类即可。

### 场景 C：只要音频解码 + 放大/音效（做音乐播放器）
删除 `VideoDecoder.java`，`HWDecoder` 中视频相关调用去掉；纯音频文件本来就走「无视频轨」分支，视频单元自动跳过，无需改逻辑。

### 场景 D：对接你自己的音频输出（已有 AudioTrack 管理体系）
`AudioDecoder` 内部通过接口 `com.hwdecoder.audio.AudioOutput` 输出：
1. 实现该接口（`open/write/getPlaybackPositionUs/flush/pause/start/setSpeed/setPitchPreserve/drain/managesOwnBuffering/close`）；
2. 在 `AudioDecoder.prepare()` 的输出后端选择段加入你的实现即可（约 5 行改动）；或发我帮你加一个 `AudioBackend.CUSTOM` 选项。

### 场景 E：深度定制（自定义数据源协议、自绘渲染）
`VideoDecoder` / `AudioDecoder` 为包级私有单元类。如需直接使用，把它们改为 `public`，并把构造函数中的 `Host` 接口在你侧实现即可单独驱动任一路。需要改动约 3 处访问修饰符。

---

## 六、注意事项（集成前必读）

1. **Surface 必须就绪后再 setDataSource**：视频解码器 `configure()` 需要非空 Surface。演示 App 的做法是先挂起、`surfaceCreated` 后再起播（见 `MainActivity.playSources`），请在你的工程里保持一致。
2. **release() 必须调用**：否则 MediaCodec/AudioTrack 句柄泄漏，后台会被系统杀。
3. **线程模型**：解码器内部自建 4 个线程（视频准备/视频解码/音频准备/音频解码）+ OpenSL 回调线程，全部回调均切回主线程，可直接操作 UI。
4. **content:// Uri**：需传 Application Context（`new HWDecoder(context)` 已处理），不要传 Activity 以防泄漏。
5. **seek 语义**：`seekTo()` 后约几百毫秒内 `onSeekCompleted` 回调首帧到位；精确 seek 比快 seek 稍慢（多解码几帧）。
6. **音量放大与爆音**：放大超过 100% 时默认启用 tanh 软限幅（`VolumeBooster`），如需更激进处理可开启 `DynamicsProcessor`（`getDspChain().get(DynamicsProcessor.class)` 调参）。
7. **设备兼容**：minSdk 21；`ENCODING_PCM_FLOAT` 在 API 21+ 可用，个别老旧设备不支持时自动回退 16bit 路径（已内置）。
8. **Kotlin 工程**：全部为 Java 类，Kotlin 可直接调用；`HWDecoderListener` 的方法是 default 方法，Kotlin 实现接口时按需 override。
9. **起播预缓冲**：默认 `preBufferMs(250)`，起播时先解码约 150ms 再启动输出设备与主时钟；`onAudioPrebuffered()` 回调时才是真正开始出声，可用来隐藏加载动画。设为 0 可关闭。
10. **耳机拔出暂停**：`pauseOnBecomingNoisy(true)` 时注册 `ACTION_AUDIO_BECOMING_NOISY` 广播自动暂停；如你的 App 自己管理该广播，请关闭此选项避免重复响应。
11. **倍速与音轨切换**：`selectAudioTrack()` 会重载源并保留播放位置，切换瞬间有几毫秒静音；`setSpeed()` 可随时调用，立即生效。

---

## 七、快速自检清单

- [ ] `com.hwdecoder` 包名未被改动（否则 `System.loadLibrary` 与 JNI 函数名失效）
- [ ] CMake 已接入（`externalNativeBuild` 配置无误，NDK 版本 r26+）
- [ ] `INTERNET` 权限已加（网络播放）
- [ ] Surface 就绪后才 setDataSource
- [ ] onDestroy / Service onDestroy 中调用了 `release()`
- [ ] 音量滑杆映射到 `setVolume(0f ~ 8f)`
- [ ] 倍速控件映射到 `setSpeed(0.25f ~ 8f)`
- [ ] 如自绘频谱：在 `onStats` 或 UI 定时器里调 `getSpectrumAnalyzer().getBands()`
