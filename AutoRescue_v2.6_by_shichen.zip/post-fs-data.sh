#!/system/bin/sh
# =====================================================================
#  AutoRescue · 早期启动检测 (post-fs-data 阶段)
#  这是最关键的救命阶段: 此时已经能读写 /data, 且早于模块完全生效
#  作者: 时尘  v2.6
# =====================================================================

MODDIR=${0%/*}
export MODDIR
. "$MODDIR/common/functions.sh"
. "$MODDIR/common/rescue.sh"

ar_init_dirs
ar_conf_defaults

ar_log INFO "===== post-fs-data 启动检测 ====="

# ---------------------------------------------------------------- 强制救援标记
if [ -f "$AR_DATA/force_rescue" ]; then
    ar_log WARN "检测到 force_rescue 标记 -> 立即执行救援"
    rm -f "$AR_DATA/force_rescue" 2>/dev/null
    r=$(ar_state_get rescue_round); case "$r" in ''|*[!0-9]*) r=2;; esac
    r=$((r+1))
    ar_state_set rescue_round "$r"
    ar_do_rescue "$r" "用户手动强制救援"
    ar_state_set boot_count 0
    if ar_circuit_breaker; then
        ar_reboot "force_rescue"
    fi
    exit 0
fi

# ---------------------------------------------------------------- 卡死阶段分析
prev=$(ar_state_get last_stage)
stuck=$(ar_state_get stuck_count); case "$stuck" in ''|*[!0-9]*) stuck=0;; esac
if [ "$prev" = "post-fs-data" ]; then
    stuck=$((stuck+1))
    ar_log WARN "上次启动停留在 post-fs-data 阶段 (连续 $stuck 次) -> 疑似模块脚本卡死"
else
    stuck=0
fi
ar_state_set stuck_count "$stuck"
ar_state_set last_stage "post-fs-data"

# ---------------------------------------------------------------- 启动计数
cnt=$(ar_boot_count)
cnt=$((cnt+1))
ar_state_set boot_count "$cnt"

thr=$(ar_conf_get boot_threshold 3)
case "$thr" in ''|*[!0-9]*) thr=3;; esac
[ "$thr" -lt 2 ] && thr=2

ar_log INFO "启动计数: $cnt / 阈值 $thr"

# ---------------------------------------------------------------- 判定是否救援
if [ "$(ar_conf_get auto_rescue 1)" != "1" ]; then
    ar_log INFO "自动救砖已关闭, 跳过检测"
    exit 0
fi

need=0
if [ "$cnt" -ge "$thr" ]; then
    need=1
elif [ "$stuck" -ge 2 ]; then
    need=1
    ar_log WARN "连续 $stuck 次卡在早期阶段 -> 提前触发救援"
fi

if [ "$need" = "1" ]; then
    r=$(ar_state_get rescue_round); case "$r" in ''|*[!0-9]*) r=0;; esac
    # 卡在早期阶段通常意味着模块脚本问题, 直接跳到 L2(跳过只清非白名单的 L1)
    if [ "$stuck" -ge 2 ] && [ "$r" -lt 2 ]; then r=2; fi
    r=$((r+1))
    ar_state_set rescue_round "$r"
    ar_do_rescue "$r" "连续 $cnt 次启动未完成 (阈值 $thr)"
    ar_state_set boot_count 0
    ar_state_set stuck_count 0
    if ar_circuit_breaker; then
        ar_reboot "bootloop_L$r"
    fi
    exit 0
fi

exit 0
