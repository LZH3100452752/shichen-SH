#!/system/bin/sh
# =====================================================================
#  AutoRescue · boot_completed 标记
#  作者: 时尘  v2.6
# =====================================================================

MODDIR=${0%/*}
export MODDIR
. "$MODDIR/common/functions.sh"
. "$MODDIR/common/rescue.sh"

ar_init_dirs
ar_conf_defaults
ar_state_set last_stage "boot-completed"
ar_state_set last_boot_completed "$(ar_now)"
ar_log INFO "===== 系统启动完成 (boot_completed) ====="

# ---------------------------------------------------------------- 兜底稳定确认
# 计数清零原本只由 watchdog 负责。但 watchdog 是 late_start 起的后台进程,
# 在 KernelSU / 部分 Magisk 上会被清理掉, 一旦它没跑起来, boot_count 就
# 永远不会清零(表现为计数一直卡在某个数不动)。这里在 boot_completed 阶段
# 再起一个延时确认作为兜底: 即便 watchdog 挂了, 计数也能正常归零。
(
    d=$(ar_conf_get confirm_delay 90)
    case "$d" in ''|*[!0-9]*) d=90;; esac
    [ "$d" -lt 10 ] && d=10
    # 比 watchdog 晚 20 秒, 正常情况由 watchdog 先清零, 这里就不会重复动作
    sleep $((d + 20))
    [ "$(getprop sys.boot_completed 2>/dev/null)" = "1" ] || exit 0
    cnt=$(ar_boot_count)
    [ "${cnt:-0}" = "0" ] && exit 0
    # 到这里说明 watchdog 没能把计数清零, 由兜底接管
    ar_log WARN "稳定确认兜底触发: watchdog 未清零计数 (cnt=$cnt)"
    ar_confirm_success
) >/dev/null 2>&1 &

# 提示型通知(如果 toast 可用)
if [ "$(ar_conf_get notify 1)" = "1" ] && [ -f "$AR_STATE/last_rescue_time" ]; then
    lt=$(ar_state_get last_rescue_time)
    lr=$(ar_state_get last_rescue_round)
    if [ -n "$lt" ] && [ -n "$lr" ]; then
        # 只在刚刚救援过(日志里最近一次)的情况下提示
        if grep -q "救援完成" "$AR_LOG" 2>/dev/null; then
            (
                sleep 8
                cmd notification post -S bigtext -t 'AutoRescue 救砖守护' 'AutoRescue' \
                    "检测到启动异常并已自动处理 (L$lr)。打开模块 WebUI 查看详情。" >/dev/null 2>&1
            ) &
        fi
    fi
fi

exit 0
