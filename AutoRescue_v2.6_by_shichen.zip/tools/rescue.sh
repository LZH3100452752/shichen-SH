#!/system/bin/sh
# =====================================================================
#  AutoRescue · 手动救援工具
#  用法: sh /data/adb/modules/auto_rescue/tools/rescue.sh
#        可在 recovery 下用 adb shell 执行(需 /data 已挂载)
#  作者: 时尘  v2.6
# =====================================================================

MODDIR="${MODDIR:-/data/adb/modules/auto_rescue}"
[ -d "$MODDIR" ] || MODDIR="/data/adb/modules/auto_rescue"
export MODDIR

if [ -f "$MODDIR/common/functions.sh" ]; then
    . "$MODDIR/common/functions.sh"
    . "$MODDIR/common/rescue.sh"
. "$MODDIR/common/scan.sh" 2>/dev/null
. "$MODDIR/common/guard.sh" 2>/dev/null
else
    echo "!! 找不到模块文件: $MODDIR"
    exit 1
fi

ar_init_dirs
ar_conf_defaults

menu() {
    echo ""
    echo " ============================================ "
    echo "   AutoRescue 手动救援工具   ${AR_VER:-v2.6}  by 时尘   "
    echo " ============================================ "
    echo "   [1] 查看当前模块列表与状态"
    echo "   [2] 查看启动计数 / 救援状态"
    echo "   [3] 查看最近日志"
    echo "   [4] L1 禁用全部非白名单模块"
    echo "   [5] L2 含白名单一起禁用(仅留守护自身)"
    echo "   [15] L3 彻底移除全部模块挂载(改名模块目录)"
    echo "   [6] 恢复全部模块(启用 + 解除隔离)"
    echo "   [7] 标记下次启动强制执行救援"
    echo "   [8] 重置启动计数"
    echo "   [9] 创建当前配置快照"
    echo "   [10] 回滚到指定快照"
    echo "   [11] 扫描某模块的脚本(危险代码/加密)"
    echo "   [12] 全部模块一键体检"
    echo "   [13] 系统防护巡检 / 重建基线"
    echo "   [14] 查看防护告警记录"
    echo "   [0] 退出"
    echo " -------------------------------------------- "
    printf '  请选择: '
}

list_modules() {
    echo ""
    printf '  %-6s %-34s %s\n' "状态" "模块名" "ID"
    echo " -------------------------------------------- "
    for d in $(ar_module_dirs); do
        id=$(basename "$d")
        st="启用"
        [ "$(ar_module_enabled "$d")" = "1" ] || st="禁用"
        ar_is_whitelisted "$id" && st="$st★"
        printf '  %-6s %-34s %s\n' "$st" "$(ar_prop "$d" name "$id" | cut -c1-34)" "$id"
    done
    echo ""
}

while :; do
    menu
    read -r c
    case "$c" in
        1) list_modules;;
        2) echo ""
           echo "  启动计数: $(ar_boot_count) / 阈值 $(ar_conf_get boot_threshold 3)"
           echo "  救援等级: $(ar_state_get rescue_round)"
           echo "  上次救援: $(ar_state_get last_rescue_time)  原因: $(ar_state_get last_rescue_reason)"
           echo "  上次成功: $(ar_state_get last_success)"
           echo "  当前阶段: $(ar_state_get last_stage)";;
        3) tail -n 40 "$AR_LOG" 2>/dev/null;;
        4) ar_rescue_now 1 "手动救援 L1"; echo "  完成, 请重启";;
        5) ar_rescue_now 2 "手动救援 L2"; echo "  完成, 请重启";;
        6) for d in $(ar_module_dirs); do ar_enable_module "$d"; done; ar_restore_quarantine; echo "  已全部恢复";;
        7) : > "$AR_DATA/force_rescue"; echo "  已标记, 下次启动将强制执行救援";;
        8) ar_state_set boot_count 0; ar_state_set rescue_round 0; echo "  已重置";;
        9) id=$(ar_snapshot_create manual); echo "  快照已创建: $id";;
        10) ls -1t "$AR_SNAP"/*.meta 2>/dev/null | while read -r f; do
                printf '  %s  %s  %s\n' "$(grep -m1 '^id=' "$f" | cut -d= -f2-)" \
                    "$(grep -m1 '^time=' "$f" | cut -d= -f2-)" "$(grep -m1 '^tag=' "$f" | cut -d= -f2-)"
            done
            printf '  输入快照 ID: '; read -r sid
            ar_snapshot_rollback "$sid" && echo "  已回滚" || echo "  回滚失败";;
        11) list_modules
            printf '  输入模块 ID: '; read -r sid
            for f in $(find "$MODULES_DIR/$sid" -maxdepth 3 -name '*.sh' 2>/dev/null | head -n 20); do
                ar_scan_file "$f" "$(basename "$f")" "$AR_TMP/m.find" 2>/dev/null
            done
            sc=$(ar_score_of "$AR_TMP/m.find"); echo "  风险得分: $sc ($(ar_level_of "$sc"))"
            rm -f "$AR_TMP/m.find" 2>/dev/null;;
        12) sh "$MODDIR/common/api.sh" scanall 2>/dev/null | tr ',' '\n' | grep -E 'name|score' | head -n 40;;
        13) ar_guard_check >/dev/null 2>&1; echo "  巡检完成, 异常项: $(ar_state_get guard_last_events)"
            printf '  重建基线? (y/N): '; read -r yn
            [ "$yn" = "y" ] && ar_guard_baseline && echo "  基线已重建";;
        14) tail -n 30 "$AR_DATA/guard/events" 2>/dev/null || echo "  (无记录)";;
        15) ar_rescue_now 3 "手动救援 L3"; echo "  完成, 请重启";;
        0) exit 0;;
        *) echo "  无效选项";;
    esac
done
