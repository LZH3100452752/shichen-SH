#!/system/bin/sh
# =====================================================================
#  AutoRescue · 安装脚本 (customize.sh)
#  作者: 时尘  v2.6
# =====================================================================

MODPATH="${MODPATH:-${0%/*}}"
export MODPATH

ui_print() { echo "$@"; }

# 版本号从 module.prop 实时读取, 避免硬编码后忘记同步
ui_ver=$(grep -m1 '^version=' "$MODPATH/module.prop" 2>/dev/null | cut -d= -f2 | tr -d '\r')
[ -z "$ui_ver" ] && ui_ver=$(grep -m1 '^AR_VER=' "$MODPATH/common/functions.sh" 2>/dev/null | cut -d= -f2 | tr -d '"')
[ -z "$ui_ver" ] && ui_ver="v2.6"

# ---------------------------------------------------------------- 进度条
# 用 [####------] 形式的进度条, 每步推进一格, 让安装过程看起来在实时反馈
AR_TOTAL=8
AR_CUR=0

_ar_bar() {
    local i filled empty
    filled=$1
    [ "$filled" -gt "$AR_TOTAL" ] && filled=$AR_TOTAL
    [ "$filled" -lt 0 ] && filled=0
    empty=$((AR_TOTAL - filled))
    local s=""
    i=0
    while [ "$i" -lt "$filled" ]; do s="$s█"; i=$((i+1)); done
    i=0
    while [ "$i" -lt "$empty" ]; do s="$s░"; i=$((i+1)); done
    printf '%s' "$s"
}

# 打印一步: 进度条 + 百分比 + 说明
step() {
    AR_CUR=$((AR_CUR + 1))
    local pct=$((AR_CUR * 100 / AR_TOTAL))
    ui_print "  [$(_ar_bar "$AR_CUR")] ${pct}%  $1"
}

ui_print ""
ui_print "  ╔══════════════════════════════════════════════╗"
ui_print "  ║                                              ║"
ui_print "  ║      AutoRescue · 自动救砖守护               ║"
ui_print "  ║              作者: 时尘   $ui_ver             ║"
ui_print "  ║                                              ║"
ui_print "  ╚══════════════════════════════════════════════╝"
ui_print ""

# ---------------------------------------------------------------- 1 环境
ui_print "  ── 环境检测 ─────────────────────────────────"
SDK=$(getprop ro.build.version.sdk 2>/dev/null)
case "$SDK" in ''|*[!0-9]*) SDK="";; esac
if [ -n "$SDK" ] && [ "$SDK" -lt 26 ]; then
    ui_print "  ! Android 版本偏低 (SDK $SDK), 部分功能可能受限"
fi

IMPL="Magisk"
if [ -d /data/adb/ap ] || [ -x /data/adb/apd ]; then IMPL="APatch"
elif [ -d /data/adb/ksu ] || [ -x /data/adb/ksud ]; then IMPL="KernelSU"
elif [ -d /data/adb/magisk ]; then IMPL="Magisk"; fi

step "Root 实现: $IMPL"

# ---------------------------------------------------------------- 2 完整性
MISSING=""
for f in post-fs-data.sh service.sh common/functions.sh common/rescue.sh \
         common/api.sh common/scan.sh common/guard.sh webroot/index.html \
         webroot/cgi-bin/api webroot/assets/js/app.js; do
    [ -f "$MODPATH/$f" ] || MISSING="$MISSING $f"
done
if [ -n "$MISSING" ]; then
    ui_print "  ! 警告: 以下文件缺失$MISSING"
fi
step "文件完整性检查"

# ---------------------------------------------------------------- 3 权限
chmod -R 0755 "$MODPATH" 2>/dev/null
for f in post-fs-data.sh service.sh boot-completed.sh action.sh uninstall.sh \
         common/functions.sh common/rescue.sh common/watchdog.sh common/api.sh \
         common/scan.sh common/guard.sh \
         webroot/cgi-bin/api tools/rescue.sh; do
    [ -f "$MODPATH/$f" ] && chmod 0755 "$MODPATH/$f" 2>/dev/null
done
chmod 0644 "$MODPATH/module.prop" 2>/dev/null
step "设置执行权限"

# ---------------------------------------------------------------- 4 数据目录
mkdir -p /data/adb/auto_rescue/state 2>/dev/null
mkdir -p /data/adb/auto_rescue/log 2>/dev/null
mkdir -p /data/adb/auto_rescue/snapshots 2>/dev/null
mkdir -p /data/adb/auto_rescue/queue 2>/dev/null
mkdir -p /data/adb/auto_rescue/tmp 2>/dev/null
mkdir -p "$MODPATH/webroot/data" 2>/dev/null
mkdir -p "$MODPATH/webroot/assets/img" 2>/dev/null
chmod -R 0755 /data/adb/auto_rescue 2>/dev/null
step "初始化数据目录"

# ---------------------------------------------------------------- 5 配置
if [ ! -f /data/adb/auto_rescue/config.conf ]; then
    MODDIR="$MODPATH" sh -c ". $MODPATH/common/functions.sh; ar_init_dirs; ar_conf_defaults" 2>/dev/null
    step "生成默认配置"
else
    step "保留已有配置(升级不影响设置)"
fi

# ---------------------------------------------------------------- 6 白名单
if [ ! -f /data/adb/auto_rescue/whitelist ]; then
    : > /data/adb/auto_rescue/whitelist 2>/dev/null
fi
grep -qx "auto_rescue" /data/adb/auto_rescue/whitelist 2>/dev/null || \
    echo "auto_rescue" >> /data/adb/auto_rescue/whitelist 2>/dev/null
step "守护自身加入白名单"

# ---------------------------------------------------------------- 7 自检
if MODDIR="$MODPATH" sh -c ". $MODPATH/common/functions.sh" 2>/dev/null; then
    step "核心脚本自检通过"
else
    ui_print "  ! 核心脚本自检异常, 请检查模块包是否完整"
    step "核心脚本自检"
fi

# ---------------------------------------------------------------- 8 清理旧缓存
rm -f /data/adb/auto_rescue/state/devcache.json 2>/dev/null
rm -f /data/adb/auto_rescue/tmp/*.json 2>/dev/null
step "清理旧缓存"

ui_print ""
ui_print "  [$(_ar_bar "$AR_TOTAL")] 100%  安装完成"
ui_print ""

# ---------------------------------------------------------------- 说明
ui_print "  ── 打开界面 ─────────────────────────────────"
ui_print "  · 点模块卡片上的「执行 / Action」按钮即可打开 WebUI"
ui_print "  · KernelSU / APatch / MMRL 支持直接内嵌渲染"
ui_print "  · 命令行: sh /data/adb/modules/auto_rescue/common/api.sh status"
ui_print "  · 手动救援: sh /data/adb/modules/auto_rescue/tools/rescue.sh"
ui_print ""
ui_print "  ── 默认策略 ─────────────────────────────────"
ui_print "  连续 3 次启动未进桌面 → 自动分级禁用模块"
ui_print "  L1 全部非白名单 → L2 含白名单 → L3 彻底移除挂载"
ui_print ""
ui_print "  ── 本次更新 ─────────────────────────────────"
ui_print "  · 【严重】修复打开界面即卡死至需强制重启"
ui_print "    云端检测串行访问多个源, 单源超时过长"
ui_print "    KernelSU 同步阻塞主线程, 界面完全无响应"
ui_print "    现为单源 3 秒 + 全局预算, 实测降到 2 秒"
ui_print "  · 【严重】修复检测脚本时卡死"
ui_print "    超过 512KB 只扫前 512KB(4MB 文件 50s → 2s)"
ui_print "  · 修复 KernelSU 打开界面慢"
ui_print "    设备信息缓存 20 秒 → 10 分钟"
ui_print "  · 修复云端已改版本却检测不到"
ui_print "    改为遍历全部源取最大版本号"
ui_print "  · 修复有更新时点检测更新报错"
ui_print "  · 修复守护目录添加/移除不立即刷新"
ui_print "  · 设置改为自动保存, 移除手动保存按钮"
ui_print "  · 更新分下载/安装两段进度, 装完自动清理"
ui_print "  · 救援等级精简为 L1 / L2 / L3 三级"
ui_print ""
ui_print "  ── 云更新 ───────────────────────────────────"
ui_print "  · 打开界面自动静默检测, 有新版才弹窗"
ui_print "  · 支持强制更新版本 / 源连通性测试"
ui_print "  · 内置 4 个源, 自动取版本号最大的那份"
ui_print ""
ui_print "  问题反馈: 3100452752@qq.com"
ui_print ""
ui_print "  [√] 安装完成, 建议重启一次使守护完全生效"
ui_print ""

exit 0
