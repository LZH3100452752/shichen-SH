#!/system/bin/sh
# =====================================================================
#  AutoRescue · 重要目录/分区守护  v2.5
#
#  能力边界(务必看清):
#    ✓ 能做: 关键路径存在性监控 / 文件数量基线比对 / 异常消失事件记录
#            / 告警 / 可写目录的快照备份与尽力恢复 / 自定义守护清单
#    ✗ 做不到: 内核级实时拦截 rm 系统调用(需 hook syscall 或 inotify 常驻守护,
#              在 Android 上无法保证全时段生效, 且风险极高)
#    因此本模块采取"高频巡检 + 立刻记录 + 尽力恢复"的策略,
#    能在文件被删后第一时间发现并留下证据, 对可备份的目录可回滚。
#
#  作者: 时尘
# =====================================================================

. "${MODDIR:-/data/adb/modules/auto_rescue}/common/functions.sh" 2>/dev/null || exit 0

AR_GUARD_DIR="$AR_DATA/guard"
AR_GUARD_PATHS="$AR_GUARD_DIR/paths"
AR_GUARD_BASE="$AR_GUARD_DIR/baseline"
AR_GUARD_EVENTS="$AR_GUARD_DIR/events"
AR_GUARD_BACKUP="$AR_GUARD_DIR/backup"

# 默认守护清单: 关键系统分区/目录 + 用户数据 + 模块目录
AR_GUARD_DEFAULT="/system/bin
/system/framework
/system/etc
/system/lib64
/system/build.prop
/vendor
/vendor/bin
/product
/data/adb
/data/adb/modules
/data/data
/data/system
/data/misc
/sdcard/DCIM
/sdcard/Download
/sdcard/Pictures
/storage/emulated/0/DCIM"

ar_guard_init() {
    mkdir -p "$AR_GUARD_DIR" "$AR_GUARD_BACKUP" 2>/dev/null
    if [ ! -f "$AR_GUARD_PATHS" ]; then
        printf '%s\n' "$AR_GUARD_DEFAULT" > "$AR_GUARD_PATHS" 2>/dev/null
    fi
    [ -f "$AR_GUARD_EVENTS" ] || : > "$AR_GUARD_EVENTS" 2>/dev/null
}

# ---------- 守护清单 ----------
ar_guard_list() {
    ar_guard_init
    grep -v '^$' "$AR_GUARD_PATHS" 2>/dev/null
}

ar_guard_add() {
    local p="$1"
    [ -n "$p" ] || return 1
    ar_guard_init
    grep -Fxq "$p" "$AR_GUARD_PATHS" 2>/dev/null || printf '%s\n' "$p" >> "$AR_GUARD_PATHS"
    return 0
}

ar_guard_del() {
    local p="$1"
    ar_guard_init
    grep -Fxv "$p" "$AR_GUARD_PATHS" > "$AR_GUARD_PATHS.tmp" 2>/dev/null \
        && mv "$AR_GUARD_PATHS.tmp" "$AR_GUARD_PATHS"
    # 关键修复: 界面显示的是"基线"里的内容, 而旧代码只删了清单(paths),
    # 基线里仍留着这条 -> 表现为"点了移除却移不掉"。
    # 这里同步把该路径从基线中剔除。
    if [ -s "$AR_GUARD_BASE" ]; then
        grep -v "^$p|" "$AR_GUARD_BASE" > "$AR_GUARD_BASE.tmp" 2>/dev/null \
            && mv "$AR_GUARD_BASE.tmp" "$AR_GUARD_BASE" 2>/dev/null
    fi
    return 0
}

# ---------- 并发锁 ----------
# watchdog(每 30s)与 WebUI(CGI)都可能触发巡检。两者同时建基线会把
# du/ls 叠加在同一批大目录上, 直接把 CPU 和 IO 打满 -> 整机卡死。
# 用 mkdir 的原子性做锁, 拿不到就直接跳过本次。
ar_guard_lock() {
    local d="$AR_GUARD_DIR/.lock" i=0
    ar_guard_init
    while [ "$i" -lt 3 ]; do
        if mkdir "$d" 2>/dev/null; then
            echo $$ > "$d/pid" 2>/dev/null
            return 0
        fi
        # 持锁进程已死 -> 清理僵尸锁
        op=$(cat "$d/pid" 2>/dev/null)
        if [ -n "$op" ] && [ ! -d "/proc/$op" ]; then
            rm -rf "$d" 2>/dev/null; continue
        fi
        i=$((i+1)); sleep 1
    done
    return 1
}
ar_guard_unlock() { rm -rf "$AR_GUARD_DIR/.lock" 2>/dev/null; return 0; }

# ---------- 安全计数 ----------
# 只统计【一级】条目数, 绝不递归。
# 之前基线里用 du -sk 递归统计体积: /vendor /product /data/data
# /system/lib64 这类目录有上万文件, 手机上一次 du 就要几十秒,
# CPU 与 IO 瞬间打满 —— 这是"打开 UI 后整机卡死"的根因。
# 另外: 旧实现先 ": > 基线" 清空再逐条写, 一旦 du 卡住被杀就留下
# 一个空基线, 下次巡检又会重跑 du, 形成"永远在建基线"的死循环。
ar_guard_count() {
    local p="$1" n
    if [ -d "$p" ]; then
        n=$(ls -1 "$p" 2>/dev/null | wc -l | tr -d ' ')
    elif [ -e "$p" ]; then
        n=1
    else
        n=0
    fi
    case "$n" in ''|*[!0-9]*) n=0;; esac
    printf '%s' "$n"
}

# ---------- 基线 ----------
# 记录: path|type|count|0   (size 字段保留但恒为 0, 不再做 du)
ar_guard_baseline() {
    ar_guard_init
    local p cnt typ tmp="$AR_GUARD_DIR/baseline.tmp.$$"
    # 原子写: 先写临时文件, 写完再 mv。避免中途失败留下空/半截基线
    : > "$tmp" 2>/dev/null
    while IFS= read -r p; do
        [ -n "$p" ] || continue
        if [ -d "$p" ]; then
            typ="dir"; cnt=$(ar_guard_count "$p")
        elif [ -e "$p" ]; then
            typ="file"; cnt=1
        else
            typ="missing"; cnt=0
        fi
        [ -z "$cnt" ] && cnt=0
        printf '%s|%s|%s|0\n' "$p" "$typ" "$cnt" >> "$tmp" 2>/dev/null
    done <<EOF
$(ar_guard_list)
EOF
    # 只有写成功(非空)才替换正式基线
    if [ -s "$tmp" ]; then
        mv "$tmp" "$AR_GUARD_BASE" 2>/dev/null
    else
        rm -f "$tmp" 2>/dev/null
    fi
    ar_state_set guard_baseline_time "$(ar_now)"
    ar_log INFO "守护基线已建立 ($(wc -l < "$AR_GUARD_BASE" 2>/dev/null | tr -d ' ') 条)"
    return 0
}

# ---------- 事件记录 ----------
ar_guard_event() {
    local kind="$1" path="$2" desc="$3"
    ar_guard_init
    printf '%s|%s|%s|%s\n' "$(ar_ts)" "$kind" "$path" "$(ar_json_esc "$desc")" >> "$AR_GUARD_EVENTS" 2>/dev/null
    tail -n 300 "$AR_GUARD_EVENTS" > "$AR_GUARD_EVENTS.tmp" 2>/dev/null \
        && mv "$AR_GUARD_EVENTS.tmp" "$AR_GUARD_EVENTS"
    ar_log WARN "[守护] $kind: $path - $desc"
}

# ---------- 巡检 ----------
# 返回: 事件数
ar_guard_check() {
    ar_guard_init
    # 拿不到锁说明正有另一个进程在巡检(常见: watchdog 与 WebUI 同时),
    # 直接跳过本次, 绝不叠加
    ar_guard_lock || { printf '0'; return 0; }

    [ -s "$AR_GUARD_BASE" ] || { ar_guard_baseline; ar_guard_unlock; printf '0'; return 0; }
    local events=0 p typ cnt sz nt nc ns
    while IFS='|' read -r p typ cnt sz; do
        [ -n "$p" ] || continue
        # 当前状态(一级计数, 不递归)
        if [ -d "$p" ]; then
            nt="dir"
            nc=$(ar_guard_count "$p")
        elif [ -e "$p" ]; then
            nt="file"; nc=1
        else
            nt="missing"; nc=0
        fi
        [ -z "$nc" ] && nc=0
        [ -z "$cnt" ] && cnt=0

        if [ "$typ" = "missing" ]; then
            # 建基线时该路径就不存在(设备无此分区/未挂载), 不算被破坏
            [ "$nt" != "missing" ] && ar_guard_event "RECOVER" "$p" "基线时缺失的路径现在出现了"
        elif [ "$nt" = "missing" ]; then
            # 原本存在, 现在消失: 高危
            ar_guard_event "MISSING" "$p" "受保护路径已消失 (基线: $typ, 条目 $cnt)"
            events=$((events+1))
        elif [ "$typ" = "dir" ] && [ "$cnt" -gt 0 ] && [ "$nc" -lt "$cnt" ]; then
            # 文件数骤减
            local drop=$(( (cnt - nc) * 100 / cnt ))
            if [ "$drop" -ge 30 ]; then
                ar_guard_event "SHRINK" "$p" "条目数由 $cnt 降至 $nc (减少 ${drop}%)"
                events=$((events+1))
            fi
        fi
    done < "$AR_GUARD_BASE"

    # 顺带记录可疑的"正在删除关键路径"的进程(尽力而为)
    ar_guard_scan_proc

    ar_state_set guard_last_check "$(ar_now)"
    ar_state_set guard_last_events "$events"
    ar_guard_unlock
    printf '%s' "$events"
}

# ---------- 检测正在执行删除操作的进程 ----------
ar_guard_scan_proc() {
    [ "$(ar_conf_get guard_proc_scan 1)" = "1" ] || return 0
    local pid cmd hit=0 self=$$
    local scanned=0
    for d in /proc/[0-9]*; do
        pid="${d#/proc/}"
        case "$pid" in ''|*[!0-9]*) continue;; esac
        [ "$pid" = "$self" ] && continue
        [ "$hit" -ge 3 ] && break
        # 最多扫 120 个进程: 进程多时全量遍历会拖慢巡检
        scanned=$((scanned+1)); [ "$scanned" -gt 120 ] && break
        cmd=$(tr '\0' ' ' < "$d/cmdline" 2>/dev/null)
        [ -n "$cmd" ] || continue
        # 排除本模块自身的进程, 避免自报
        case "$cmd" in
            *auto_rescue*|*guard.sh*|*rescue.sh*|*watchdog.sh*) continue;;
        esac
        case "$cmd" in
            *"rm -rf /data"*|*"rm -rf /system"*|*"rm -rf /sdcard"*|*"rm -rf /storage"*|*"rm -rf /data/media"*|*"rm -rf / "*|*"rm -rf /*"*)
                ar_guard_event "PROC" "$pid" "检测到进程正在删除关键路径: $(printf '%s' "$cmd" | cut -c1-90)"
                hit=$((hit+1))
                ;;
        esac
    done
    return 0
}

# ---------- 备份(仅对可写目录, 备份模块开关与文件清单) ----------
ar_guard_backup() {
    ar_guard_init
    local tag="${1:-manual}" id f
    id="gbak_$(ar_ts)"
    f="$AR_GUARD_BACKUP/$id.list"
    : > "$f" 2>/dev/null
    # 备份模块启用状态(最有价值)
    local d
    for d in $(ar_module_dirs); do
        printf '%s|%s|%s\n' "$(basename "$d")" "$(ar_module_enabled "$d")" "$(ar_prop "$d" name "$(basename "$d")")" >> "$f" 2>/dev/null
    done
    # 备份守护清单当前快照
    ar_guard_baseline
    cp "$AR_GUARD_BASE" "$AR_GUARD_BACKUP/$id.base" 2>/dev/null
    printf 'id=%s\ntime=%s\ntag=%s\n' "$id" "$(ar_now)" "$tag" > "$AR_GUARD_BACKUP/$id.meta" 2>/dev/null
    ar_log INFO "守护备份已创建: $id ($tag)"
    printf '%s' "$id"
}

ar_guard_restore() {
    local id="$1"
    [ -f "$AR_GUARD_BACKUP/$id.list" ] || return 1
    local line mid en d
    while IFS='|' read -r mid en rest; do
        [ -z "$mid" ] && continue
        [ "$mid" = "$AR_ID" ] && continue
        d="$MODULES_DIR/$mid"
        [ -d "$d" ] || continue
        if [ "$en" = "1" ]; then rm -f "$d/disable" 2>/dev/null; else : > "$d/disable" 2>/dev/null; fi
    done < "$AR_GUARD_BACKUP/$id.list"
    ar_log INFO "已从守护备份恢复: $id"
    return 0
}

# ---------- 只读加固(尽力而为) ----------
# 对支持 chattr +i 的文件系统加不可变属性; 不支持则跳过
ar_guard_harden() {
    local c="$CHATTR" ok=0 fail=0 p
    for c in /system/bin/chattr /data/adb/magisk/busybox /system/xbin/busybox; do
        [ -x "$c" ] && break
        c=""
    done
    [ -z "$c" ] && { ar_log INFO "无 chattr, 跳过只读加固"; return 1; }
    while IFS= read -r p; do
        [ -e "$p" ] || continue
        if [ -x "$c" ] && [ "$c" != "${c%busybox}" ]; then
            "$c" chattr +i "$p" >/dev/null 2>&1 && ok=$((ok+1)) || fail=$((fail+1))
        else
            "$c" +i "$p" >/dev/null 2>&1 && ok=$((ok+1)) || fail=$((fail+1))
        fi
    done <<EOF
$(ar_guard_list)
EOF
    ar_log INFO "只读加固: 成功 $ok, 不支持/失败 $fail"
    printf '%s' "$ok"
}

# ---------- JSON 输出 ----------
ar_guard_status_json() {
    ar_guard_init
    local p typ cnt sz nt nc st
    local first=1
    printf '['
    if [ -s "$AR_GUARD_BASE" ]; then
        while IFS='|' read -r p typ cnt sz; do
            [ -n "$p" ] || continue
            if [ -d "$p" ]; then nt="dir"; nc=$(ls -1 "$p" 2>/dev/null | wc -l | tr -d ' ')
            elif [ -e "$p" ]; then nt="file"; nc=1
            else nt="missing"; nc=0; fi
            [ -z "$nc" ] && nc=0
            if [ "$typ" = "missing" ]; then
                if [ "$nt" = "missing" ]; then st="nobase"; else st="ok"; fi
            elif [ "$nt" = "missing" ]; then st="missing"
            elif [ "$typ" = "dir" ] && [ "$cnt" -gt 0 ] && [ "$nc" -lt "$cnt" ]; then st="shrink"
            else st="ok"; fi
            [ "$first" = "1" ] && first=0 || printf ','
            printf '{"path":"%s","base_type":"%s","base_count":%s,"now_count":%s,"state":"%s"}' \
                "$(ar_json_esc "$p")" "$typ" "${cnt:-0}" "$nc" "$st"
        done < "$AR_GUARD_BASE"
    else
        while IFS= read -r p; do
            [ -n "$p" ] || continue
            if [ -d "$p" ]; then nt="dir"; nc=$(ls -1 "$p" 2>/dev/null | wc -l | tr -d ' ')
            elif [ -e "$p" ]; then nt="file"; nc=1
            else nt="missing"; nc=0; fi
            [ -z "$nc" ] && nc=0
            [ "$nt" = "missing" ] && st="missing" || st="ok"
            [ "$first" = "1" ] && first=0 || printf ','
            printf '{"path":"%s","base_type":"%s","base_count":0,"now_count":%s,"state":"%s"}' \
                "$(ar_json_esc "$p")" "$nt" "$nc" "$st"
        done <<EOF
$(ar_guard_list)
EOF
    fi
    printf ']'
}

ar_guard_events_json() {
    ar_guard_init
    local first=1 ts kind path desc
    printf '['
    tail -n 60 "$AR_GUARD_EVENTS" 2>/dev/null | while IFS='|' read -r ts kind path desc; do
        [ -n "$ts" ] || continue
        [ "$first" = "1" ] && first=0 || printf ','
        printf '{"ts":%s,"time":"%s","kind":"%s","path":"%s","desc":"%s"}' \
            "$ts" "$(date -d "@$ts" '+%m-%d %H:%M' 2>/dev/null || echo "$ts")" \
            "$(ar_json_esc "$kind")" "$(ar_json_esc "$path")" "$(ar_json_esc "$desc")"
    done
    printf ']'
}

ar_guard_backups_json() {
    ar_guard_init
    local first=1 f id t tag
    printf '['
    for f in $(ls -1t "$AR_GUARD_BACKUP"/*.meta 2>/dev/null); do
        id=$(grep -m1 '^id=' "$f" | cut -d= -f2-)
        t=$(grep -m1 '^time=' "$f" | cut -d= -f2-)
        tag=$(grep -m1 '^tag=' "$f" | cut -d= -f2-)
        [ "$first" = "1" ] && first=0 || printf ','
        printf '{"id":"%s","time":"%s","tag":"%s"}' "$(ar_json_esc "$id")" "$(ar_json_esc "$t")" "$(ar_json_esc "$tag")"
    done
    printf ']'
}
