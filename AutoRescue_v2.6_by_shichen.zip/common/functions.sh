#!/system/bin/sh
# =====================================================================
#  AutoRescue · 自动救砖守护  —  公共函数库
#  作者: 时尘   版本: v2.6
#  兼容: Magisk / KernelSU / APatch  (Android 8.0+)
# =====================================================================

AR_ID="auto_rescue"
AR_NAME="AutoRescue"
AR_VER="v2.6"
AR_AUTHOR="时尘"

: "${MODDIR:=/data/adb/modules/$AR_ID}"

AR_DATA="/data/adb/auto_rescue"
AR_CONF="$AR_DATA/config.conf"
AR_STATE="$AR_DATA/state"
AR_LOGDIR="$AR_DATA/log"
AR_LOG="$AR_LOGDIR/rescue.log"
AR_SNAP="$AR_DATA/snapshots"
AR_QUEUE="$AR_DATA/queue"
AR_TMP="$AR_DATA/tmp"
AR_BACKUP="$AR_DATA/backup"
AR_TOOLS="$AR_DATA/tools"
MODULES_DIR="/data/adb/modules"

# ---------- 基础工具 ----------
ar_now() { date '+%Y-%m-%d %H:%M:%S'; }
ar_ts()  { date '+%s'; }

ar_mkdir() { [ -d "$1" ] || mkdir -p "$1" 2>/dev/null; }

ar_init_dirs() {
    local d
    for d in "$AR_DATA" "$AR_STATE" "$AR_LOGDIR" "$AR_SNAP" "$AR_QUEUE" "$AR_TMP" "$AR_TOOLS"; do
        ar_mkdir "$d"
        chmod 0755 "$d" 2>/dev/null
    done
    [ -f "$AR_LOG" ] || : > "$AR_LOG"
    chmod 0644 "$AR_LOG" 2>/dev/null
}

# 取 busybox
ar_busybox() {
    local b
    for b in /data/adb/magisk/busybox /data/adb/ksu/bin/busybox /data/adb/ap/bin/busybox \
             /data/adb/modules/$AR_ID/bin/busybox /system/bin/busybox /system/xbin/busybox; do
        [ -x "$b" ] && { echo "$b"; return 0; }
    done
    echo ""
}
BB="$(ar_busybox)"

# ---------- 日志 ----------
ar_log() {
    local lvl="$1"; shift
    ar_mkdir "$AR_LOGDIR"
    printf '[%s][%s] %s\n' "$(ar_now)" "$lvl" "$*" >> "$AR_LOG"
    # 日志体积控制: 保留最后 1500 行
    local n
    n=$(wc -l < "$AR_LOG" 2>/dev/null | tr -d ' ')
    if [ -n "$n" ] && [ "$n" -gt 1500 ] 2>/dev/null; then
        tail -n 1200 "$AR_LOG" > "$AR_LOG.tmp" 2>/dev/null && mv "$AR_LOG.tmp" "$AR_LOG"
    fi
    log -t AutoRescue -p i "$*" >/dev/null 2>&1
}

# ---------- 配置读写 ----------
ar_conf_get() {
    local k="$1" d="$2" v=""
    [ -f "$AR_CONF" ] && v=$(grep -m1 "^$k=" "$AR_CONF" 2>/dev/null | cut -d= -f2-)
    [ -z "$v" ] && v="$d"
    printf '%s' "$v"
}

ar_conf_set() {
    local k="$1" v="$2"
    ar_mkdir "$AR_DATA"
    [ -f "$AR_CONF" ] || : > "$AR_CONF"
    if grep -q "^$k=" "$AR_CONF" 2>/dev/null; then
        sed -i "s|^$k=.*|$k=$v|" "$AR_CONF" 2>/dev/null
    else
        printf '%s=%s\n' "$k" "$v" >> "$AR_CONF"
    fi
}

# 写入默认配置(只补缺失项)
# 排除名单: 比白名单更强 —— 任何等级(含 L2/L3)都不会动这些模块
AR_EXCLUDE="$AR_DATA/exclude"

ar_is_excluded() {
    local id="$1"
    [ -z "$id" ] && return 1
    grep -qx "$id" "$AR_EXCLUDE" 2>/dev/null
}

ar_exclude_add() {
    local id="$1"
    [ -z "$id" ] && return 1
    ar_is_excluded "$id" && return 0
    printf '%s\n' "$id" >> "$AR_EXCLUDE" 2>/dev/null
    chmod 0644 "$AR_EXCLUDE" 2>/dev/null
    return 0
}

ar_exclude_del() {
    local id="$1" tmp
    [ -z "$id" ] && return 1
    tmp="$AR_TMP/exc.$$"
    grep -vx "$id" "$AR_EXCLUDE" 2>/dev/null > "$tmp" 2>/dev/null
    mv "$tmp" "$AR_EXCLUDE" 2>/dev/null
    chmod 0644 "$AR_EXCLUDE" 2>/dev/null
    return 0
}

ar_conf_defaults() {
    ar_mkdir "$AR_DATA"
    [ -f "$AR_CONF" ] || : > "$AR_CONF"
    local line k v
    while IFS='=' read -r k v; do
        [ -z "$k" ] && continue
        case "$k" in \#*) continue;; esac
        grep -q "^$k=" "$AR_CONF" 2>/dev/null || printf '%s=%s\n' "$k" "$v" >> "$AR_CONF"
    done <<'EOF'
auto_rescue=1
boot_threshold=3
confirm_delay=90
boot_timeout=180
max_round=3
protect_self=1
whitelist=
auto_snapshot=1
snapshot_keep=10
watchdog=1
monitor_systemserver=1
monitor_zygote=1
webui_port=8080
webui_autostart=1
webui_token=1
safe_confirm=1
notify=1
log_level=2
module_auto_backup=1
conflict_scan_onboot=0
rescue_notify_file=1
guard_enable=1
guard_interval=30
guard_proc_scan=1
guard_autobackup=1
auto_scan_new=1
auto_quarantine_danger=0
danger_score=60
allow_terminal=1
exclude=
splash_enable=1
anim_enable=1
metal_theme=1
rescue_after_snapshot=1
log_keep_days=7
sort_mode=time
confirm_before_rescue=1
auto_disable_danger=0
boot_sound_notify=0
compact_mode=0
update_auto=1
EOF
    chmod 0644 "$AR_CONF" 2>/dev/null
}

# ---------- 状态文件 ----------
ar_state_get() { cat "$AR_STATE/$1" 2>/dev/null; }
ar_state_set() { ar_mkdir "$AR_STATE"; printf '%s' "$2" > "$AR_STATE/$1"; }

ar_boot_count() {
    local c
    c=$(ar_state_get boot_count)
    case "$c" in ''|*[!0-9]*) c=0;; esac
    printf '%s' "$c"
}

# ---------- 白名单 ----------
ar_is_whitelisted() {
    local id="$1"
    [ "$id" = "$AR_ID" ] && return 0                 # 永远保护自己
    [ "$(ar_conf_get protect_self 1)" = "1" ] && [ "$id" = "$AR_ID" ] && return 0
    grep -qx "$id" "$AR_DATA/whitelist" 2>/dev/null && return 0
    return 1
}

ar_whitelist_list() {
    grep -v '^$' "$AR_DATA/whitelist" 2>/dev/null
}

# ---------- 模块属性 ----------
ar_prop() { # dir key default
    local v
    v=$(grep -m1 "^$2=" "$1/module.prop" 2>/dev/null | cut -d= -f2-)
    [ -z "$v" ] && v="$3"
    printf '%s' "$v"
}

# 列出模块目录(未禁用 + 已禁用), 按修改时间倒序(最近安装优先)
ar_module_dirs() {
    local d
    for d in $(ls -1td "$MODULES_DIR"/*/ 2>/dev/null); do
        d="${d%/}"
        [ -f "$d/module.prop" ] || continue
        printf '%s\n' "$d"
    done
}

ar_module_enabled() { [ -f "$1/disable" ] && echo 0 || echo 1; }

ar_disable_module() {
    local d="$1"
    [ -d "$d" ] || return 1
    : > "$d/disable" 2>/dev/null || return 1
    # 记录由本模块禁用, 便于卸载时恢复 / 展示
    echo "$(basename "$d")" >> "$AR_STATE/disabled_by_us" 2>/dev/null
    ar_log WARN "已禁用模块: $(ar_prop "$d" name "$(basename "$d")") [$(basename "$d")]"
    return 0
}

ar_enable_module() {
    local d="$1"
    [ -d "$d" ] || return 1
    rm -f "$d/disable" 2>/dev/null
    grep -vx "$(basename "$d")" "$AR_STATE/disabled_by_us" > "$AR_STATE/disabled_by_us.tmp" 2>/dev/null \
        && mv "$AR_STATE/disabled_by_us.tmp" "$AR_STATE/disabled_by_us"
    ar_log INFO "已启用模块: $(ar_prop "$d" name "$(basename "$d")") [$(basename "$d")]"
    return 0
}

# 极端手段: 重命名模块目录, 让 root 实现完全看不到它
ar_quarantine_module() {
    local d="$1"
    [ -d "$d" ] || return 1
    case "$d" in *.ar_quarantine) return 0;; esac
    mv "$d" "$d.ar_quarantine" 2>/dev/null || return 1
    echo "$(basename "$d")" >> "$AR_STATE/quarantined" 2>/dev/null
    ar_log WARN "已隔离(移除挂载)模块: $(basename "$d")"
    return 0
}

ar_restore_quarantine() {
    local d
    for d in "$MODULES_DIR"/*.ar_quarantine; do
        [ -d "$d" ] || continue
        local t="${d%.ar_quarantine}"
        mv "$d" "$t" 2>/dev/null && ar_log INFO "已解除隔离: $(basename "$t")"
    done
    : > "$AR_STATE/quarantined" 2>/dev/null
}

# ---------- 快照 ----------
ar_snapshot_create() {
    local tag="$1"
    local id ts f
    ar_mkdir "$AR_SNAP"
    id="snap_$(ar_ts)"
    ts="$(ar_now)"
    f="$AR_SNAP/$id.list"
    : > "$f"
    local d
    for d in $(ls -1td "$MODULES_DIR"/*/ 2>/dev/null); do
        d="${d%/}"
        [ -f "$d/module.prop" ] || continue
        printf '%s|%s|%s\n' "$(basename "$d")" "$(ar_module_enabled "$d")" "$(ar_prop "$d" name "$(basename "$d")")" >> "$f"
    done
    {
        printf 'id=%s\n' "$id"
        printf 'time=%s\n' "$ts"
        printf 'tag=%s\n' "${tag:-manual}"
        printf 'count=%s\n' "$(wc -l < "$f" | tr -d ' ')"
    } > "$AR_SNAP/$id.meta"
    # 清理旧快照
    local keep; keep=$(ar_conf_get snapshot_keep 10)
    case "$keep" in ''|*[!0-9]*) keep=10;; esac
    ls -1t "$AR_SNAP"/*.meta 2>/dev/null | tail -n +$((keep+1)) | while read -r m; do
        rm -f "$m" "${m%.meta}.list" 2>/dev/null
    done
    ar_log INFO "已创建快照 $id (${tag:-manual})"
    printf '%s' "$id"
}

ar_snapshot_rollback() {
    local id="$1"
    [ -f "$AR_SNAP/$id.list" ] || return 1
    local line mid en d
    while IFS='|' read -r mid en rest; do
        [ -z "$mid" ] && continue
        [ "$mid" = "$AR_ID" ] && continue
        d="$MODULES_DIR/$mid"
        [ -d "$d" ] || continue
        if [ "$en" = "1" ]; then rm -f "$d/disable" 2>/dev/null; else : > "$d/disable" 2>/dev/null; fi
    done < "$AR_SNAP/$id.list"
    ar_log INFO "已回滚到快照 $id"
    return 0
}

# ---------- 重启 ----------
ar_reboot() {
    local why="${1:-rescue}"
    ar_log WARN "执行重启 ($why)"
    sync 2>/dev/null
    # 留下可读的标记, 便于 recovery / adb 排查
    printf '%s\n%s\n' "$(ar_now)" "$why" > "$AR_STATE/last_reboot_reason" 2>/dev/null
    setprop sys.powerctl "reboot,$why" >/dev/null 2>&1
    sleep 2
    setprop sys.powerctl reboot >/dev/null 2>&1
    sleep 2
    /system/bin/reboot >/dev/null 2>&1
    reboot >/dev/null 2>&1
    reboot -f >/dev/null 2>&1
    return 0
}

# ---------- JSON 转义 ----------
ar_json_esc() {
    printf '%s' "$1" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g' -e 's/	/\\t/g' | tr '\n\r' '  '
}

# ---------- root 实现识别 ----------
ar_root_impl() {
    if [ -d /data/adb/ap ] || [ -x /data/adb/apd ]; then echo "APatch"
    elif [ -d /data/adb/ksu ] || [ -x /data/adb/ksud ]; then echo "KernelSU"
    else echo "Magisk"; fi
}

ar_root_version() {
    local impl; impl=$(ar_root_impl)
    case "$impl" in
        Magisk)   magisk -v 2>/dev/null | head -n1 | tr -d '\n'; magisk -V 2>/dev/null | head -n1 | tr -d '\n';;
        KernelSU) ksud -v 2>/dev/null | head -n1 | tr -d '\n'; getprop persist.kernel.version 2>/dev/null;;
        APatch)   apd -V 2>/dev/null | head -n1 | tr -d '\n';;
    esac
    echo ""
}

# ---------- 救援提示文件( recovery / adb 可见 ) ----------
ar_write_notice() {
    local msg="$1"
    [ "$(ar_conf_get rescue_notify_file 1)" = "1" ] || return 0
    mkdir -p "$AR_STATE" 2>/dev/null
    [ -d /data/local/tmp ] || mkdir -p /data/local/tmp 2>/dev/null
    {
        printf '==== AutoRescue 救砖通知 ====\n'
        printf '时间: %s\n' "$(ar_now)"
        printf '%s\n' "$msg"
        printf '本模块已自动处理, 设备已重启。\n'
        printf '如需查看日志: /data/adb/auto_rescue/log/rescue.log\n'
        printf '如需手动救援: sh /data/adb/modules/auto_rescue/tools/rescue.sh\n'
    } > "$AR_STATE/last_notice" 2>/dev/null
    [ -d /data/local/tmp ] || return 0
    cp "$AR_STATE/last_notice" /data/local/tmp/AutoRescue_Notice.txt 2>/dev/null
    chmod 0644 /data/local/tmp/AutoRescue_Notice.txt 2>/dev/null
}

