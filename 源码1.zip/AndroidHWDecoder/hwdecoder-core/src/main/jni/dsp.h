#ifndef HWD_DSP_H
#define HWD_DSP_H

#include <cmath>
#include <cstring>
#include <algorithm>
#include <vector>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

namespace hwd {

inline float dbToGain(float db) {
    return std::pow(10.0f, db / 20.0f);
}

/**
 * 双二阶滤波器（RBJ cookbook 系数，每声道独立状态，处理交错 PCM）。
 */
class Biquad {
public:
    void init(int channels) {
        mChannels = channels > 0 ? channels : 1;
        mX1.assign(mChannels, 0.0);
        mX2.assign(mChannels, 0.0);
        mY1.assign(mChannels, 0.0);
        mY2.assign(mChannels, 0.0);
        setBypass(true);
    }

    void setBypass(bool bypass) {
        mBypass = bypass;
        std::fill(mX1.begin(), mX1.end(), 0.0);
        std::fill(mX2.begin(), mX2.end(), 0.0);
        std::fill(mY1.begin(), mY1.end(), 0.0);
        std::fill(mY2.begin(), mY2.end(), 0.0);
    }

    void setPeaking(double fs, double freq, double q, double gainDb) {
        double A = std::pow(10.0, gainDb / 40.0);
        double w0 = 2.0 * M_PI * freq / fs;
        double cw = std::cos(w0);
        double alpha = std::sin(w0) / (2.0 * q);
        setCoeffs(1.0 + alpha * A, -2.0 * cw, 1.0 - alpha * A,
                  1.0 + alpha / A, -2.0 * cw, 1.0 - alpha / A);
    }

    void setLowShelf(double fs, double freq, double slope, double gainDb) {
        double A = std::pow(10.0, gainDb / 40.0);
        double w0 = 2.0 * M_PI * freq / fs;
        double cw = std::cos(w0);
        double beta = std::sqrt(A) / slope;
        double alpha = std::sin(w0) / 2.0;
        double ap1 = 2.0 * std::sqrt(A) * alpha;
        setCoeffs(A * ((A + 1) - (A - 1) * cw + beta * std::sin(w0)),
                  2.0 * A * ((A - 1) - (A + 1) * cw),
                  A * ((A + 1) - (A - 1) * cw - beta * std::sin(w0)),
                  (A + 1) + (A - 1) * cw + ap1,
                  -2.0 * ((A - 1) + (A + 1) * cw),
                  (A + 1) + (A - 1) * cw - ap1);
    }

    void setHighShelf(double fs, double freq, double slope, double gainDb) {
        double A = std::pow(10.0, gainDb / 40.0);
        double w0 = 2.0 * M_PI * freq / fs;
        double cw = std::cos(w0);
        double beta = std::sqrt(A) / slope;
        double alpha = std::sin(w0) / 2.0;
        double ap1 = 2.0 * std::sqrt(A) * alpha;
        setCoeffs(A * ((A + 1) + (A - 1) * cw + beta * std::sin(w0)),
                  -2.0 * A * ((A - 1) + (A + 1) * cw),
                  A * ((A + 1) + (A - 1) * cw - beta * std::sin(w0)),
                  (A + 1) - (A - 1) * cw + ap1,
                  2.0 * ((A - 1) - (A + 1) * cw),
                  (A + 1) - (A - 1) * cw - ap1);
    }

    void setHighPass(double fs, double freq, double q) {
        double w0 = 2.0 * M_PI * freq / fs;
        double cw = std::cos(w0);
        double alpha = std::sin(w0) / (2.0 * q);
        setCoeffs((1.0 + cw) / 2.0, -(1.0 + cw), (1.0 + cw) / 2.0,
                  1.0 + alpha, -2.0 * cw, 1.0 - alpha);
    }

    /** 就地处理交错 PCM */
    void process(float* buf, size_t len) {
        if (mBypass || mChannels <= 0) return;
        size_t frames = len / mChannels;
        for (size_t f = 0; f < frames; ++f) {
            size_t base = f * mChannels;
            for (int c = 0; c < mChannels; ++c) {
                double x0 = buf[base + c];
                double y0 = mB0 * x0 + mB1 * mX1[c] + mB2 * mX2[c]
                            - mA1 * mY1[c] - mA2 * mY2[c];
                mX2[c] = mX1[c];
                mX1[c] = x0;
                mY2[c] = mY1[c];
                mY1[c] = y0;
                buf[base + c] = static_cast<float>(y0);
            }
        }
    }

private:
    void setCoeffs(double b0, double b1, double b2,
                   double a0, double a1, double a2) {
        mB0 = b0 / a0;
        mB1 = b1 / a0;
        mB2 = b2 / a0;
        mA1 = a1 / a0;
        mA2 = a2 / a0;
        mBypass = false;
    }

    double mB0 = 1.0, mB1 = 0.0, mB2 = 0.0, mA1 = 0.0, mA2 = 0.0;
    std::vector<double> mX1, mX2, mY1, mY2;
    int mChannels = 0;
    bool mBypass = true;
};

/**
 * 软限幅器：线性区保持原样，超出 ceiling 部分用 tanh 平滑压缩，
 * 避免硬削波产生的数字噪声，可安全放大到 800%。
 */
class SoftLimiter {
public:
    void setCeiling(float ceiling) {
        mCeiling = ceiling < 0.3f ? 0.3f : (ceiling > 1.0f ? 1.0f : ceiling);
        mSpan = 1.0f - mCeiling;
    }

    void process(float* buf, size_t len) {
        float ceiling = mCeiling;
        float span = mSpan < 0.05f ? 0.05f : mSpan;
        for (size_t i = 0; i < len; ++i) {
            float x = buf[i];
            float a = std::fabs(x);
            if (a > ceiling) {
                float comp = ceiling + span * std::tanh((a - ceiling) / span);
                if (comp > 1.0f) comp = 1.0f;
                x = x < 0.0f ? -comp : comp;
            }
            buf[i] = x;
        }
    }

private:
    float mCeiling = 0.92f;
    float mSpan = 0.08f;
};

/**
 * 线性插值重采样器（变速播放）。
 * ratio = 输入帧 / 输出帧，即倍速。支持任意浮点倍速。
 */
class LinearResampler {
public:
    // 输入 inFrames 帧（交错），输出 outFrames 帧到 dst
    // 返回实际消耗的输入帧数
    static int process(const float* in, int inFrames,
                       float* dst, int outFrames,
                       float ratio, int channels) {
        float pos = 0.0f;
        int lastIdx = inFrames > 0 ? inFrames - 1 : 0;
        for (int i = 0; i < outFrames; ++i) {
            int i0 = static_cast<int>(pos);
            if (i0 > lastIdx) i0 = lastIdx;
            int i1 = i0 + 1 <= lastIdx ? i0 + 1 : lastIdx;
            float frac = pos - static_cast<float>(i0);
            const float* s0 = in + static_cast<size_t>(i0) * channels;
            const float* s1 = in + static_cast<size_t>(i1) * channels;
            float* d = dst + static_cast<size_t>(i) * channels;
            for (int c = 0; c < channels; ++c) {
                d[c] = s0[c] * (1.0f - frac) + s1[c] * frac;
            }
            pos += ratio;
        }
        return static_cast<int>(pos);
    }
};

/**
 * WSOLA（Waveform Similarity Overlap-Add）变速不变调重采样器。
 * <p>
 * 倍速播放时保持音调不变（不会变尖），解决高倍速下的听感问题。
 * 实现要点：
 * - Hann 窗分析/合成段，段间 overlap-add；
 * - 每段在输入基准位置 ±Delta 范围内做波形相似度搜索（互相关），
 *   选取最「自然延续」的位置，抑制颤音与金属感；
 * - 相似度搜索只取声道 0、抽样计算，控制 CPU 开销；
 * - 输入跨调用保持（未消费数据留到下一次），输出按段产出。
 */
class WsolaResampler {
public:
    void init(int channels, int winFrames = 512, int hopFrames = 128, int deltaFrames = 128) {
        mCh = channels > 0 ? channels : 1;
        mWin = winFrames;
        mHop = hopFrames;
        mDelta = deltaFrames;
        mWindow.resize(mWin);
        for (int i = 0; i < mWin; ++i) {
            mWindow[i] = 0.5f - 0.5f * std::cos(2.0f * (float) M_PI * i / (mWin - 1));
        }
        mSeg.assign(static_cast<size_t>(mWin) * mCh, 0.0f);
        mTail.assign(static_cast<size_t>(mWin - mHop) * mCh, 0.0f);
        mRef.assign(static_cast<size_t>(mWin) * mCh, 0.0f);
        mLastStart = 0;
        mSegIndex = 0;
    }

    void reset() {
        std::fill(mSeg.begin(), mSeg.end(), 0.0f);
        std::fill(mTail.begin(), mTail.end(), 0.0f);
        std::fill(mRef.begin(), mRef.end(), 0.0f);
        mLastStart = 0;
        mHasHistory = false;
        mSegIndex = 0;
    }

    /** 产出 outFrames 帧所需的输入帧数下限 */
    static int requiredInput(int outFrames, float ratio, int winFrames, int deltaFrames,
                             int hopFrames) {
        int Ss = static_cast<int>(std::lrint(hopFrames * ratio));
        if (Ss < 1) Ss = 1;
        int segs = (outFrames + hopFrames - 1) / hopFrames;
        return Ss * (segs - 1) + winFrames + deltaFrames;
    }

    /**
     * 处理一段（流式：未消费的输入尾部由调用方保留，跨调用连续）。
     *
     * @param in        输入（交错，帧为单位计数）
     * @param inFrames  输入可用帧数
     * @param out       输出缓冲（至少 maxOut 帧）
     * @param maxOut    期望产出帧数
     * @param ratio     输入/输出 比（= 倍速，>1 表示加速）
     * @param channels  声道数
     * @param consumedOut 输出参数：可消费的输入帧数（尾部 [consumed, inFrames) 应留给下次）
     * @return 实际产出的帧数
     */
    int process(const float* in, int inFrames, float* out, int maxOut,
                float ratio, int channels, int& consumedOut) {
        int ch = channels > 0 ? channels : mCh;
        int Ss = static_cast<int>(std::lrint(mHop * ratio));
        if (Ss < 1) Ss = 1;
        int produced = 0;
        int consumed = 0;
        mSegIndex = 0; // 每次调用从输入起点开始（未消费尾部已由调用方保留）

        while (produced < maxOut) {
            int base = mSegIndex * Ss;
            // 输入充足性：最坏偏移 +mDelta 后仍需完整一窗
            if (base + mWin + mDelta > inFrames) break;

            // 相似度参考窗：「上一段起点 + mHop」处的自然延续
            int refStart = mLastStart + mHop;
            if (refStart < 0) refStart = 0;
            if (refStart + mWin > inFrames) refStart = inFrames - mWin;
            if (refStart < 0) refStart = 0;
            for (int k = 0; k < mWin * ch; ++k) {
                mRef[k] = in[static_cast<size_t>(refStart) * ch + k];
            }

            int bestOff = 0;
            if (mHasHistory) {
                float bestScore = -1e30f;
                for (int off = -mDelta; off <= mDelta; ++off) {
                    int start = base + off;
                    if (start < 0) start = 0;
                    if (start + mWin > inFrames) start = inFrames - mWin;
                    // 归一化互相关（声道 0，步长 2 抽样，控制开销）
                    float num = 0.0f, da = 0.0f, db = 0.0f;
                    for (int k = 0; k < mWin; k += 2) {
                        float a = in[static_cast<size_t>(start) * ch];
                        float b = mRef[static_cast<size_t>(k) * ch];
                        num += a * b;
                        da += a * a;
                        db += b * b;
                    }
                    float denom = std::sqrt(da * db) + 1e-9f;
                    float score = num / denom;
                    // 轻微偏移惩罚：偏向时间连续位置
                    score -= std::fabs(static_cast<float>(off)) * 1e-5f;
                    if (score > bestScore) {
                        bestScore = score;
                        bestOff = off;
                    }
                }
            }

            int start = base + bestOff;
            if (start < 0) start = 0;
            if (start + mWin > inFrames) start = inFrames - mWin;
            mLastStart = start;
            mHasHistory = true;

            // 提取段并加 Hann 窗（边界不足补零）
            std::fill(mSeg.begin(), mSeg.end(), 0.0f);
            int avail = inFrames - start;
            int n = mWin < avail ? mWin : avail;
            for (int k = 0; k < n * ch; ++k) {
                mSeg[k] = in[static_cast<size_t>(start) * ch + k];
            }
            for (int f = 0; f < mWin; ++f) {
                float w = mWindow[f];
                for (int c = 0; c < ch; ++c) {
                    mSeg[static_cast<size_t>(f) * ch + c] *= w;
                }
            }
            // overlap-add 输出前 mHop 帧
            for (int j = 0; j < mHop && produced < maxOut; ++j, ++produced) {
                for (int c = 0; c < ch; ++c) {
                    float v = mSeg[static_cast<size_t>(j) * ch + c];
                    if (j < mWin - mHop) v += mTail[static_cast<size_t>(j) * ch + c];
                    out[static_cast<size_t>(produced) * ch + c] = v;
                }
            }
            // 保存尾部供下一段 overlap
            for (int j = mHop; j < mWin; ++j) {
                for (int c = 0; c < ch; ++c) {
                    mTail[static_cast<size_t>(j - mHop) * ch + c] =
                            mSeg[static_cast<size_t>(j) * ch + c];
                }
            }
            mSegIndex++;
            consumed = start; // 尾部 [consumed, inFrames) 留给下次调用
        }
        consumedOut = consumed;
        return produced;
    }

private:
    int mCh = 2;
    int mWin = 512;
    int mHop = 128;
    int mDelta = 128;
    int mLastStart = 0;
    bool mHasHistory = false;
    int mSegIndex = 0;
    std::vector<float> mWindow;
    std::vector<float> mSeg;
    std::vector<float> mTail;
    std::vector<float> mRef;
};

} // namespace hwd

#endif // HWD_DSP_H
