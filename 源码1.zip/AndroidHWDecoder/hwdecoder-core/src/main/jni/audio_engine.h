#ifndef HWD_AUDIO_ENGINE_H
#define HWD_AUDIO_ENGINE_H

#include "dsp.h"
#include "ring_buffer.h"

#include <SLES/OpenSLES.h>
#include <SLES/OpenSLES_Android.h>
#include <SLES/OpenSLES_AndroidConfiguration.h>

#include <atomic>
#include <chrono>
#include <cstdint>
#include <deque>
#include <mutex>
#include <vector>

namespace hwd {

/**
 * 基于 OpenSL ES 的低延迟音频引擎。
 * <p>
 * 数据流：
 *   Java (float PCM) --JNI--> SPSC 环形缓冲
 *     --> [输入保持缓冲] --> [WSOLA/线性重采样变速]
 *     --> [3段 EQ] --> [增益放大 + 软限幅] --> int16 --> 设备
 * <p>
 * 变速不变调：倍速 != 1 且 pitchPreserve 开启时使用 WSOLA（音调保持）；
 * 关闭时使用线性重采样（CPU 更低）。
 * <p>
 * 媒体时钟：以「已播放的媒体帧数」为基准（扣除保持缓冲与设备队列中的未播内容），
 * 变速时依然精确。
 */
class AudioEngine {
public:
    AudioEngine();
    ~AudioEngine();

    bool configure(int sampleRate, int channels, int bufferFrames, bool lowLatency);
    void start();
    void pause();
    void stop();
    void flush();

    /** 阻塞写入 float 采样（交错，媒体速率），返回写入的采样数 */
    int write(const float* data, int samples);

    void setVolume(float gain);   // 线性 0~8
    void setSpeed(float speed);   // 0.25~8
    void setPitchPreserve(bool preserve);
    void setEq(int band, float gainDb); // 0=low 1=mid 2=high

    float bufferMs() const;        // 设备输出缓冲估算时长
    int64_t mediaPositionFrames(); // 已播放媒体帧（自上次 flush 起累计）
    int64_t playedFramesPublic() const;  // 设备已播放帧（1x 空间）
    int underruns() const;
    int holdFrames() const;        // 重采样输入保持缓冲中的帧数

private:
    void pump();
    void applyEq();
    void destroy();
    static void bqCallback(SLAndroidSimpleBufferQueueItf bq, void* ctx);

    // OpenSL ES 对象
    SLObjectItf mEngineObj = nullptr;
    SLEngineItf mEngine = nullptr;
    SLObjectItf mOutputMixObj = nullptr;
    SLObjectItf mPlayerObj = nullptr;
    SLPlayItf mPlay = nullptr;
    SLAndroidSimpleBufferQueueItf mQueue = nullptr;

    // 音频参数
    int mSampleRate = 48000;
    int mChannels = 2;
    int mBufFrames = 960;      // 每次回调输出帧数（20ms @48k）
    int16_t* mMixBuffer[2] = {nullptr, nullptr};
    int mBufIndex = 0;

    // 环形缓冲与处理缓冲
    SpscRingBuffer<float> mRing{1 << 16};
    std::vector<float> mInHold;     // 重采样输入保持（跨调用）
    std::vector<float> mMixScratch; // 重采样输出

    // DSP
    Biquad mEqLow, mEqMid, mEqHigh;
    SoftLimiter mLimiter;
    WsolaResampler mWsola;
    std::atomic<float> mGain{1.0f};
    std::atomic<float> mSpeed{1.0f};
    std::atomic<float> mEqLowDb{0.0f};
    std::atomic<float> mEqMidDb{0.0f};
    std::atomic<float> mEqHighDb{0.0f};
    std::atomic<bool> mEqDirty{false};
    std::atomic<bool> mPitchPreserve{true};

    // 状态与统计
    std::atomic<bool> mRunning{false};
    std::atomic<bool> mStarted{false};
    std::atomic<int64_t> mPulledInFrames{0};    // 从环形缓冲取走的媒体帧
    std::atomic<int64_t> mEnqueuedOutFrames{0}; // 已入队设备的帧（1x 空间）
    std::atomic<int64_t> mHoldFrames{0};        // 保持缓冲中的媒体帧
    std::atomic<int> mUnderruns{0};
    bool mConfigured = false;

    // 设备播放进度：OpenSL ES 无播放位置 API，按入队时刻推算
    // （每批入队时记录「预计播完时刻」，播放进度 = 已播完批次 + 当前批已播比例）
    void advancePlayed();
    static int64_t nowNs();
    mutable std::mutex mTimeLock;
    std::deque<std::pair<int64_t, int>> mQueueTimes; // (预计播完时刻 ns, 帧数)
    int64_t mHorizonNs = 0;        // 预计最后一批播完时刻
    int64_t mPausedAtNs = 0;       // 暂停时刻（>0 表示处于暂停）
    int64_t mPlayedOutFrames = 0;  // 已完整播完的设备帧
    double mPlayedPartialFrames = 0; // 当前批按时间比例折算的已播帧
};

} // namespace hwd

#endif // HWD_AUDIO_ENGINE_H
