#ifndef HWD_RING_BUFFER_H
#define HWD_RING_BUFFER_H

#include <atomic>
#include <cstdint>
#include <cstddef>

namespace hwd {

/**
 * 单生产者单消费者（SPSC）无锁环形缓冲区。
 * 生产者 = Java 音频解码线程；消费者 = OpenSL ES 回调线程。
 * 基于序号（sequence number）实现 lock-free，适合音频低延迟场景。
 */
template <typename T>
class SpscRingBuffer {
public:
    explicit SpscRingBuffer(size_t capacityPow2)
        : mCapacity(capacityPow2), mMask(capacityPow2 - 1) {
        mData = new T[capacityPow2];
    }

    ~SpscRingBuffer() { delete[] mData; }

    SpscRingBuffer(const SpscRingBuffer&) = delete;
    SpscRingBuffer& operator=(const SpscRingBuffer&) = delete;

    size_t size() const {
        uint64_t w = mWriteSeq.load(std::memory_order_acquire);
        uint64_t r = mReadSeq.load(std::memory_order_acquire);
        return static_cast<size_t>(w - r);
    }

    size_t capacity() const { return mCapacity; }

    size_t space() const { return mCapacity - size(); }

    /** 非阻塞写入，返回实际写入元素数 */
    size_t push(const T* src, size_t n) {
        uint64_t w = mWriteSeq.load(std::memory_order_relaxed);
        uint64_t r = mReadSeq.load(std::memory_order_acquire);
        size_t avail = mCapacity - static_cast<size_t>(w - r);
        size_t k = n < avail ? n : avail;
        for (size_t i = 0; i < k; ++i) {
            mData[(w + i) & mMask] = src[i];
        }
        mWriteSeq.store(w + k, std::memory_order_release);
        return k;
    }

    /** 非阻塞读取，返回实际读出元素数 */
    size_t pop(T* dst, size_t n) {
        uint64_t r = mReadSeq.load(std::memory_order_relaxed);
        uint64_t w = mWriteSeq.load(std::memory_order_acquire);
        size_t avail = static_cast<size_t>(w - r);
        size_t k = n < avail ? n : avail;
        for (size_t i = 0; i < k; ++i) {
            dst[i] = mData[(r + i) & mMask];
        }
        mReadSeq.store(r + k, std::memory_order_release);
        return k;
    }

    /** 清空（消费者侧） */
    void clear() {
        uint64_t w = mWriteSeq.load(std::memory_order_acquire);
        mReadSeq.store(w, std::memory_order_release);
    }

private:
    T* mData;
    size_t mCapacity;
    size_t mMask;
    std::atomic<uint64_t> mWriteSeq{0};
    std::atomic<uint64_t> mReadSeq{0};
};

} // namespace hwd

#endif // HWD_RING_BUFFER_H
