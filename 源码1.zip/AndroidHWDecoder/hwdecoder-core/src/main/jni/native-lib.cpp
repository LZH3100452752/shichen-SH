#include <jni.h>

#include "audio_engine.h"

#include <unistd.h>
#include <algorithm>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <sched.h>
#include <string>
#include <vector>

namespace {

hwd::AudioEngine* engineFromHandle(jlong handle) {
    return reinterpret_cast<hwd::AudioEngine*>(handle);
}

/** 读取 CPU 最大频率（kHz），失败返回 -1 */
long readCpuMaxFreqKhz(int cpu) {
    char path[128];
    std::snprintf(path, sizeof(path),
                  "/sys/devices/system/cpu/cpu%d/cpufreq/cpuinfo_max_freq", cpu);
    std::ifstream f(path);
    if (!f.is_open()) return -1;
    long khz = -1;
    f >> khz;
    return khz;
}

/** 获取大核 CPU id 列表（按频率降序，取前一半簇） */
std::vector<int> bigCoreIds() {
    int n = static_cast<int>(sysconf(_SC_NPROCESSORS_ONLN));
    if (n < 1) n = 1;
    if (n > 64) n = 64;
    std::vector<std::pair<long, int>> freqs; // (freq, cpu)
    bool anyFreq = false;
    for (int i = 0; i < n; i++) {
        long khz = readCpuMaxFreqKhz(i);
        if (khz > 0) anyFreq = true;
        freqs.emplace_back(khz > 0 ? khz : 0, i);
    }
    std::vector<int> cores;
    if (anyFreq) {
        std::stable_sort(freqs.begin(), freqs.end(),
                         [](const std::pair<long, int>& a, const std::pair<long, int>& b) {
                             return a.first > b.first;
                         });
        long top = freqs.front().first;
        // 频率 >= 最高频率 90% 的核心视为大核
        for (auto& f : freqs) {
            if (f.first * 10 >= top * 9) cores.push_back(f.second);
        }
    }
    if (cores.empty()) {
        // 无频率信息（部分内核受限）：取编号较大的一半（常见的大小核布局）
        for (int i = n / 2; i < n; i++) cores.push_back(i);
        if (cores.empty()) cores.push_back(0);
    }
    return cores;
}

/** 绑定当前线程到大核集合（round-robin 选取一个） */
void bindToBigCores() {
    static std::vector<int> cores = bigCoreIds();
    if (cores.empty()) return;
    static std::atomic<int> rr{0};
    int idx = rr.fetch_add(1, std::memory_order_relaxed) % static_cast<int>(cores.size());
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(cores[idx], &set);
    // 屏蔽返回码：绑定失败不影响功能
    sched_setaffinity(0, sizeof(set), &set);
}

} // namespace

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_hwdecoder_NativeLib_nativeCreateEngine(JNIEnv* /*env*/, jobject /*thiz*/) {
    auto* engine = new hwd::AudioEngine();
    return reinterpret_cast<jlong>(engine);
}

JNIEXPORT void JNICALL
Java_com_hwdecoder_NativeLib_nativeDestroyEngine(JNIEnv* /*env*/, jobject /*thiz*/, jlong handle) {
    auto* engine = engineFromHandle(handle);
    if (engine == nullptr) return;
    delete engine;
}

JNIEXPORT jboolean JNICALL
Java_com_hwdecoder_NativeLib_nativeConfigure(JNIEnv* /*env*/, jobject /*thiz*/, jlong handle,
                                             jint sampleRate, jint channels,
                                             jint bufferFrames, jboolean lowLatency) {
    auto* engine = engineFromHandle(handle);
    if (engine == nullptr) return JNI_FALSE;
    return engine->configure(sampleRate, channels, bufferFrames,
                             lowLatency == JNI_TRUE) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_hwdecoder_NativeLib_nativeStart(JNIEnv* /*env*/, jobject /*thiz*/, jlong handle) {
    auto* engine = engineFromHandle(handle);
    if (engine != nullptr) engine->start();
}

JNIEXPORT void JNICALL
Java_com_hwdecoder_NativeLib_nativePause(JNIEnv* /*env*/, jobject /*thiz*/, jlong handle) {
    auto* engine = engineFromHandle(handle);
    if (engine != nullptr) engine->pause();
}

JNIEXPORT void JNICALL
Java_com_hwdecoder_NativeLib_nativeStop(JNIEnv* /*env*/, jobject /*thiz*/, jlong handle) {
    auto* engine = engineFromHandle(handle);
    if (engine != nullptr) engine->stop();
}

JNIEXPORT void JNICALL
Java_com_hwdecoder_NativeLib_nativeFlush(JNIEnv* /*env*/, jobject /*thiz*/, jlong handle) {
    auto* engine = engineFromHandle(handle);
    if (engine != nullptr) engine->flush();
}

JNIEXPORT jint JNICALL
Java_com_hwdecoder_NativeLib_nativeWrite(JNIEnv* env, jobject /*thiz*/, jlong handle,
                                         jfloatArray data, jint off, jint len) {
    auto* engine = engineFromHandle(handle);
    if (engine == nullptr || data == nullptr || len <= 0) return 0;

    // 分块拷贝，避免大数组一次性进本地缓冲
    const int CHUNK = 4096;
    std::vector<float> buf(CHUNK);
    int done = 0;
    while (done < len) {
        int n = len - done < CHUNK ? len - done : CHUNK;
        env->GetFloatArrayRegion(data, off + done, n, buf.data());
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            break;
        }
        int k = engine->write(buf.data(), n);
        done += k;
        if (k < n) break; // 已停止
    }
    return done;
}

JNIEXPORT void JNICALL
Java_com_hwdecoder_NativeLib_nativeSetVolume(JNIEnv* /*env*/, jobject /*thiz*/, jlong handle,
                                             jfloat gain) {
    auto* engine = engineFromHandle(handle);
    if (engine != nullptr) engine->setVolume(gain);
}

JNIEXPORT void JNICALL
Java_com_hwdecoder_NativeLib_nativeSetSpeed(JNIEnv* /*env*/, jobject /*thiz*/, jlong handle,
                                            jfloat speed) {
    auto* engine = engineFromHandle(handle);
    if (engine != nullptr) engine->setSpeed(speed);
}

JNIEXPORT void JNICALL
Java_com_hwdecoder_NativeLib_nativeSetEq(JNIEnv* /*env*/, jobject /*thiz*/, jlong handle,
                                         jint band, jfloat gainDb) {
    auto* engine = engineFromHandle(handle);
    if (engine != nullptr) engine->setEq(band, gainDb);
}

JNIEXPORT jfloat JNICALL
Java_com_hwdecoder_NativeLib_nativeGetBufferMs(JNIEnv* /*env*/, jobject /*thiz*/, jlong handle) {
    auto* engine = engineFromHandle(handle);
    return engine != nullptr ? engine->bufferMs() : 0.0f;
}

JNIEXPORT jlong JNICALL
Java_com_hwdecoder_NativeLib_nativeGetPlayedFrames(JNIEnv* /*env*/, jobject /*thiz*/, jlong handle) {
    auto* engine = engineFromHandle(handle);
    return engine != nullptr ? static_cast<jlong>(engine->playedFramesPublic()) : 0;
}

JNIEXPORT jlong JNICALL
Java_com_hwdecoder_NativeLib_nativeGetMediaPositionFrames(JNIEnv* /*env*/, jobject /*thiz*/,
                                                         jlong handle) {
    auto* engine = engineFromHandle(handle);
    return engine != nullptr ? static_cast<jlong>(engine->mediaPositionFrames()) : 0;
}

JNIEXPORT void JNICALL
Java_com_hwdecoder_NativeLib_nativeSetPitchPreserve(JNIEnv* /*env*/, jobject /*thiz*/,
                                                   jlong handle, jboolean preserve) {
    auto* engine = engineFromHandle(handle);
    if (engine != nullptr) {
        engine->setPitchPreserve(preserve == JNI_TRUE);
    }
}

JNIEXPORT jintArray JNICALL
Java_com_hwdecoder_NativeLib_nativeGetBigCoreIds(JNIEnv* env, jobject /*thiz*/) {
    std::vector<int> cores = bigCoreIds();
    jintArray arr = env->NewIntArray(static_cast<jsize>(cores.size()));
    if (arr == nullptr) return nullptr;
    env->SetIntArrayRegion(arr, 0, static_cast<jsize>(cores.size()),
                           reinterpret_cast<const jint*>(cores.data()));
    return arr;
}

JNIEXPORT void JNICALL
Java_com_hwdecoder_NativeLib_nativeBindThreadToBigCore(JNIEnv* /*env*/, jobject /*thiz*/) {
    bindToBigCores();
}

JNIEXPORT void JNICALL
Java_com_hwdecoder_NativeLib_nativeBindThreadToCpu(JNIEnv* /*env*/, jobject /*thiz*/, jint cpu) {
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(cpu, &set);
    sched_setaffinity(0, sizeof(set), &set);
}

JNIEXPORT jint JNICALL
Java_com_hwdecoder_NativeLib_nativeGetUnderruns(JNIEnv* /*env*/, jobject /*thiz*/, jlong handle) {
    auto* engine = engineFromHandle(handle);
    return engine != nullptr ? engine->underruns() : 0;
}

JNIEXPORT jint JNICALL
Java_com_hwdecoder_NativeLib_nativeGetCpuCount(JNIEnv* /*env*/, jobject /*thiz*/) {
    long n = sysconf(_SC_NPROCESSORS_ONLN);
    if (n < 1) n = 1;
    if (n > 64) n = 64;
    return static_cast<jint>(n);
}

} // extern "C"
