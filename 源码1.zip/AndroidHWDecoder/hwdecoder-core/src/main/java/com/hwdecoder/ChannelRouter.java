package com.hwdecoder;

/**
 * 声道路由：在 DSP 链最前端对多声道 PCM 做声道级处理。
 * <p>
 * 典型用途：
 * <ul>
 *   <li>双声道影片只听一侧对白：仅左 / 仅右；</li>
 *   <li>耳返/录音场景交换左右声道；</li>
 *   <li>多声道（5.1/7.1）内容下混为单声道，提升小音量清晰度；</li>
 *   <li>双语声道（左=中文，右=英文）只保留一路。</li>
 * </ul>
 * 处理在 float 域完成，置于音量放大之前，不影响后续各级。
 */
public final class ChannelRouter implements AudioProcessor {

    public static final int MODE_STEREO = 0;   // 原始输出（直通）
    public static final int MODE_SWAP = 1;     // 交换左右声道
    public static final int MODE_LEFT = 2;     // 仅左声道（复制到所有声道）
    public static final int MODE_RIGHT = 3;    // 仅右声道（复制到所有声道）
    public static final int MODE_MONO = 4;     // 下混为单声道（复制到所有声道）

    private volatile int mMode = MODE_STEREO;
    private int mChannels = 2;

    public ChannelRouter(int channels) {
        mChannels = channels > 0 ? channels : 1;
    }

    public void setMode(int mode) {
        if (mode < MODE_STEREO || mode > MODE_MONO) mode = MODE_STEREO;
        mMode = mode;
    }

    public int getMode() {
        return mMode;
    }

    @Override
    public void init(int sampleRate, int channels) {
        if (channels > 0) mChannels = channels;
    }

    @Override
    public void process(float[] buf, int off, int len) {
        int mode = mMode;
        if (mode == MODE_STEREO) return;
        int ch = mChannels;
        int frames = len / ch;
        if (frames <= 0) return;
        switch (mode) {
            case MODE_SWAP: {
                if (ch < 2) return;
                for (int f = 0; f < frames; f++) {
                    int base = off + f * ch;
                    float t = buf[base];
                    buf[base] = buf[base + 1];
                    buf[base + 1] = t;
                }
                break;
            }
            case MODE_LEFT:
            case MODE_RIGHT: {
                if (ch < 2) return;
                int src = mode == MODE_LEFT ? 0 : 1;
                for (int f = 0; f < frames; f++) {
                    int base = off + f * ch;
                    float v = buf[base + src];
                    for (int c = 0; c < ch; c++) buf[base + c] = v;
                }
                break;
            }
            case MODE_MONO: {
                for (int f = 0; f < frames; f++) {
                    int base = off + f * ch;
                    float sum = 0f;
                    for (int c = 0; c < ch; c++) sum += buf[base + c];
                    float v = sum / ch;
                    for (int c = 0; c < ch; c++) buf[base + c] = v;
                }
                break;
            }
            default:
                break;
        }
    }

    @Override
    public void reset() {
        // 无状态
    }

    @Override
    public void release() {
        // 无状态
    }
}
