package com.hwdecoder.audio;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Build;

/**
 * 基于 AudioTrack 的音频输出（主链路）。
 * <p>
 * 要点：
 * 1. 优先使用 ENCODING_PCM_FLOAT（API 21+），使音量放大不受 16bit 动态范围限制；
 * 2. API 26+ 申请 LOW_LATENCY 性能模式；
 * 3. 以 getPlaybackHeadPosition() 精确推导媒体时钟位置，供视频同步；
 * 4. 倍速两种模式：
 *    a) 音调保持（默认）：WSOLA 时间缩放（Hann 窗 + 波形相似度搜索 + overlap-add），
 *       高倍速下人声不变尖、无颤音；设备按 1x 播放；
 *    b) 音调随速：setPlaybackRate 交设备侧重采样（CPU 更低，音调随倍速变化）；
 * 5. 统计写入阻塞时长检测 underrun。
 * <p>
 * 线程模型：write/drain 由音频解码线程调用；setSpeed/setPitchPreserve/flush 可跨线程，
 * 内部以短临界区保护保持缓冲，阻塞式设备写入不持锁。
 */
public final class AudioTrackOutput implements AudioOutput {

    private static final int FLOAT_OVERHEAD = 4; // float = 4 bytes

    // WSOLA 参数（与原生层一致）
    private static final int WSOLA_WIN = 512;
    private static final int WSOLA_HOP = 128;
    private static final int WSOLA_DELTA = 128;

    private AudioTrack mTrack;
    private int mSampleRate;
    private int mChannels;
    private boolean mFloatSupported;

    private long mBasePtsUs;      // 首个媒体帧对应的时间戳
    private long mFramesWritten;  // 已写入设备的帧数
    private long mMediaFrames;    // 已接收的媒体帧数（WSOLA 模式用于 pts 基准）
    private long mFramesPlayed;   // 设备已播放帧数（含回卷修正）
    private int mLastHead;
    private long mHeadWrapCount;

    private int mUnderruns;
    private int mSpeedPm = 1000;  // 设备播放速率（千分比）
    private volatile boolean mStarted;

    // ---- 变速不变调（WSOLA）状态 ----
    private volatile float mSpeed = 1.0f;     // 0.1 ~ 8
    private volatile boolean mPitchPreserve = true;
    private volatile float mTimeScale = 1.0f; // 媒体帧 = 设备帧 * timeScale
    private WsolaResampler mWsola;
    private float[] mHold;        // 媒体输入保持缓冲（跨 write 调用）
    private int mHoldFrames;
    private float[] mWsolaOut;    // WSOLA 输出暂存（设备帧）
    private int mChunkFrames;     // 每次产出的设备帧数（约 20ms）
    private float mHoldSpeed = 1.0f; // 保持缓冲累积时的倍速
    private final int[] mConsumedBox = new int[1]; // 热路径复用，避免分配
    private final Object mLock = new Object();

    public AudioTrackOutput() {}

    @Override
    public int open(int sampleRate, int channels, int bufferMs, boolean lowLatency) {
        mSampleRate = sampleRate;
        mChannels = channels;

        int channelMask = channels == 1
                ? AudioFormat.CHANNEL_OUT_MONO
                : AudioFormat.CHANNEL_OUT_STEREO;
        int minBuf = AudioTrack.getMinBufferSize(
                sampleRate, channelMask, AudioFormat.ENCODING_PCM_FLOAT);
        if (minBuf <= 0) {
            // 极端设备不支持 float 输出，退回 16bit
            minBuf = AudioTrack.getMinBufferSize(
                    sampleRate, channelMask, AudioFormat.ENCODING_PCM_16BIT);
            mFloatSupported = false;
        } else {
            mFloatSupported = true;
        }
        if (minBuf <= 0) return RESULT_ERROR_INIT;

        int bytesPerFrame = (mFloatSupported ? FLOAT_OVERHEAD : 2) * channels;
        int bufferBytes = Math.max(minBuf * 2,
                (int) ((long) sampleRate * bufferMs / 1000L * bytesPerFrame));

        AudioAttributes attributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();

        AudioFormat format = new AudioFormat.Builder()
                .setEncoding(mFloatSupported
                        ? AudioFormat.ENCODING_PCM_FLOAT
                        : AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sampleRate)
                .setChannelMask(channelMask)
                .build();

        try {
            AudioTrack.Builder builder = new AudioTrack.Builder()
                    .setAudioAttributes(attributes)
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(bufferBytes)
                    .setTransferMode(AudioTrack.MODE_STREAM);
            // 性能模式走 Builder（API 26+，常量编译期内联，旧版本不进此分支）
            if (Build.VERSION.SDK_INT >= 26) {
                try {
                    builder.setPerformanceMode(
                            lowLatency
                                    ? AudioTrack.PERFORMANCE_MODE_LOW_LATENCY
                                    : AudioTrack.PERFORMANCE_MODE_POWER_SAVING);
                } catch (Throwable ignored) {
                }
            }
            mTrack = builder.build();
            mTrack.setVolume(1.0f); // 增益由 DSP 链完成，此处保持 unity
        } catch (Throwable t) {
            mTrack = null;
            return RESULT_ERROR_INIT;
        }

        // ---- WSOLA 初始化 ----
        mWsola = new WsolaResampler(mChannels, WSOLA_WIN, WSOLA_HOP, WSOLA_DELTA);
        mChunkFrames = Math.max(240, sampleRate / 50); // 约 20ms
        mWsolaOut = new float[mChunkFrames * mChannels];
        // 保持缓冲容量：约 1.2s 媒体帧 + 高倍速余量（8x 时单 chunk 需 ~170ms）
        int holdCap = (int) (sampleRate * 1.2) + WSOLA_WIN * 10;
        mHold = new float[holdCap * mChannels];
        mHoldFrames = 0;
        mHoldSpeed = mSpeed;
        return RESULT_OK;
    }

    @Override
    public int write(float[] data, int off, int len, long ptsUs) {
        if (mTrack == null) return RESULT_ERROR_WRITE;
        int frames = len / mChannels;
        if (frames <= 0) return 0;

        if (mMediaFrames == 0) {
            mBasePtsUs = ptsUs; // 首个媒体帧建立 pts 基准
        }
        mMediaFrames += frames;

        if (!wsolaActive()) {
            // 遗留的 WSOLA 保持缓冲：按累积时的倍速先送出，避免切换丢音
            if (mHoldFrames > 0) {
                drainHold(mHoldSpeed);
            }
            int written = writeFloatsToTrack(data, off, frames);
            if (written < 0) return written;
            mFramesWritten += written;
            updatePlayedFrames();
            noteUnderrun(written);
            return frames;
        }

        // ---- WSOLA 路径：入保持缓冲 -> 时间缩放 -> 写设备 ----
        synchronized (mLock) {
            ensureHoldCapacity(mHoldFrames + frames);
            if (mHoldFrames == 0) mHoldSpeed = mSpeed;
            System.arraycopy(data, off, mHold, mHoldFrames * mChannels, len);
            mHoldFrames += frames;
        }
        return pumpHold(mSpeed);
    }

    /** 把保持缓冲中的媒体帧经 WSOLA 送出（阻塞写设备） */
    private int pumpHold(float speed) {
        int totalConsumed = 0;
        while (true) {
            int hold;
            synchronized (mLock) {
                hold = mHoldFrames;
            }
            int need = WsolaResampler.requiredInput(mChunkFrames, speed,
                    WSOLA_WIN, WSOLA_DELTA, WSOLA_HOP);
            if (hold < need) break;
            int produced;
            synchronized (mLock) {
                produced = mWsola.process(mHold, hold, mWsolaOut, mChunkFrames,
                        speed, mChannels, mConsumedBox);
                int c = mConsumedBox[0];
                if (c > 0) {
                    int remain = hold - c;
                    if (remain > 0) {
                        System.arraycopy(mHold, c * mChannels, mHold, 0, remain * mChannels);
                    }
                    mHoldFrames = remain;
                }
            }
            if (produced <= 0) break;
            int written = writeFloatsToTrack(mWsolaOut, 0, produced);
            if (written < 0) break;
            mFramesWritten += written;
            updatePlayedFrames();
            noteUnderrun(written);
            totalConsumed += mConsumedBox[0];
        }
        return totalConsumed;
    }

    /** EOS 或模式切换时把保持缓冲剩余内容送出（补零 + 自然淡出） */
    @Override
    public void drain() {
        if (mTrack == null) return;
        drainHold(mHoldSpeed);
    }

    private void drainHold(float speed) {
        if (mTrack == null) return;
        while (true) {
            int hold;
            synchronized (mLock) {
                hold = mHoldFrames;
            }
            if (hold <= 0) break;
            int need = WsolaResampler.requiredInput(mChunkFrames, speed,
                    WSOLA_WIN, WSOLA_DELTA, WSOLA_HOP);
            synchronized (mLock) {
                ensureHoldCapacity(need);
                java.util.Arrays.fill(mHold, mHoldFrames * mChannels,
                        need * mChannels, 0f);
                mHoldFrames = need;
            }
            if (pumpHold(speed) <= 0) {
                break; // 异常保护：无法继续产出则丢弃剩余，避免死循环
            }
        }
        synchronized (mLock) {
            mHoldFrames = 0;
        }
    }

    private boolean wsolaActive() {
        return mPitchPreserve && Math.abs(mSpeed - 1.0f) > 0.01f;
    }

    private void ensureHoldCapacity(int frames) {
        int need = frames * mChannels;
        if (need > mHold.length) {
            int newCap = Math.max(need, mHold.length * 2);
            mHold = java.util.Arrays.copyOf(mHold, newCap);
        }
    }

    /** 写入设备（float 直写或 16bit 转换），返回写入的设备帧数 */
    private int writeFloatsToTrack(float[] data, int off, int frames) {
        if (mTrack == null) return RESULT_ERROR_WRITE;
        long t0 = System.nanoTime();
        int writtenFrames;
        if (mFloatSupported) {
            int r = mTrack.write(data, off, frames * mChannels, AudioTrack.WRITE_BLOCKING);
            if (r < 0) return r;
            writtenFrames = r / mChannels;
        } else {
            short[] tmp = new short[frames * mChannels];
            for (int i = 0; i < frames * mChannels; i++) {
                float v = data[off + i];
                if (v > 1f) v = 1f;
                else if (v < -1f) v = -1f;
                tmp[i] = (short) (v * 32767f);
            }
            int r = mTrack.write(tmp, 0, tmp.length);
            if (r < 0) return r;
            writtenFrames = r / 2 / mChannels;
        }
        long blockNs = System.nanoTime() - t0;
        mLastBlockMs = blockNs / 1_000_000L;
        return writtenFrames;
    }

    private long mLastBlockMs;

    private void noteUnderrun(int writtenFrames) {
        // underrun 检测：写入耗时远大于数据时长说明输出饥饿
        double dataMs = writtenFrames * 1000.0 / mSampleRate;
        if (mLastBlockMs > dataMs * 3 + 30) {
            mUnderruns++;
        }
    }

    private void updatePlayedFrames() {
        if (mTrack == null) return;
        int head = mTrack.getPlaybackHeadPosition();
        if (mLastHead != 0 && head < mLastHead) {
            mHeadWrapCount++; // 32bit 回卷
        }
        mLastHead = head;
        mFramesPlayed = (mHeadWrapCount << 32) | (head & 0xFFFFFFFFL);
    }

    @Override
    public long getPlaybackPositionUs() {
        if (mTrack == null || mSampleRate <= 0) return 0;
        updatePlayedFrames();
        // 媒体位置 = pts 基准 + 设备已播帧 * 时间缩放系数 / 采样率
        // （WSOLA 模式设备帧是压缩后的，需乘倍速还原为媒体帧）
        return mBasePtsUs + (long) ((double) mFramesPlayed * mTimeScale * 1e6 / mSampleRate);
    }

    @Override
    public int getBufferedMs() {
        if (mTrack == null || mSampleRate <= 0) return 0;
        updatePlayedFrames();
        long pending = mFramesWritten - mFramesPlayed;
        if (pending < 0) pending = 0;
        return (int) (pending * 1000L / mSampleRate);
    }

    @Override
    public boolean managesOwnBuffering() {
        return false; // AudioTrack 无预填充机制，需要调用方预缓冲
    }

    @Override
    public int getUnderruns() { return mUnderruns; }

    @Override
    public void flush() {
        if (mTrack == null) return;
        try {
            mTrack.pause();
            mTrack.flush();
        } catch (Throwable ignored) {
        }
        mFramesWritten = 0;
        mFramesPlayed = 0;
        mLastHead = 0;
        mHeadWrapCount = 0;
        mBasePtsUs = 0;
        mMediaFrames = 0;
        synchronized (mLock) {
            mHoldFrames = 0;
            if (mWsola != null) mWsola.reset();
        }
        if (mStarted) {
            mTrack.play();
        }
    }

    @Override
    public void start() {
        if (mTrack == null) return;
        try {
            mTrack.play();
            mStarted = true;
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void pause() {
        if (mTrack == null) return;
        try {
            mTrack.pause();
            mStarted = false;
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void setSpeed(float speed) {
        if (speed < 0.1f) speed = 0.1f;
        if (speed > 8.0f) speed = 8.0f;
        mSpeed = speed;
        if (mTrack == null) return;
        if (wsolaActive()) {
            // WSOLA 模式：设备按 1x 播放，时间缩放由本类完成
            mTimeScale = speed;
            setDeviceRate(1000);
        } else {
            // 设备侧重采样模式：音调随倍速变化，CPU 更低
            mTimeScale = 1.0f;
            setDeviceRate(Math.round(speed * 1000f));
        }
    }

    @Override
    public void setPitchPreserve(boolean preserve) {
        if (mPitchPreserve == preserve) return;
        mPitchPreserve = preserve;
        // 模式切换：遗留保持缓冲按原模式丢弃/复位，避免新旧缩放混淆
        synchronized (mLock) {
            mHoldFrames = 0;
            if (mWsola != null) mWsola.reset();
        }
        setSpeed(mSpeed);
    }

    private void setDeviceRate(int permille) {
        if (permille == mSpeedPm) return;
        try {
            mTrack.setPlaybackRate(permille);
            mSpeedPm = permille;
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void close() {
        if (mTrack != null) {
            try {
                mTrack.pause();
                mTrack.flush();
                mTrack.release();
            } catch (Throwable ignored) {
            }
            mTrack = null;
        }
        synchronized (mLock) {
            mHold = null;
            mHoldFrames = 0;
            mWsola = null;
        }
    }
}
