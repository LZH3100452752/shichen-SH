package com.hwdecoder;

/**
 * 性能统计采集器（线程安全）。
 * <p>
 * 采集解码帧率、丢帧率、码率、缓冲水位、underrun 等关键指标，
 * 既可用于 UI 展示，也可用于自适应策略决策。
 */
public final class StatsCollector {

    /** 统计快照 */
    public static final class Stats {
        public long videoDecoded;      // 累计解码视频帧
        public long videoDropped;      // 累计丢弃视频帧
        public long videoRendered;     // 累计渲染视频帧
        public long videoSkipped;      // 累计解封装层跳过的帧（高倍速抽帧）
        public long audioDecoded;      // 累计解码音频采样（帧）
        public long audioUnderruns;    // 音频输出欠载次数
        public long bytesDecoded;      // 累计解封装字节数
        public double videoFps;        // 区间瞬时解码帧率
        public double audioFps;        // 区间瞬时音频帧率
        public double dropRatio;       // 丢帧率 0~1
        public double bitrateKbps;     // 区间瞬时码率
        public int videoQueueSize;     // 视频解码在途帧数（估算）
        public int audioBufferMs;      // 音频输出缓冲时长（ms）
        public long positionUs;
        public long uptimeMs;
        public String videoCodec = "";
        public String audioCodec = "";
        public boolean hardwareVideo;
        public boolean hardwareAudio;
        public double avgSpeed = 1.0;
    }

    private final Stats mStats = new Stats();
    private final Object mLock = new Object();

    private long mLastVideoDecoded;
    private long mLastAudioDecoded;
    private long mLastBytes;
    private long mLastTickNs;
    private long mStartNs = System.nanoTime();

    public StatsCollector() {
        mLastTickNs = mStartNs;
    }

    public void onVideoDecoded() {
        synchronized (mLock) {
            mStats.videoDecoded++;
        }
    }

    public void onVideoDropped() {
        synchronized (mLock) {
            mStats.videoDropped++;
        }
    }

    public void onVideoRendered() {
        synchronized (mLock) {
            mStats.videoRendered++;
        }
    }

    /** 解封装层跳过的帧（高倍速抽帧，未进解码器） */
    public void onVideoSkipped() {
        synchronized (mLock) {
            mStats.videoSkipped++;
        }
    }

    public void onAudioDecoded(long frames) {
        synchronized (mLock) {
            mStats.audioDecoded += frames;
        }
    }

    public void onAudioUnderrun() {
        synchronized (mLock) {
            mStats.audioUnderruns++;
        }
    }

    public void onBytesDecoded(long bytes) {
        synchronized (mLock) {
            mStats.bytesDecoded += bytes;
        }
    }

    public void setCodecInfo(String videoCodec, boolean hwVideo, String audioCodec, boolean hwAudio) {
        synchronized (mLock) {
            mStats.videoCodec = videoCodec;
            mStats.hardwareVideo = hwVideo;
            mStats.audioCodec = audioCodec;
            mStats.hardwareAudio = hwAudio;
        }
    }

    public void setVideoQueueSize(int n) {
        synchronized (mLock) {
            mStats.videoQueueSize = n;
        }
    }

    public void setAudioBufferMs(int ms) {
        synchronized (mLock) {
            mStats.audioBufferMs = ms;
        }
    }

    public void setPosition(long us) {
        synchronized (mLock) {
            mStats.positionUs = us;
        }
    }

    /**
     * 计算一个采样间隔的快照（会重置区间计数器）。
     */
    public Stats snapshot() {
        Stats out = new Stats();
        long now = System.nanoTime();
        synchronized (mLock) {
            out.videoDecoded = mStats.videoDecoded;
            out.videoDropped = mStats.videoDropped;
            out.videoRendered = mStats.videoRendered;
            out.videoSkipped = mStats.videoSkipped;
            out.audioDecoded = mStats.audioDecoded;
            out.audioUnderruns = mStats.audioUnderruns;
            out.bytesDecoded = mStats.bytesDecoded;
            out.videoQueueSize = mStats.videoQueueSize;
            out.audioBufferMs = mStats.audioBufferMs;
            out.positionUs = mStats.positionUs;
            out.videoCodec = mStats.videoCodec;
            out.audioCodec = mStats.audioCodec;
            out.hardwareVideo = mStats.hardwareVideo;
            out.hardwareAudio = mStats.hardwareAudio;

            double elapsedSec = (now - mLastTickNs) / 1e9;
            if (elapsedSec > 0.0001) {
                out.videoFps = (mStats.videoDecoded - mLastVideoDecoded) / elapsedSec;
                out.audioFps = (mStats.audioDecoded - mLastAudioDecoded) / elapsedSec;
                out.bitrateKbps = (mStats.bytesDecoded - mLastBytes) * 8.0 / 1000.0 / elapsedSec;
            }
            mLastVideoDecoded = mStats.videoDecoded;
            mLastAudioDecoded = mStats.audioDecoded;
            mLastBytes = mStats.bytesDecoded;
            mLastTickNs = now;
            out.uptimeMs = (now - mStartNs) / 1_000_000L;
        }
        long total = out.videoDecoded;
        if (total > 0) {
            out.dropRatio = (double) out.videoDropped / (double) total;
        }
        return out;
    }
}
