package com.hwdecoder;

/**
 * 播放器状态机。
 */
public enum PlayerState {
    /** 空闲（未设置数据源或已停止） */
    IDLE,
    /** 已设置数据源，尚未 prepare */
    INITIALIZED,
    /** 正在异步 prepare（打开文件、选择解码器） */
    PREPARING,
    /** prepare 完成，可以播放 */
    PREPARED,
    /** 播放中 */
    PLAYING,
    /** 已暂停 */
    PAUSED,
    /** seek 中 */
    SEEKING,
    /** 缓冲中（网络流卡顿） */
    BUFFERING,
    /** 播放完成 */
    COMPLETED,
    /** 已停止 */
    STOPPED,
    /** 出错 */
    ERROR,
    /** 已释放 */
    RELEASED;

    public boolean isPlayable() {
        return this == PLAYING || this == PAUSED || this == SEEKING;
    }
}
