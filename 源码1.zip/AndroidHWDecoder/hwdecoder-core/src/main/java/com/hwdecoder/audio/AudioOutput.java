package com.hwdecoder.audio;

/**
 * 音频输出抽象。实现类：AudioTrackOutput（Framework 主路）、
 * OpenSLOutput（NDK 低延迟 + 原生 DSP + 原生重采样变速）。
 */
public interface AudioOutput {

    int RESULT_OK = 0;
    int RESULT_ERROR_INIT = -1;
    int RESULT_ERROR_WRITE = -2;

    /**
     * 打开输出。
     *
     * @param sampleRate  解码输出采样率
     * @param channels    声道数
     * @param bufferMs    缓冲时长
     * @param lowLatency  是否请求低延迟模式
     * @return RESULT_OK 或错误码
     */
    int open(int sampleRate, int channels, int bufferMs, boolean lowLatency);

    /**
     * 写入一段 PCM（float，交错）。阻塞直到写完或出错。
     *
     * @param ptsUs 该段起始时间戳（用于时钟同步）
     * @return 写入的帧数；<0 表示错误
     */
    int write(float[] data, int off, int len, long ptsUs);

    /** 当前媒体播放位置（us），用于视频同步 */
    long getPlaybackPositionUs();

    /** 输出缓冲时长（ms） */
    int getBufferedMs();

    /**
     * 输出是否自行管理缓冲（如 OpenSL ES 有原生环形缓冲 + 预填充机制）。
     * 返回 true 时调用方无需做起播预缓冲。
     */
    boolean managesOwnBuffering();

    /** 欠载次数 */
    int getUnderruns();

    void flush();

    void start();

    void pause();

    /**
     * 设置倍速（0.25 ~ 8.0）。
     * 实现语义：AudioTrack 后端在 pitchPreserve 开启时用 WSOLA 时间缩放（音调不变），
     * 关闭时交设备侧重采样（音调随倍速变化）；OpenSL ES 后端同理走原生重采样。
     */
    void setSpeed(float speed);

    /**
     * 变速时是否保持音调（WSOLA 时间缩放）。
     * 需在 {@link #setSpeed(float)} 之前或之后调用均可生效。
     */
    void setPitchPreserve(boolean preserve);

    /**
     * 排空内部缓冲（EOS 时调用）。
     * 有变速保持缓冲的实现应将剩余媒体帧送出；无缓冲的实现可为空操作。
     */
    void drain();

    void close();
}
