package com.hwdecoder;

/**
 * 主时钟（AV 同步基准）。
 * <p>
 * 以 System.nanoTime()（单调时钟，不受系统时间调整影响）为基准，
 * 支持暂停、变速、位置重置。视频渲染线程以此为同步基准；
 * 有音频轨时由音频渲染器持续以实际播放位置校准，保证长时播放不漂移。
 */
public final class MediaClock {

    private long mBaseMediaUs;   // 速度/暂停变更时的媒体时间锚点
    private long mBaseRealNs;    // 对应的单调时钟锚点
    private float mSpeed = 1.0f;
    private boolean mPaused;

    public MediaClock() {
        mBaseMediaUs = 0L;
        mBaseRealNs = System.nanoTime();
    }

    /** 当前媒体时间（us） */
    public synchronized long nowUs() {
        if (mPaused) return mBaseMediaUs;
        long elapsedNs = System.nanoTime() - mBaseRealNs;
        double scaledUs = elapsedNs * (double) mSpeed / 1000.0; // ns -> us，再乘速度
        return mBaseMediaUs + (long) scaledUs;
    }

    public synchronized void setPaused(boolean paused) {
        if (mPaused == paused) return;
        if (paused) {
            mBaseMediaUs = nowUsLocked();
        } else {
            mBaseRealNs = System.nanoTime();
        }
        mPaused = paused;
    }

    public synchronized void setSpeed(float speed) {
        float s = speed <= 0f ? 0.01f : speed;
        mBaseMediaUs = nowUsLocked();
        mBaseRealNs = System.nanoTime();
        mSpeed = s;
    }

    /** 设置当前媒体位置（seek 时调用） */
    public synchronized void setPositionUs(long us) {
        mBaseMediaUs = us;
        mBaseRealNs = System.nanoTime();
    }

    /** 音频渲染器校准：以实际输出位置为准，消除累积漂移 */
    public synchronized void alignTo(long actualUs, long realNs) {
        if (mPaused) {
            mBaseMediaUs = actualUs;
            return;
        }
        mBaseMediaUs = actualUs;
        mBaseRealNs = realNs;
    }

    public synchronized boolean isPaused() { return mPaused; }

    public synchronized float getSpeed() { return mSpeed; }

    private long nowUsLocked() {
        if (mPaused) return mBaseMediaUs;
        long elapsedNs = System.nanoTime() - mBaseRealNs;
        double scaledUs = elapsedNs * (double) mSpeed / 1000.0;
        return mBaseMediaUs + (long) scaledUs;
    }
}
