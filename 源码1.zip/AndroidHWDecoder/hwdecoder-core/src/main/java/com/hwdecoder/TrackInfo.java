package com.hwdecoder;

/**
 * 媒体轨道信息（音视频轨选择用）。
 */
public final class TrackInfo {

    public static final int TYPE_VIDEO = 0;
    public static final int TYPE_AUDIO = 1;
    public static final int TYPE_SUBTITLE = 2;
    public static final int TYPE_OTHER = 3;

    /** 轨道在 MediaExtractor 中的索引 */
    public final int index;
    public final int type;
    public final String mime;
    /** 语言（ISO 639-2，可能为 null 或 "und"） */
    public final String language;
    // 视频
    public final int width;
    public final int height;
    // 音频
    public final int sampleRate;
    public final int channelCount;

    TrackInfo(int index, int type, String mime, String language,
              int width, int height, int sampleRate, int channelCount) {
        this.index = index;
        this.type = type;
        this.mime = mime;
        this.language = language;
        this.width = width;
        this.height = height;
        this.sampleRate = sampleRate;
        this.channelCount = channelCount;
    }

    /** 人类可读描述，例如 "音频 · AAC · 立体声 · 英语" */
    public String describe() {
        StringBuilder sb = new StringBuilder();
        switch (type) {
            case TYPE_VIDEO:
                sb.append("视频");
                break;
            case TYPE_AUDIO:
                sb.append("音频");
                break;
            case TYPE_SUBTITLE:
                sb.append("字幕");
                break;
            default:
                sb.append("其它");
                break;
        }
        if (mime != null && mime.contains("/")) {
            sb.append(" · ").append(mime.substring(mime.indexOf('/') + 1).toUpperCase());
        }
        if (type == TYPE_VIDEO && width > 0) {
            sb.append(" · ").append(width).append("×").append(height);
        }
        if (type == TYPE_AUDIO) {
            if (channelCount == 1) sb.append(" · 单声道");
            else if (channelCount == 2) sb.append(" · 立体声");
            else if (channelCount > 2) sb.append(" · ").append(channelCount).append(" 声道");
            if (sampleRate > 0) sb.append(" · ").append(sampleRate / 1000).append("kHz");
        }
        if (language != null && !language.isEmpty() && !"und".equals(language)) {
            sb.append(" · ").append(language);
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        return describe();
    }
}
