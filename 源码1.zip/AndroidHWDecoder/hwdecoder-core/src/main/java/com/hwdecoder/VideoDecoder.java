package com.hwdecoder;

import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.os.Build;
import android.os.Process;
import android.os.SystemClock;
import android.view.Surface;

import java.nio.ByteBuffer;

/**
 * 视频硬件解码单元。
 * <p>
 * 设计要点：
 * 1. 准备（解封装器/解码器创建）与解码循环分离：prepareAsync 在独立线程完成，
 *    解码线程只在用户 start 后运行，避免未播放就解码到文件末尾；
 * 2. 解码线程运行在独立高优先级线程（THREAD_PRIORITY_URGENT_DISPLAY）并绑定大核；
 * 3. MediaCodec 同步模式 + 独立 MediaExtractor，避免与音频线程争抢解封装器；
 * 4. 输出直接渲染到 Surface（零拷贝，无 CPU 回读）；
 * 5. 自适应丢帧：迟到超过阈值直接 releaseOutputBuffer(render=false)；
 *    阈值随倍速与帧间隔自适应，高倍速下不误丢、不迟滞；
 * 6. 呈现前精确 sleep，且等待期间持续喂输入——解码器始终饱和，无流水线饥饿；
 * 7. 高倍速抽帧：在解封装层按倍速间隔跳过不显示的帧（根本性降低解码负载），
 *    8 倍速也只解码约 1/8 的帧，音画仍按音频主时钟同步；
 * 8. seek 后按策略丢弃目标时间之前的帧，保证起播位置准确；
 * 9. 支持 Surface 热切换（API 23+ 用 setOutputSurface，低版本自动重启解码器）；
 * 10. 解码分辨率限制（硬件缩放）降低功耗与内存带宽；
 * 11. 硬件解码失败自动回退软件解码（按 CodecSelector 候选列表逐一尝试）；
 * 12. 渲染门控：起播预缓冲期间丢弃预热帧，门控打开后与音频时钟严格对齐；
 * 13. 单帧步进（暂停态逐帧前进）、HDR 信息检测上报。
 */
final class VideoDecoder implements Runnable {

    /** 与宿主（HWDecoder）的交互接口 */
    interface Host {
        DecoderConfig config();

        MediaClock clock();

        StatsCollector stats();

        Surface surface();

        int surfaceWidth();

        int surfaceHeight();

        android.content.Context context();

        /** 解码器创建成功（输出格式已知） */
        void onVideoReady(String codecName, boolean hardware, int width, int height);

        /** seek 后首帧已渲染 */
        void onFirstFrameAfterSeek(long ptsUs);

        /** 视频流结束，或不存在视频轨 */
        void onVideoEos();

        /** 输出格式变化（分辨率/旋转） */
        void onVideoOutputFormatChanged(int width, int height);

        /** HDR 信息变化（PQ/HLG） */
        void onVideoHdrChanged(boolean hdr);

        /** 单帧步进完成（暂停态） */
        void onFrameStepped(long ptsUs);

        void onDecoderError(int errorCode, String message);
    }

    private static final long INPUT_TIMEOUT_US = 10_000L;
    private static final long STEP_DEQUEUE_TIMEOUT_US = 2_000_000L;
    private static final long PAUSE_POLL_MS = 20L;
    private static final int SLICE_SLEEP_MS = 2;      // 等待切片粒度
    private static final int FEED_AHEAD_MS = 6;       // 剩余等待超过该值才喂输入

    private final Host mHost;
    private final String mSource;
    private final android.content.Context mContext;

    private MediaExtractor mExtractor;
    private MediaCodec mCodec;
    private String mMime;
    private String mCodecName;
    private boolean mHardware;
    private Thread mDecodeThread;

    private volatile boolean mQuit;
    private volatile boolean mPaused;
    private volatile boolean mPrepared;
    private volatile boolean mSeekRequested;
    private volatile long mSeekTargetUs;
    private volatile long mSkipUntilUs = Long.MIN_VALUE;
    private volatile boolean mInputEos;
    private volatile boolean mOutputEos;
    private volatile boolean mEosDelivered;
    private volatile boolean mAwaitingFirstFrameAfterSeek;
    private volatile Surface mSurface;
    private int mTargetWidth, mTargetHeight;
    private int mSrcWidth, mSrcHeight;

    // ---- 渲染门控（起播预缓冲）----
    private volatile boolean mRenderGate = true; // false = 预热期，丢弃渲染

    // ---- 单帧步进 ----
    private volatile boolean mStepPending;

    // ---- 高倍速解封装抽帧 ----
    private long mNextFeedPtsUs = Long.MIN_VALUE; // 下一个应送入解码的 pts
    private long mLastFedPtsUs = Long.MIN_VALUE;
    private long mAvgFrameIntervalUs;             // EMA 帧间隔（0 = 未估计）

    // ---- HDR ----
    private volatile boolean mHdr;
    private boolean mHdrReported;

    private final MediaCodec.BufferInfo mBufferInfo = new MediaCodec.BufferInfo();

    VideoDecoder(Host host, String source) {
        mHost = host;
        mSource = source;
        mContext = host.context();
        mSurface = host.surface();
    }

    // ---------------- 生命周期 ----------------

    /** 在独立线程完成准备（打开源、选择并创建解码器） */
    void prepareAsync() {
        Thread t = new Thread(() -> {
            Process.setThreadPriority(Process.THREAD_PRIORITY_DEFAULT);
            try {
                if (prepare()) {
                    mPrepared = true;
                    mHost.onVideoReady(mCodecName, mHardware, mSrcWidth, mSrcHeight);
                }
            } catch (Throwable t2) {
                mHost.onDecoderError(HWDecoder.ERROR_PREPARE,
                        "video prepare failed: " + t2);
            }
        }, "hwdec-video-prepare");
        t.start();
    }

    /** 开始解码循环（幂等） */
    private void ensureDecodeThreadStarted() {
        if (mDecodeThread != null || !mPrepared) return;
        mQuit = false;
        mDecodeThread = new Thread(this, "hwdec-video");
        mDecodeThread.start();
    }

    void pause() {
        mPaused = true;
    }

    void resumePlayback() {
        mPaused = false;
        ensureDecodeThreadStarted();
    }

    void requestSeek(long targetUs) {
        if (!mPrepared) return;
        mSeekTargetUs = targetUs;
        mSeekRequested = true;
        mAwaitingFirstFrameAfterSeek = true;
        mSkipUntilUs = Long.MIN_VALUE; // 由 doSeek 按策略重置
        mNextFeedPtsUs = Long.MIN_VALUE;
    }

    /** 渲染门控：起播预缓冲期间关闭，音频就绪后打开 */
    void setRenderGate(boolean open) {
        mRenderGate = open;
    }

    /** 单帧步进（暂停态调用） */
    void stepFrame() {
        mStepPending = true;
    }

    void setSurface(Surface surface) {
        if (surface == null || surface == mSurface) return;
        if (mCodec == null || !mPrepared) {
            mSurface = surface;
            return;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                mCodec.setOutputSurface(surface);
                mSurface = surface;
                return;
            } catch (Throwable ignored) {
                // 落到重启逻辑
            }
        }
        mSurface = surface;
        restartCodec();
    }

    void quit() {
        mQuit = true;
        mPaused = false;
    }

    boolean isDone() {
        return mOutputEos;
    }

    // ---------------- 解码主循环 ----------------

    @Override
    public void run() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY);
        // 解码线程绑定大核：高倍速/高分辨率场景的算力保障（默认关闭，按需开启）
        if (mHost.config() != null && mHost.config().isBigCoreBinding() && NativeLib.isAvailable()) {
            try {
                NativeLib.nativeBindThreadToBigCore();
            } catch (Throwable ignored) {
                // 个别设备/内核不支持 affinity 设置，静默降级
            }
        }
        try {
            while (!mQuit) {
                if (mSeekRequested) {
                    doSeek();
                    continue;
                }
                if (mOutputEos) {
                    if (!mEosDelivered) {
                        mEosDelivered = true;
                        mHost.onVideoEos();
                    }
                    break;
                }
                if (mPaused) {
                    if (mStepPending) {
                        mStepPending = false;
                        stepOneFrame();
                    } else {
                        SystemClock.sleep(PAUSE_POLL_MS);
                    }
                    continue;
                }
                feedInput();
                drainOutput();
            }
        } catch (Throwable t) {
            if (!mQuit) {
                mHost.onDecoderError(HWDecoder.ERROR_DECODE,
                        "video decode failed: " + t);
            }
        } finally {
            releaseCodec();
            mDecodeThread = null;
        }
    }

    // ---------------- 初始化 ----------------

    private boolean prepare() {
        mExtractor = new MediaExtractor();
        try {
            setDataSource(mExtractor, mSource, mContext);
        } catch (Throwable t) {
            mHost.onDecoderError(HWDecoder.ERROR_PREPARE, "open video source failed: " + t);
            return false;
        }

        int track = -1;
        for (int i = 0; i < mExtractor.getTrackCount(); i++) {
            MediaFormat f = mExtractor.getTrackFormat(i);
            String mime = f.getString(MediaFormat.KEY_MIME);
            if (mime != null && mime.startsWith("video/")) {
                track = i;
                break;
            }
        }
        if (track < 0) {
            // 纯音频文件：不算错误，视频单元视为已完成
            mOutputEos = true;
            mHost.onVideoEos();
            return false;
        }
        mExtractor.selectTrack(track);
        MediaFormat format = mExtractor.getTrackFormat(track);
        mMime = format.getString(MediaFormat.KEY_MIME);
        try {
            mSrcWidth = format.getInteger(MediaFormat.KEY_WIDTH);
            mSrcHeight = format.getInteger(MediaFormat.KEY_HEIGHT);
        } catch (Throwable ignored) {
            mSrcWidth = 0;
            mSrcHeight = 0;
        }
        detectHdr(format);
        computeTargetSize();

        // 选择解码器（硬件优先，失败逐个回退）
        DecoderConfig cfg = mHost.config();
        boolean created = false;
        Throwable lastError = null;
        for (MediaCodecInfo info : CodecSelector.candidates(mMime)) {
            boolean hw = CodecSelector.isHardwareAccelerated(info);
            if (cfg.isHardwareOnly() && !hw) continue;
            if (!cfg.isSoftwareFallback() && !hw) continue;
            if (CodecSelector.shouldAvoidHardware(mMime, info.getName())) continue;
            try {
                mCodec = MediaCodec.createByCodecName(info.getName());
                mCodecName = info.getName();
                mHardware = hw;
                created = configureCodec(format, cfg);
                if (created) break;
            } catch (Throwable t) {
                lastError = t;
                releaseCodec();
                mCodec = null;
            }
        }
        if (!created) {
            mHost.onDecoderError(HWDecoder.ERROR_UNSUPPORTED,
                    "no decoder for " + mMime + (lastError != null ? ": " + lastError : ""));
            return false;
        }
        mHost.stats().setCodecInfo(mCodecName, mHardware, null, false);
        return true;
    }

    private boolean configureCodec(MediaFormat srcFormat, DecoderConfig cfg) {
        MediaFormat format = new MediaFormat();
        // 从源格式拷贝 csd / mime 等关键信息
        try {
            String mime = srcFormat.getString(MediaFormat.KEY_MIME);
            format.setString(MediaFormat.KEY_MIME, mime != null ? mime : mMime);
        } catch (Throwable ignored) {
            format.setString(MediaFormat.KEY_MIME, mMime);
        }
        format.setInteger(MediaFormat.KEY_WIDTH, mSrcWidth > 0 ? mSrcWidth : 1920);
        format.setInteger(MediaFormat.KEY_HEIGHT, mSrcHeight > 0 ? mSrcHeight : 1080);
        copyCsd(srcFormat, format);
        if (mTargetWidth > 0 && mTargetHeight > 0
                && (mTargetWidth < mSrcWidth || mTargetHeight < mSrcHeight)) {
            // 交给硬件缩放器解码到目标分辨率（省电、降带宽）
            format.setInteger(MediaFormat.KEY_WIDTH, mTargetWidth);
            format.setInteger(MediaFormat.KEY_HEIGHT, mTargetHeight);
        }
        format.setInteger(MediaFormat.KEY_PRIORITY, 0); // 实时优先级
        // 低延迟解码提示（部分 Opus/VP9/AV1 硬件解码器支持）
        try {
            format.setInteger(MediaFormat.KEY_LOW_LATENCY, 1);
        } catch (Throwable ignored) {
        }
        mCodec.configure(format, mSurface, null, 0);
        mCodec.start();
        mInputEos = false;
        mOutputEos = false;
        detectHdr(mCodec.getOutputFormat());
        return true;
    }

    /** HDR 检测：PQ(ST2084) 或 HLG 传输函数视为 HDR */
    private void detectHdr(MediaFormat fmt) {
        if (fmt == null) return;
        boolean hdr = false;
        try {
            int transfer = fmt.getInteger(MediaFormat.KEY_COLOR_TRANSFER);
            hdr = transfer == 6 /* COLOR_TRANSFER_ST2084 */
                    || transfer == 7 /* COLOR_TRANSFER_HLG */;
        } catch (Throwable ignored) {
        }
        if (hdr != mHdr) {
            mHdr = hdr;
            if (!mHdrReported) {
                mHdrReported = true;
                mHost.onVideoHdrChanged(hdr);
            }
        }
    }

    private void copyCsd(MediaFormat src, MediaFormat dst) {
        try {
            ByteBuffer csd0 = src.getByteBuffer("csd-0");
            if (csd0 != null) dst.setByteBuffer("csd-0", csd0);
        } catch (Throwable ignored) {
        }
        try {
            ByteBuffer csd1 = src.getByteBuffer("csd-1");
            if (csd1 != null) dst.setByteBuffer("csd-1", csd1);
        } catch (Throwable ignored) {
        }
        try {
            ByteBuffer csd2 = src.getByteBuffer("csd-2");
            if (csd2 != null) dst.setByteBuffer("csd-2", csd2);
        } catch (Throwable ignored) {
        }
    }

    /** 计算解码目标分辨率：不超过配置上限与 Surface 大小 */
    private void computeTargetSize() {
        if (mSrcWidth <= 0 || mSrcHeight <= 0) {
            mTargetWidth = 0;
            mTargetHeight = 0;
            return;
        }
        int maxW = mHost.config().getMaxVideoWidth();
        int maxH = mHost.config().getMaxVideoHeight();
        if (maxW <= 0) maxW = mHost.surfaceWidth();
        if (maxH <= 0) maxH = mHost.surfaceHeight();
        if (maxW <= 0 || maxH <= 0) {
            mTargetWidth = mSrcWidth;
            mTargetHeight = mSrcHeight;
            return;
        }
        if (mSrcWidth <= maxW && mSrcHeight <= maxH) {
            mTargetWidth = mSrcWidth;
            mTargetHeight = mSrcHeight;
            return;
        }
        float ratio = Math.min((float) maxW / mSrcWidth, (float) maxH / mSrcHeight);
        mTargetWidth = align16((int) (mSrcWidth * ratio));
        mTargetHeight = align16((int) (mSrcHeight * ratio));
    }

    private static int align16(int v) {
        return Math.max(16, (v + 15) & ~15);
    }

    // ---------------- 送数据 / 收帧 ----------------

    /**
     * 送入一帧（可能因高倍速抽帧而跳过）。
     * 抽帧在解封装层完成：不显示的帧直接 advance，不进解码器——
     * 这是高倍速下降低解码负载的根本手段（8 倍速只解 ~1/8 的帧）。
     */
    private void feedInput() {
        if (mInputEos || mCodec == null || mExtractor == null) return;

        float speed = mHost.clock().getSpeed();
        int skip = speed > 1.05f ? Math.max(1, Math.round(speed)) : 1;
        if (skip > 1 && mNextFeedPtsUs != Long.MIN_VALUE) {
            long pts = mExtractor.getSampleTime();
            if (pts >= 0 && pts < mNextFeedPtsUs) {
                mExtractor.advance(); // 跳过：不解码、不上屏
                mHost.stats().onVideoSkipped();
                return;
            }
        }

        int idx = mCodec.dequeueInputBuffer(INPUT_TIMEOUT_US);
        if (idx < 0) return;
        ByteBuffer buffer = mCodec.getInputBuffer(idx);
        if (buffer == null) return;
        int size = mExtractor.readSampleData(buffer, 0);
        if (size < 0) {
            mCodec.queueInputBuffer(idx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
            mInputEos = true;
            return;
        }
        long pts = mExtractor.getSampleTime();
        int flags = 0;
        if ((mExtractor.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0) {
            flags |= MediaCodec.BUFFER_FLAG_KEY_FRAME;
        }
        mCodec.queueInputBuffer(idx, 0, size, pts, flags);
        mHost.stats().onBytesDecoded(size);

        // 帧间隔估计（EMA）与下一次喂入目标
        if (mLastFedPtsUs != Long.MIN_VALUE && pts > mLastFedPtsUs) {
            long d = pts - mLastFedPtsUs;
            mAvgFrameIntervalUs = mAvgFrameIntervalUs <= 0 ? d
                    : (mAvgFrameIntervalUs * 3 + d) / 4;
        }
        mLastFedPtsUs = pts;
        if (skip > 1) {
            long interval = mAvgFrameIntervalUs > 0 ? mAvgFrameIntervalUs : 33_333L;
            mNextFeedPtsUs = pts + (long) (skip * interval);
        }
        mExtractor.advance();
    }

    private void drainOutput() {
        int idx = mCodec.dequeueOutputBuffer(mBufferInfo, INPUT_TIMEOUT_US);
        if (idx >= 0) {
            long pts = mBufferInfo.presentationTimeUs;
            boolean render = decideRender(pts);
            if (render) {
                mCodec.releaseOutputBuffer(idx, true);
                mHost.stats().onVideoRendered();
                if (mAwaitingFirstFrameAfterSeek) {
                    mAwaitingFirstFrameAfterSeek = false;
                    mHost.onFirstFrameAfterSeek(pts);
                }
            } else {
                mCodec.releaseOutputBuffer(idx, false);
                mHost.stats().onVideoDropped();
            }
            mHost.stats().onVideoDecoded();
            if ((mBufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                mOutputEos = true;
            }
        } else if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
            try {
                MediaFormat fmt = mCodec.getOutputFormat();
                int w = fmt.getInteger(MediaFormat.KEY_WIDTH);
                int h = fmt.getInteger(MediaFormat.KEY_HEIGHT);
                mHost.onVideoOutputFormatChanged(w, h);
                detectHdr(fmt);
            } catch (Throwable ignored) {
            }
        }
    }

    /** 暂停态单帧步进：取一帧立即渲染（不按时钟等待） */
    private void stepOneFrame() {
        if (mCodec == null) return;
        feedInput();
        int idx = mCodec.dequeueOutputBuffer(mBufferInfo, STEP_DEQUEUE_TIMEOUT_US);
        if (idx < 0) return;
        long pts = mBufferInfo.presentationTimeUs;
        if (mSkipUntilUs != Long.MIN_VALUE) {
            if (pts < mSkipUntilUs) {
                mCodec.releaseOutputBuffer(idx, false);
                mHost.stats().onVideoDropped();
                if ((mBufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    mOutputEos = true;
                }
                return;
            }
            mSkipUntilUs = Long.MIN_VALUE;
        }
        mCodec.releaseOutputBuffer(idx, true);
        mHost.stats().onVideoRendered();
        mHost.stats().onVideoDecoded();
        mHost.onFrameStepped(pts);
        if ((mBufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
            mOutputEos = true;
        }
    }

    /**
     * 渲染决策：丢帧 / 等待 / 立即渲染。
     * <p>
     * - 起播预缓冲门控未开：一律丢弃（预热帧，音频时钟尚未启动）；
     * - seek 后丢弃目标时间之前的帧；
     * - 迟到超过自适应阈值：丢帧保同步；
     * - 超前超过自适应阈值：立即渲染，避免流水线停顿；
     * - 否则精确等待到呈现时刻（等待期间持续喂输入，解码器不饥饿）。
     */
    private boolean decideRender(long ptsUs) {
        if (!mRenderGate) return false;

        // seek 后丢弃目标时间之前的帧
        if (mSkipUntilUs != Long.MIN_VALUE) {
            if (ptsUs < mSkipUntilUs) return false;
            mSkipUntilUs = Long.MIN_VALUE;
        }

        long now = mHost.clock().nowUs();
        long diff = ptsUs - now;
        long dropMs = effectiveDropMs();
        if (diff <= -dropMs * 1000L) {
            return false; // 迟到过多：丢帧保同步
        }
        long holdMs = effectiveHoldMs();
        if (diff > holdMs * 1000L) {
            return true;  // 超前过多：直接渲染，避免流水线停顿
        }
        if (diff > 0) {
            waitWithFeeding(diff / 1000L);
        }
        return true;
    }

    /**
     * 自适应丢帧阈值：高倍速下输出帧间隔变大（倍速 × 帧间隔），
     * 阈值需随之放宽，否则会把正常帧误判为迟到。
     */
    private long effectiveDropMs() {
        long base = mHost.config().getMaxFrameDropMs();
        long frameMs = frameIntervalMs();
        float speed = mHost.clock().getSpeed();
        long adaptive = (long) (speed * frameMs);
        return Math.max(base, adaptive);
    }

    /** 自适应保持阈值：超前超过该值直接渲染 */
    private long effectiveHoldMs() {
        long base = mHost.config().getMaxHoldMs();
        long frameMs = frameIntervalMs();
        float speed = mHost.clock().getSpeed();
        long adaptive = (long) (2.5 * speed * frameMs);
        return Math.max(base, adaptive);
    }

    private long frameIntervalMs() {
        long us = mAvgFrameIntervalUs > 0 ? mAvgFrameIntervalUs : 33_333L;
        return Math.max(8L, us / 1000L);
    }

    /**
     * 精确等待到呈现时刻，且等待期间持续喂输入。
     * <p>
     * 这是「解码/呈现流水线饱和」的关键：传统实现等待期间停止喂输入，
     * 解码器输入队列耗尽后停转，恢复供数时已产生延迟；本实现保持输入队列
     * 常满，解码器始终有活干，呈现时刻到来时帧已备好。
     */
    private void waitWithFeeding(long ms) {
        if (ms <= 0) return;
        long deadlineNs = System.nanoTime() + ms * 1_000_000L;
        while (true) {
            long remainNs = deadlineNs - System.nanoTime();
            if (remainNs <= 0) break;
            if (mQuit || mPaused || mSeekRequested) break;
            long remainMs = remainNs / 1_000_000L;
            if (remainMs > FEED_AHEAD_MS) {
                feedInput(); // 保持解码器饱和
                SystemClock.sleep(SLICE_SLEEP_MS);
            } else if (remainMs > 2) {
                SystemClock.sleep(remainMs / 2);
            }
            // 最后 2ms 忙等，保证呈现精度
        }
        while (System.nanoTime() < deadlineNs) {
            if (mQuit || mPaused || mSeekRequested) break;
            // 忙等
        }
    }

    // ---------------- seek / 释放 ----------------

    private void doSeek() {
        long target = mSeekTargetUs;
        mSeekRequested = false;
        try {
            if (mCodec != null) {
                mCodec.flush();
                mCodec.start();
            }
            mExtractor.seekTo(target, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            mInputEos = false;
            mOutputEos = false;
            mEosDelivered = false;
            mAwaitingFirstFrameAfterSeek = true;
            mSkipUntilUs = mHost.config().getSeekMode() == DecoderConfig.SeekMode.PRECISE
                    ? target : Long.MIN_VALUE;
            mNextFeedPtsUs = Long.MIN_VALUE;
            mLastFedPtsUs = Long.MIN_VALUE;
        } catch (Throwable t) {
            mHost.onDecoderError(HWDecoder.ERROR_DECODE, "video seek failed: " + t);
        }
    }

    private void restartCodec() {
        try {
            if (mCodec != null) {
                mCodec.stop();
                mCodec.reset();
                configureCodec(mExtractor.getTrackFormat(currentTrackIndex()), mHost.config());
            }
        } catch (Throwable t) {
            mHost.onDecoderError(HWDecoder.ERROR_SURFACE, "video restart failed: " + t);
        }
    }

    private int currentTrackIndex() {
        for (int i = 0; i < mExtractor.getTrackCount(); i++) {
            MediaFormat f = mExtractor.getTrackFormat(i);
            String mime = f.getString(MediaFormat.KEY_MIME);
            if (mime != null && mime.startsWith("video/")) return i;
        }
        return 0;
    }

    private void releaseCodec() {
        if (mCodec != null) {
            try {
                mCodec.stop();
            } catch (Throwable ignored) {
            }
            try {
                mCodec.release();
            } catch (Throwable ignored) {
            }
            mCodec = null;
        }
        if (mExtractor != null) {
            try {
                mExtractor.release();
            } catch (Throwable ignored) {
            }
            mExtractor = null;
        }
    }

    // ---------------- 工具 ----------------

    private static void setDataSource(MediaExtractor extractor, String source,
                                      android.content.Context context) throws Exception {
        if (source == null) throw new IllegalArgumentException("null source");
        if (source.startsWith("content://") && context != null) {
            // content:// Uri 必须走 Context 重载，部分 ROM 上字符串重载不支持
            extractor.setDataSource(context, android.net.Uri.parse(source), null);
        } else {
            extractor.setDataSource(source);
        }
    }
}
