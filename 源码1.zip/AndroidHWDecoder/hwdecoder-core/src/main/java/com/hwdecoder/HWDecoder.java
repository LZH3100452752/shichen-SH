package com.hwdecoder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.PixelCopy;
import android.view.Surface;
import android.view.SurfaceView;
import android.view.TextureView;

import java.util.ArrayList;
import java.util.List;

/**
 * 硬件解码播放器门面类（对外唯一入口）。
 * <p>
 * 架构：
 * <pre>
 *   HWDecoder（门面/状态机/时钟/播放列表）
 *     ├── VideoDecoder（独立线程：解封装+硬解+上屏，含丢帧/抽帧策略）
 *     └── AudioDecoder（独立线程：解封装+硬解+DSP链+输出，音频主时钟）
 * </pre>
 * <p>
 * 功能：H.264/H.265/VP8/VP9/AV1 视频硬解、AAC/MP3/Opus/FLAC/AMR 音频硬解、
 * 音画同步、seek、倍速（0.25~8，WSOLA 变速不变调）、音量放大（0~800%）、
 * 10 段 EQ、动态处理、响度归一化、声道路由、频谱可视化、A-B 循环、单帧步进、
 * 多音轨选择、截图、播放列表、双音频后端（AudioTrack / OpenSL ES）、
 * 性能统计、Surface 热切换、起播预缓冲、大核绑定、耳机拔出自动暂停。
 */
public final class HWDecoder implements VideoDecoder.Host, AudioDecoder.Host {

    // ---- 错误码 ----
    public static final int ERROR_PREPARE = 1;
    public static final int ERROR_DECODE = 2;
    public static final int ERROR_SURFACE = 3;
    public static final int ERROR_UNSUPPORTED = 4;
    public static final int ERROR_AUDIO_DEVICE = 5;

    private static final long PROGRESS_INTERVAL_MS = 250L;
    private static final long SEEK_RECOVER_TIMEOUT_MS = 1200L;

    private final Context mContext;
    private final Handler mMain = new Handler(Looper.getMainLooper());

    private DecoderConfig mConfig;
    private HWDecoderListener mListener;
    private volatile PlayerState mState = PlayerState.IDLE;

    private MediaClock mClock;
    private StatsCollector mStats;
    private PlayList mPlayList;

    private VideoDecoder mVideo;
    private AudioDecoder mAudio;
    private AudioProcessorChain mDspChain;

    private long mDurationUs;
    private int mVideoWidth;
    private int mVideoHeight;
    private volatile int mSurfaceWidth;
    private volatile int mSurfaceHeight;

    private boolean mVideoEos;
    private boolean mAudioEos;
    private volatile boolean mVideoReady;
    private volatile boolean mAudioReady;
    private volatile boolean mPreparedNotified;
    private PlayerState mStateBeforeSeek = PlayerState.PAUSED;
    private volatile boolean mReleased;
    private volatile boolean mPreparing;
    private volatile long mAutoSeekAfterPrepare = -1L;
    private volatile boolean mSuppressAutoPlay;

    // ---- 音轨选择 ----
    private int mAudioTrackIndex = -1; // -1 = 第一个音频轨
    private volatile boolean mAudioTrackAbsent;
    private List<TrackInfo> mTrackInfos;

    // ---- A-B 循环 ----
    private volatile long mLoopStartUs = -1L;
    private volatile long mLoopEndUs = -1L;

    // ---- 耳机拔出自动暂停 ----
    private volatile boolean mNoisyReceiverRegistered;
    private final BroadcastReceiver mNoisyReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!AudioManager.ACTION_AUDIO_BECOMING_NOISY.equals(intent.getAction())) return;
            if (mConfig != null && !mConfig.isPauseOnBecomingNoisy()) return;
            mMain.post(() -> {
                if (isPlaying()) {
                    pause();
                    if (mListener != null) mListener.onError(ERROR_AUDIO_DEVICE,
                            "audio device disconnected, paused");
                }
            });
        }
    };

    private final Runnable mProgressTicker = new Runnable() {
        @Override
        public void run() {
            if (mState == PlayerState.PLAYING) {
                long pos = mClock.nowUs();
                // A-B 循环：到达 B 点回到 A 点
                if (mLoopEndUs > 0 && pos >= mLoopEndUs) {
                    long start = mLoopStartUs > 0 ? mLoopStartUs : 0L;
                    seekTo(start);
                    mMain.postDelayed(this, PROGRESS_INTERVAL_MS);
                    return;
                }
                if (mListener != null) mListener.onProgress(pos, mDurationUs);
                mMain.postDelayed(this, PROGRESS_INTERVAL_MS);
            }
        }
    };

    private final Runnable mStatsTicker = new Runnable() {
        @Override
        public void run() {
            if (mListener != null && mConfig != null && mConfig.getStatsIntervalMs() > 0
                    && mState.isPlayable()) {
                mStats.setPosition(mClock.nowUs());
                if (mAudio != null && mAudio.getOutput() != null) {
                    mStats.setAudioBufferMs(mAudio.getOutput().getBufferedMs());
                }
                mListener.onStats(mStats.snapshot());
                mMain.postDelayed(this, mConfig.getStatsIntervalMs());
            }
        }
    };

    private final Runnable mSeekRecover = new Runnable() {
        @Override
        public void run() {
            if (mState == PlayerState.SEEKING) {
                setState(mStateBeforeSeek == PlayerState.PLAYING
                        ? PlayerState.PLAYING : PlayerState.PAUSED);
            }
        }
    };

    public HWDecoder(Context context) {
        mContext = context.getApplicationContext();
    }

    // ================= 对外 API =================

    public void setListener(HWDecoderListener listener) {
        mListener = listener;
    }

    public PlayerState getState() {
        return mState;
    }

    public long getPositionUs() {
        return mClock != null ? mClock.nowUs() : 0L;
    }

    public long getDurationUs() {
        return mDurationUs;
    }

    public boolean isPlaying() {
        return mState == PlayerState.PLAYING;
    }

    /** 设置数据源并异步 prepare */
    public void setDataSource(DecoderConfig config) {
        if (mReleased) return;
        releaseDecoders();
        mConfig = config;
        mClock = new MediaClock();
        mStats = new StatsCollector();
        mPlayList = new PlayList(config.getSource());
        mPlayList.setRepeatMode(PlayList.RepeatMode.OFF);
        mSurfaceWidth = 0;
        mSurfaceHeight = 0;
        mSuppressAutoPlay = false;
        mTrackInfos = null;
        setState(PlayerState.INITIALIZED);
    }

    /** 设置播放列表（第一个为当前项） */
    public void setPlayList(List<String> sources, DecoderConfig baseConfig) {
        if (mReleased || sources == null || sources.isEmpty()) return;
        releaseDecoders();
        mPlayList = new PlayList();
        mPlayList.addAll(sources);
        mConfig = DecoderConfig.builder()
                .source(mPlayList.getCurrent())
                .surface(baseConfig.getSurface())
                .maxVideoSize(baseConfig.getMaxVideoWidth(), baseConfig.getMaxVideoHeight())
                .hardwareOnly(baseConfig.isHardwareOnly())
                .softwareFallback(baseConfig.isSoftwareFallback())
                .volume(baseConfig.getVolume())
                .audioBufferMs(baseConfig.getAudioBufferMs())
                .lowLatencyAudio(baseConfig.isLowLatencyAudio())
                .audioBackend(baseConfig.getAudioBackend())
                .pitchPreserve(baseConfig.isPitchPreserve())
                .preBufferMs(baseConfig.getPreBufferMs())
                .enableDsp(baseConfig.isEnableDsp())
                .loudnessNorm(baseConfig.isLoudnessNorm(), baseConfig.getLoudnessTargetLufs())
                .statsIntervalMs(baseConfig.getStatsIntervalMs())
                .autoPlay(baseConfig.isAutoPlay())
                .seekMode(baseConfig.getSeekMode())
                .speed(baseConfig.getSpeed())
                .frameDropThresholdMs(baseConfig.getMaxFrameDropMs())
                .maxHoldMs(baseConfig.getMaxHoldMs())
                .bigCoreBinding(baseConfig.isBigCoreBinding())
                .pauseOnBecomingNoisy(baseConfig.isPauseOnBecomingNoisy())
                .loopList(baseConfig.isLoopList())
                .build();
        mClock = new MediaClock();
        mStats = new StatsCollector();
        mSurfaceWidth = 0;
        mSurfaceHeight = 0;
        mSuppressAutoPlay = false;
        mTrackInfos = null;
        setState(PlayerState.INITIALIZED);
    }

    public PlayList getPlayList() {
        return mPlayList;
    }

    /** 异步准备（打开文件、选择解码器） */
    public void prepareAsync() {
        if (mReleased || mConfig == null || mPreparing) return;
        if (mState == PlayerState.PREPARED || mState == PlayerState.PLAYING
                || mState == PlayerState.PAUSED) {
            return;
        }
        mPreparing = true;
        setState(PlayerState.PREPARING);
        final String source = mPlayList != null ? mPlayList.getCurrent() : mConfig.getSource();
        Thread t = new Thread(() -> doPrepare(source), "hwdec-prepare");
        t.start();
    }

    private void doPrepare(String source) {
        try {
            probeDuration(source);
            probeTracks(source);
            mVideo = new VideoDecoder(this, source);
            mAudio = new AudioDecoder(this, source, mAudioTrackIndex);
            mVideo.prepareAsync();
            mAudio.prepareAsync();
            // 兜底：个别异常路径下 8s 内未就绪也通知上层，避免界面卡死
            mMain.postDelayed(() -> {
                mVideoReady = true;
                mAudioReady = true;
                checkPrepared();
            }, 8000L);
        } catch (Throwable t) {
            mMain.post(() -> {
                mPreparing = false;
                fail(ERROR_PREPARE, "prepare failed: " + t);
            });
        }
    }

    /** 探测轨道列表（音轨选择 UI 用） */
    private void probeTracks(String source) {
        mTrackInfos = null;
        MediaExtractor ex = new MediaExtractor();
        try {
            if (source.startsWith("content://")) {
                ex.setDataSource(mContext, android.net.Uri.parse(source), null);
            } else {
                ex.setDataSource(source);
            }
            List<TrackInfo> list = new ArrayList<>();
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime == null) continue;
                String lang = null;
                try {
                    lang = f.getString(MediaFormat.KEY_LANGUAGE);
                } catch (Throwable ignored) {
                }
                int type;
                int w = 0, h = 0, sr = 0, ch = 0;
                if (mime.startsWith("video/")) {
                    type = TrackInfo.TYPE_VIDEO;
                    try {
                        w = f.getInteger(MediaFormat.KEY_WIDTH);
                        h = f.getInteger(MediaFormat.KEY_HEIGHT);
                    } catch (Throwable ignored) {
                    }
                } else if (mime.startsWith("audio/")) {
                    type = TrackInfo.TYPE_AUDIO;
                    try {
                        sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    } catch (Throwable ignored) {
                    }
                    try {
                        ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    } catch (Throwable ignored) {
                    }
                } else if (mime.startsWith("text/") || mime.startsWith("application/x-subtitle")) {
                    type = TrackInfo.TYPE_SUBTITLE;
                } else {
                    type = TrackInfo.TYPE_OTHER;
                }
                list.add(new TrackInfo(i, type, mime, lang, w, h, sr, ch));
            }
            mTrackInfos = list;
        } catch (Throwable ignored) {
        } finally {
            try {
                ex.release();
            } catch (Throwable ignored) {
            }
        }
    }

    /** 音视频单元均就绪后，统一通知 onPrepared 并自动播放 */
    private void checkPrepared() {
        if (mPreparedNotified || !mVideoReady || !mAudioReady) return;
        mPreparedNotified = true;
        mMain.post(() -> {
            mPreparing = false;
            setState(PlayerState.PREPARED);
            if (mListener != null) {
                mListener.onPrepared(mVideoWidth, mVideoHeight, mDurationUs);
            }
            if (mConfig.isAutoPlay() && !mSuppressAutoPlay) {
                start();
            }
            if (mAutoSeekAfterPrepare >= 0) {
                long target = mAutoSeekAfterPrepare;
                mAutoSeekAfterPrepare = -1L;
                seekTo(target);
            }
            startTickers();
        });
    }

    /** 探测时长（优先 track format，回退 MediaMetadataRetriever） */
    private void probeDuration(String source) {
        mDurationUs = 0L;
        MediaExtractor ex = new MediaExtractor();
        try {
            if (source.startsWith("content://")) {
                ex.setDataSource(mContext, android.net.Uri.parse(source), null);
            } else {
                ex.setDataSource(source);
            }
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                try {
                    long d = f.getLong(MediaFormat.KEY_DURATION);
                    if (d > 0) {
                        mDurationUs = d;
                        break;
                    }
                } catch (Throwable ignored) {
                }
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("video/")) {
                    try {
                        mVideoWidth = f.getInteger(MediaFormat.KEY_WIDTH);
                        mVideoHeight = f.getInteger(MediaFormat.KEY_HEIGHT);
                    } catch (Throwable ignored) {
                    }
                }
            }
        } catch (Throwable ignored) {
        } finally {
            try {
                ex.release();
            } catch (Throwable ignored) {
            }
        }
        if (mDurationUs <= 0) {
            MediaMetadataRetriever mmr = new MediaMetadataRetriever();
            try {
                if (source.startsWith("content://")) {
                    mmr.setDataSource(mContext, android.net.Uri.parse(source));
                } else {
                    mmr.setDataSource(source);
                }
                String d = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                if (d != null) mDurationUs = Long.parseLong(d) * 1000L;
                String w = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
                String h = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
                if (w != null && h != null) {
                    mVideoWidth = Integer.parseInt(w);
                    mVideoHeight = Integer.parseInt(h);
                }
            } catch (Throwable ignored) {
            } finally {
                try {
                    mmr.release();
                } catch (Throwable ignored) {
                }
            }
        }
    }

    // ---- 播放控制 ----

    public void start() {
        if (mReleased) return;
        if (mState == PlayerState.PREPARED || mState == PlayerState.PAUSED) {
            resumeDecoders();
            setState(PlayerState.PLAYING);
            startTickers();
        } else if (mState == PlayerState.COMPLETED) {
            // 播放完成后重新开始：重新准备当前曲目
            restartCurrent();
        } else if (mState == PlayerState.INITIALIZED || mState == PlayerState.STOPPED) {
            prepareAsync();
        }
    }

    /** 重新准备当前曲目（用于播放完成后重播） */
    private void restartCurrent() {
        String source = mPlayList != null ? mPlayList.getCurrent() : mConfig.getSource();
        if (source == null) return;
        releaseDecoders();
        mClock = new MediaClock();
        mStats = new StatsCollector();
        mVideoReady = false;
        mAudioReady = false;
        mAudioTrackAbsent = false;
        mPreparedNotified = false;
        mSuppressAutoPlay = false;
        mConfig = rebuildConfig(source);
        setState(PlayerState.PREPARING);
        doPrepare(source);
    }

    public void pause() {
        if (mReleased || !mState.isPlayable()) return;
        pauseDecoders();
        setState(PlayerState.PAUSED);
        mMain.removeCallbacks(mProgressTicker);
        mMain.removeCallbacks(mStatsTicker);
    }

    public void togglePlayPause() {
        if (isPlaying()) pause();
        else start();
    }

    public void stop() {
        if (mReleased) return;
        releaseDecoders();
        mVideoReady = false;
        mAudioReady = false;
        mPreparedNotified = false;
        setState(PlayerState.STOPPED);
        mMain.removeCallbacks(mProgressTicker);
        mMain.removeCallbacks(mStatsTicker);
    }

    public void seekTo(long positionUs) {
        if (mReleased) return;
        if (mState != PlayerState.PLAYING && mState != PlayerState.PAUSED
                && mState != PlayerState.SEEKING && mState != PlayerState.PREPARED) {
            // 未就绪：记录下来，prepare 后自动跳转
            mAutoSeekAfterPrepare = positionUs;
            return;
        }
        long target = Math.max(0L, positionUs);
        if (mDurationUs > 0) target = Math.min(target, mDurationUs);
        if (mState != PlayerState.SEEKING) {
            mStateBeforeSeek = mState == PlayerState.PLAYING ? PlayerState.PLAYING : PlayerState.PAUSED;
            setState(PlayerState.SEEKING);
        }
        if (mClock != null) mClock.setPositionUs(target);
        if (mVideo != null) mVideo.requestSeek(target);
        if (mAudio != null) mAudio.requestSeek(target);
        mMain.removeCallbacks(mSeekRecover);
        mMain.postDelayed(mSeekRecover, SEEK_RECOVER_TIMEOUT_MS);
    }

    public void seekToPercent(float percent) {
        if (mDurationUs <= 0) return;
        seekTo((long) (mDurationUs * Math.max(0f, Math.min(1f, percent))));
    }

    // ---- 音量 / 音效 ----

    /** 设置音量（线性增益，1.0=100%，最大 8.0=800%） */
    public void setVolume(float gain) {
        float g = gain < 0f ? 0f : (gain > 8f ? 8f : gain);
        if (mAudio != null) mAudio.setVolume(g);
        if (mListener != null) mListener.onVolumeChanged(g);
    }

    public float getVolume() {
        return mAudio != null ? mAudio.getVolume() : 1.0f;
    }

    /**
     * 设置倍速（0.25 ~ 8.0）。
     * <p>
     * 开启音调保持（默认）时使用 WSOLA 时间缩放：高倍速下人声不变尖、无颤音；
     * 关闭时交设备侧重采样（音调随倍速变化，CPU 更低）。
     * 视频侧同步按倍速在解封装层抽帧，高倍速不解多余帧。
     */
    public void setSpeed(float speed) {
        float s = speed < 0.25f ? 0.25f : (speed > 8f ? 8f : speed);
        if (mClock != null) mClock.setSpeed(s);
        if (mAudio != null) mAudio.setSpeed(s);
    }

    public float getSpeed() {
        return mClock != null ? mClock.getSpeed() : 1.0f;
    }

    /** 变速是否保持音调（WSOLA），默认 true */
    public void setPitchPreserve(boolean preserve) {
        if (mAudio != null) mAudio.setPitchPreserve(preserve);
    }

    public boolean isPitchPreserve() {
        return mConfig != null && mConfig.isPitchPreserve();
    }

    // ---- 单帧步进 ----

    /** 暂停态单帧步进（自动进入暂停后逐帧前进） */
    public void stepFrame() {
        if (mReleased) return;
        if (isPlaying()) pause();
        if (mVideo != null) mVideo.stepFrame();
    }

    // ---- A-B 循环 ----

    /** 设置 A-B 循环区间（us）；endUs &lt;= 0 表示清除 */
    public void setLoopRange(long startUs, long endUs) {
        if (endUs <= 0 || endUs <= startUs) {
            mLoopStartUs = -1L;
            mLoopEndUs = -1L;
        } else {
            mLoopStartUs = startUs;
            mLoopEndUs = endUs;
        }
    }

    public void clearLoopRange() {
        mLoopStartUs = -1L;
        mLoopEndUs = -1L;
    }

    public boolean isLooping() {
        return mLoopEndUs > 0;
    }

    // ---- 音轨选择 ----

    /** 轨道列表（prepare 后可用） */
    public List<TrackInfo> getTrackList() {
        return mTrackInfos;
    }

    /**
     * 选择音频轨（轨道在 {@link #getTrackList()} 中的索引）。
     * 切换会重建音频单元并重载当前源，播放位置保持不变。
     *
     * @return 是否成功
     */
    public boolean selectAudioTrack(int trackIndex) {
        if (mReleased || mTrackInfos == null) return false;
        TrackInfo target = null;
        for (TrackInfo t : mTrackInfos) {
            if (t.index == trackIndex && t.type == TrackInfo.TYPE_AUDIO) {
                target = t;
                break;
            }
        }
        if (target == null) return false;
        if (target.index == mAudioTrackIndex && mAudio != null && mAudioReady) {
            return true; // 已是当前轨
        }
        mAudioTrackIndex = target.index;
        String source = mPlayList != null ? mPlayList.getCurrent() : mConfig.getSource();
        long pos = getPositionUs();
        boolean wasPlaying = isPlaying();
        reloadSource(source, pos, wasPlaying);
        return true;
    }

    /** 当前音频轨索引（-1 = 默认第一个） */
    public int getAudioTrackIndex() {
        return mAudioTrackIndex;
    }

    /** 重载数据源（保留播放位置，用于音轨切换等场景） */
    private void reloadSource(String source, long seekToUs, boolean autoPlay) {
        if (source == null) return;
        releaseDecoders();
        mClock = new MediaClock();
        mStats = new StatsCollector();
        mVideoEos = false;
        mAudioEos = false;
        mVideoReady = false;
        mAudioReady = false;
        mAudioTrackAbsent = false;
        mPreparedNotified = false;
        mConfig = rebuildConfig(source);
        mSuppressAutoPlay = !autoPlay;
        mAutoSeekAfterPrepare = seekToUs > 0 ? seekToUs : -1L;
        setState(PlayerState.PREPARING);
        doPrepare(source);
    }

    // ---- 声道路由 ----

    /** 设置声道模式（ChannelRouter.MODE_*） */
    public void setChannelMode(int mode) {
        if (mAudio != null) mAudio.setChannelMode(mode);
    }

    public int getChannelMode() {
        return mAudio != null ? mAudio.getChannelMode() : ChannelRouter.MODE_STEREO;
    }

    // ---- 频谱可视化 ----

    /** 频谱分析器（prepare 后可用，UI 线程周期性 getBands） */
    public SpectrumAnalyzer getSpectrumAnalyzer() {
        return mAudio != null ? mAudio.getSpectrumAnalyzer() : null;
    }

    // ---- 截图 ----

    /** 截图回调 */
    public interface CaptureCallback {
        void onCaptured(android.graphics.Bitmap bitmap);
        void onError(String message);
    }

    /**
     * 捕获当前显示帧（SurfaceView，API 24+ 用 PixelCopy 异步截图）。
     * 调用线程需要带 Looper（通常为主线程）。
     */
    public void captureFrame(SurfaceView view, CaptureCallback cb) {
        if (view == null || cb == null) return;
        if (android.os.Build.VERSION.SDK_INT >= 24) {
            try {
                android.graphics.Bitmap bitmap = android.graphics.Bitmap.createBitmap(
                        view.getWidth(), view.getHeight(), android.graphics.Bitmap.Config.ARGB_8888);
                PixelCopy.request(view, bitmap, copyResult -> {
                    if (copyResult == PixelCopy.SUCCESS) {
                        cb.onCaptured(bitmap);
                    } else {
                        cb.onError("PixelCopy failed: " + copyResult);
                    }
                }, mMain);
                return;
            } catch (Throwable t) {
                cb.onError("capture failed: " + t);
                return;
            }
        }
        cb.onError("captureFrame requires API 24+ for SurfaceView");
    }

    /**
     * 捕获当前显示帧（TextureView，直接取位图，同步调用）。
     */
    public void captureFrame(TextureView view, CaptureCallback cb) {
        if (view == null || cb == null) return;
        try {
            android.graphics.Bitmap bitmap = view.getBitmap();
            if (bitmap != null) {
                cb.onCaptured(bitmap);
            } else {
                cb.onError("texture view has no content");
            }
        } catch (Throwable t) {
            cb.onError("capture failed: " + t);
        }
    }

    /** 获取均衡器（prepare 后可用） */
    public Equalizer getEqualizer() {
        return mAudio != null ? mAudio.getEqualizer() : null;
    }

    public AudioProcessorChain getDspChain() {
        return mDspChain;
    }

    // ---- Surface ----

    public void setSurface(Surface surface) {
        if (mReleased || surface == null) return;
        if (mVideo != null) {
            mVideo.setSurface(surface);
        }
    }

    public void setSurfaceSize(int w, int h) {
        mSurfaceWidth = w;
        mSurfaceHeight = h;
    }

    // ---- 播放列表 ----

    public boolean next() {
        if (mReleased || mPlayList == null) return false;
        int idx = mPlayList.advance();
        if (idx < 0) {
            if (mListener != null) mListener.onCompletion();
            return false;
        }
        playPlaylistIndex(idx);
        return true;
    }

    public boolean previous() {
        if (mReleased || mPlayList == null) return false;
        // 播放超过 3 秒则重播当前
        if (getPositionUs() > 3_000_000L) {
            seekTo(0);
            return true;
        }
        int idx = mPlayList.previous();
        if (idx < 0) return false;
        playPlaylistIndex(idx);
        return true;
    }

    public void playIndex(int index) {
        if (mReleased || mPlayList == null) return;
        if (mPlayList.select(index)) {
            playPlaylistIndex(index);
        }
    }

    private void playPlaylistIndex(int index) {
        releaseDecoders();
        mClock = new MediaClock();
        mStats = new StatsCollector();
        String source = mPlayList.getCurrent();
        DecoderConfig cfg = rebuildConfig(source);
        mConfig = cfg;
        mVideoEos = false;
        mAudioEos = false;
        mVideoReady = false;
        mAudioReady = false;
        mPreparedNotified = false;
        setState(PlayerState.PREPARING);
        doPrepare(source);
        if (mListener != null) {
            mListener.onPlaylistAdvanced(index, source);
        }
    }

    private DecoderConfig rebuildConfig(String source) {
        DecoderConfig b = mConfig;
        return DecoderConfig.builder()
                .source(source)
                .surface(b.getSurface())
                .maxVideoSize(b.getMaxVideoWidth(), b.getMaxVideoHeight())
                .hardwareOnly(b.isHardwareOnly())
                .softwareFallback(b.isSoftwareFallback())
                .volume(b.getVolume())
                .audioBufferMs(b.getAudioBufferMs())
                .lowLatencyAudio(b.isLowLatencyAudio())
                .audioBackend(b.getAudioBackend())
                .pitchPreserve(b.isPitchPreserve())
                .preBufferMs(b.getPreBufferMs())
                .enableDsp(b.isEnableDsp())
                .loudnessNorm(b.isLoudnessNorm(), b.getLoudnessTargetLufs())
                .statsIntervalMs(b.getStatsIntervalMs())
                .autoPlay(true)
                .seekMode(b.getSeekMode())
                .speed(b.getSpeed())
                .frameDropThresholdMs(b.getMaxFrameDropMs())
                .maxHoldMs(b.getMaxHoldMs())
                .bigCoreBinding(b.isBigCoreBinding())
                .pauseOnBecomingNoisy(b.isPauseOnBecomingNoisy())
                .loopList(b.isLoopList())
                .build();
    }

    // ---- 释放 ----

    public void release() {
        if (mReleased) return;
        mReleased = true;
        mMain.removeCallbacks(mProgressTicker);
        mMain.removeCallbacks(mStatsTicker);
        mMain.removeCallbacks(mSeekRecover);
        unregisterNoisyReceiver();
        releaseDecoders();
        setState(PlayerState.RELEASED);
    }

    private void releaseDecoders() {
        if (mVideo != null) {
            mVideo.quit();
            mVideo = null;
        }
        if (mAudio != null) {
            mAudio.quit();
            mAudio = null;
        }
        mDspChain = null;
        mVideoEos = false;
        mAudioEos = false;
        mVideoReady = false;
        mAudioReady = false;
        mAudioTrackAbsent = false;
        mPreparedNotified = false;
    }

    private void pauseDecoders() {
        if (mClock != null) mClock.setPaused(true);
        if (mAudio != null) mAudio.pause();
        if (mVideo != null) mVideo.pause();
        unregisterNoisyReceiver();
    }

    private void resumeDecoders() {
        // 起播预缓冲：有音频轨且输出设备不自行管理缓冲时，
        // 先解码一小段再启动输出与主时钟（视频渲染门控由音频预缓冲完成回调打开）
        boolean prebuffer = mConfig != null
                && mConfig.getPreBufferMs() > 0
                && mAudio != null
                && !mAudioTrackAbsent
                && mAudio.willPrebuffer();
        if (!prebuffer && mClock != null) mClock.setPaused(false);
        if (prebuffer && mVideo != null) mVideo.setRenderGate(false);
        if (mAudio != null) mAudio.resumePlayback(prebuffer);
        if (mVideo != null) mVideo.resumePlayback();
        if (!prebuffer && mVideo != null) mVideo.setRenderGate(true);
        registerNoisyReceiver();
    }

    /** 注册耳机拔出/音频设备断开广播（配置开启时） */
    private void registerNoisyReceiver() {
        if (mReleased || mNoisyReceiverRegistered) return;
        if (mConfig == null || !mConfig.isPauseOnBecomingNoisy()) return;
        try {
            IntentFilter filter = new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY);
            if (Build.VERSION.SDK_INT >= 33) {
                // Android 13+ 强制要求声明导出标志；本广播只收系统级，用 NOT_EXPORTED
                mContext.registerReceiver(mNoisyReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                mContext.registerReceiver(mNoisyReceiver, filter);
            }
            mNoisyReceiverRegistered = true;
        } catch (Throwable ignored) {
        }
    }

    private void unregisterNoisyReceiver() {
        if (!mNoisyReceiverRegistered) return;
        try {
            mContext.unregisterReceiver(mNoisyReceiver);
        } catch (Throwable ignored) {
        }
        mNoisyReceiverRegistered = false;
    }

    private void startTickers() {
        mMain.removeCallbacks(mProgressTicker);
        mMain.removeCallbacks(mStatsTicker);
        if (mState == PlayerState.PLAYING) {
            mMain.post(mProgressTicker);
            if (mConfig != null && mConfig.getStatsIntervalMs() > 0) {
                mMain.post(mStatsTicker);
            }
        }
    }

    private void setState(PlayerState state) {
        if (mState == state) return;
        mState = state;
        if (mListener != null) mListener.onStateChanged(state);
    }

    private void fail(int code, String message) {
        setState(PlayerState.ERROR);
        if (mListener != null) mListener.onError(code, message);
    }

    // ================= Host 实现 =================

    @Override
    public DecoderConfig config() {
        return mConfig;
    }

    @Override
    public MediaClock clock() {
        return mClock;
    }

    @Override
    public StatsCollector stats() {
        return mStats;
    }

    @Override
    public Surface surface() {
        return mConfig != null ? mConfig.getSurface() : null;
    }

    @Override
    public int surfaceWidth() {
        return mSurfaceWidth;
    }

    @Override
    public int surfaceHeight() {
        return mSurfaceHeight;
    }

    @Override
    public Context context() {
        return mContext;
    }

    @Override
    public void onVideoReady(String codecName, boolean hardware, int width, int height) {
        mVideoWidth = width;
        mVideoHeight = height;
        mVideoReady = true;
        mMain.post(() -> {
            if (mListener != null) mListener.onVideoSizeChanged(width, height);
        });
        checkPrepared();
    }

    @Override
    public void onFirstFrameAfterSeek(long ptsUs) {
        mMain.post(() -> {
            mMain.removeCallbacks(mSeekRecover);
            if (mState == PlayerState.SEEKING) {
                setState(mStateBeforeSeek == PlayerState.PLAYING
                        ? PlayerState.PLAYING : PlayerState.PAUSED);
            }
            if (mListener != null) mListener.onSeekCompleted(ptsUs);
        });
    }

    @Override
    public void onVideoEos() {
        mVideoEos = true;
        mVideoReady = true;
        checkPrepared();
        checkCompletion();
    }

    @Override
    public void onVideoOutputFormatChanged(int width, int height) {
        mVideoWidth = width;
        mVideoHeight = height;
        mMain.post(() -> {
            if (mListener != null) mListener.onVideoSizeChanged(width, height);
        });
    }

    @Override
    public void onVideoHdrChanged(boolean hdr) {
        mMain.post(() -> {
            if (mListener != null) mListener.onVideoHdrChanged(hdr);
        });
    }

    @Override
    public void onFrameStepped(long ptsUs) {
        // 步进一帧：把时钟对齐到该帧，保证进度显示连续
        if (mClock != null) mClock.setPositionUs(ptsUs);
        mMain.post(() -> {
            if (mListener != null) mListener.onFrameStepped(ptsUs);
        });
    }

    @Override
    public void onAudioReady(AudioProcessorChain dspChain, String codecName, boolean hardware) {
        mDspChain = dspChain;
        // 应用可能已变化过的音量
        if (mConfig != null && mConfig.getVolume() != 1.0f) {
            mAudio.setVolume(mConfig.getVolume());
        }
        mAudioReady = true;
        checkPrepared();
    }

    @Override
    public void onAudioTrackAbsent() {
        mAudioTrackAbsent = true;
        // 纯视频文件：没有预缓冲可言，立即打开视频门控与时钟
        mMain.post(() -> {
            if (mClock != null && mClock.isPaused() && mState != PlayerState.PLAYING) {
                mClock.setPaused(false);
            }
            if (mVideo != null) mVideo.setRenderGate(true);
        });
    }

    @Override
    public void onAudioPrebuffered() {
        // 起播预缓冲完成：打开视频渲染门控（时钟已由 AudioDecoder 恢复）
        if (mVideo != null) mVideo.setRenderGate(true);
        mMain.post(() -> {
            if (mListener != null) mListener.onAudioPrebuffered();
        });
    }

    @Override
    public void onAudioEos() {
        mAudioEos = true;
        mAudioReady = true;
        checkPrepared();
        checkCompletion();
    }

    @Override
    public void onDecoderError(int errorCode, String message) {
        mMain.post(() -> fail(errorCode, message));
    }

    private void checkCompletion() {
        if (!mVideoEos || !mAudioEos) return;
        mMain.post(() -> {
            if (mState == PlayerState.RELEASED || mState == PlayerState.ERROR) return;
            // 播放列表自动前进
            if (mPlayList != null && mPlayList.size() > 1) {
                if (next()) return;
            }
            setState(PlayerState.COMPLETED);
            if (mListener != null) mListener.onCompletion();
        });
    }
}
