package com.hwdecoder;

/**
 * 音量放大器（支持超过 100% 的增益放大）。
 * <p>
 * 特性：
 * 1. 增益范围 0.0 ~ 8.0（即 0% ~ 800%），满足小音量音源的放大需求；
 * 2. 每样本增益斜坡（gain ramp），切换音量时无咔哒声；
 * 3. tanh 软限幅：超过 ceiling 的部分平滑压缩而非硬削波，放大不失真；
 * 4. 末端可选硬限幅到 ±1.0，保证输出到 int16 转换时安全。
 */
public final class VolumeBooster implements AudioProcessor {

    private static final float RAMP_FACTOR = 0.002f; // 每样本最大增益变化比例

    private float mTargetGain = 1.0f;
    private float mCurrentGain = 1.0f;
    private float mCeiling = 0.92f;   // 软限幅起点（线性区上限）
    private boolean mEnabled = true;

    public VolumeBooster() {}

    public VolumeBooster(float gain) {
        mTargetGain = gain;
        mCurrentGain = gain;
    }

    /** 设置目标增益（线性，1.0 = 100%） */
    public void setGain(float gain) {
        mTargetGain = gain < 0f ? 0f : gain;
    }

    public float getGain() { return mTargetGain; }

    /** 软限幅起点（0.5 ~ 1.0） */
    public void setCeiling(float ceiling) {
        mCeiling = ceiling < 0.3f ? 0.3f : (ceiling > 1.0f ? 1.0f : ceiling);
    }

    public void setEnabled(boolean enabled) { mEnabled = enabled; }

    @Override
    public void init(int sampleRate, int channels) {
        // 无采样率相关状态
    }

    @Override
    public void process(float[] buf, int off, int len) {
        if (!mEnabled) return;
        float target = mTargetGain;
        float cur = mCurrentGain;
        if (cur != target) {
            float maxStep = Math.max(Math.abs(target - cur) * RAMP_FACTOR,
                    0.0005f * Math.max(1f, Math.abs(target)));
            if (target > cur) cur = Math.min(target, cur + maxStep);
            else cur = Math.max(target, cur - maxStep);
        }
        float step = (target - cur) / Math.max(1, len);
        float g = cur;
        float ceiling = mCeiling;
        float span = Math.max(1.0f - ceiling, 0.05f);
        for (int i = off; i < off + len; i++) {
            float x = buf[i] * g;
            g += step;
            // 软限幅：线性区保持原样，超出部分用 tanh 平滑压缩
            float a = x < 0f ? -x : x;
            if (a > ceiling) {
                float over = a - ceiling;
                float comp = ceiling + span * (float) Math.tanh(over / span);
                if (comp > 1.0f) comp = 1.0f;
                x = x < 0f ? -comp : comp;
            }
            buf[i] = x;
        }
        mCurrentGain = cur;
    }

    @Override
    public void reset() {
        mCurrentGain = mTargetGain;
    }

    @Override
    public void release() {}
}
