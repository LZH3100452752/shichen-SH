package com.hwdecoder;

/**
 * 双二阶滤波器（Biquad，RBJ  cookbook 系数）。
 * 支持 peaking / low-shelf / high-shelf，每声道独立状态，处理交错 PCM。
 */
public final class BiquadFilter {

    // 系数（double 累加，float 输出）
    private double mB0, mB1, mB2, mA1, mA2;
    // 每声道状态（Direct Form I）
    private double[] mX1, mX2, mY1, mY2;
    private int mChannels;
    private boolean mBypass = true;

    public void init(int channels) {
        mChannels = channels;
        mX1 = new double[channels];
        mX2 = new double[channels];
        mY1 = new double[channels];
        mY2 = new double[channels];
        setBypass(true);
    }

    public void setBypass(boolean bypass) {
        mBypass = bypass;
        if (mX1 != null) {
            java.util.Arrays.fill(mX1, 0);
            java.util.Arrays.fill(mX2, 0);
            java.util.Arrays.fill(mY1, 0);
            java.util.Arrays.fill(mY2, 0);
        }
    }

    /** Peaking EQ：freq 处增益 gainDb，带宽由 Q 控制 */
    public void setPeaking(double sampleRate, double freq, double q, double gainDb) {
        double A = Math.pow(10.0, gainDb / 40.0);
        double w0 = 2.0 * Math.PI * freq / sampleRate;
        double cosw0 = Math.cos(w0);
        double alpha = Math.sin(w0) / (2.0 * q);
        double b0 = 1.0 + alpha * A;
        double b1 = -2.0 * cosw0;
        double b2 = 1.0 - alpha * A;
        double a0 = 1.0 + alpha / A;
        double a1 = -2.0 * cosw0;
        double a2 = 1.0 - alpha / A;
        setCoeffs(b0, b1, b2, a0, a1, a2);
    }

    /** 高通滤波（RBJ） */
    public void setHighPass(double sampleRate, double freq, double q) {
        double w0 = 2.0 * Math.PI * freq / sampleRate;
        double cosw0 = Math.cos(w0);
        double alpha = Math.sin(w0) / (2.0 * q);
        double b0 = (1.0 + cosw0) / 2.0;
        double b1 = -(1.0 + cosw0);
        double b2 = (1.0 + cosw0) / 2.0;
        double a0 = 1.0 + alpha;
        double a1 = -2.0 * cosw0;
        double a2 = 1.0 - alpha;
        setCoeffs(b0, b1, b2, a0, a1, a2);
    }

    /** 低频搁架式滤波 */
    public void setLowShelf(double sampleRate, double freq, double slope, double gainDb) {
        double A = Math.pow(10.0, gainDb / 40.0);
        double w0 = 2.0 * Math.PI * freq / sampleRate;
        double cosw0 = Math.cos(w0);
        double beta = Math.sqrt(A) / slope;
        double alpha = Math.sin(w0) / 2.0;
        double ap1 = 2.0 * Math.sqrt(A) * alpha;
        double b0 = A * ((A + 1) - (A - 1) * cosw0 + beta * Math.sin(w0));
        double b1 = 2.0 * A * ((A - 1) - (A + 1) * cosw0);
        double b2 = A * ((A + 1) - (A - 1) * cosw0 - beta * Math.sin(w0));
        double a0 = (A + 1) + (A - 1) * cosw0 + ap1;
        double a1 = -2.0 * ((A - 1) + (A + 1) * cosw0);
        double a2 = (A + 1) + (A - 1) * cosw0 - ap1;
        setCoeffs(b0, b1, b2, a0, a1, a2);
    }

    /** 高频搁架式滤波 */
    public void setHighShelf(double sampleRate, double freq, double slope, double gainDb) {
        double A = Math.pow(10.0, gainDb / 40.0);
        double w0 = 2.0 * Math.PI * freq / sampleRate;
        double cosw0 = Math.cos(w0);
        double beta = Math.sqrt(A) / slope;
        double alpha = Math.sin(w0) / 2.0;
        double ap1 = 2.0 * Math.sqrt(A) * alpha;
        double b0 = A * ((A + 1) + (A - 1) * cosw0 + beta * Math.sin(w0));
        double b1 = -2.0 * A * ((A - 1) + (A + 1) * cosw0);
        double b2 = A * ((A + 1) + (A - 1) * cosw0 - beta * Math.sin(w0));
        double a0 = (A + 1) - (A - 1) * cosw0 + ap1;
        double a1 = 2.0 * ((A - 1) - (A + 1) * cosw0);
        double a2 = (A + 1) - (A - 1) * cosw0 - ap1;
        setCoeffs(b0, b1, b2, a0, a1, a2);
    }

    private void setCoeffs(double b0, double b1, double b2,
                           double a0, double a1, double a2) {
        mB0 = b0 / a0;
        mB1 = b1 / a0;
        mB2 = b2 / a0;
        mA1 = a1 / a0;
        mA2 = a2 / a0;
        mBypass = false;
    }

    /** 就地处理交错 PCM */
    public void process(float[] buf, int off, int len) {
        if (mBypass || mChannels <= 0) return;
        int frames = len / mChannels;
        for (int f = 0; f < frames; f++) {
            int base = off + f * mChannels;
            for (int c = 0; c < mChannels; c++) {
                double x0 = buf[base + c];
                double y0 = mB0 * x0 + mB1 * mX1[c] + mB2 * mX2[c]
                        - mA1 * mY1[c] - mA2 * mY2[c];
                mX2[c] = mX1[c];
                mX1[c] = x0;
                mY2[c] = mY1[c];
                mY1[c] = y0;
                buf[base + c] = (float) y0;
            }
        }
    }
}
