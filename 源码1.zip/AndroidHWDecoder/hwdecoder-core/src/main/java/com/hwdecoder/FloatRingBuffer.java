package com.hwdecoder;

import java.util.concurrent.atomic.AtomicLong;

/**
 * 单生产者单消费者（SPSC）无锁环形缓冲区（float 采样）。
 * <p>
 * 生产者 = 音频解码线程；消费者 = 音频输出线程。
 * 基于序号（sequence number）实现 lock-free，避免锁竞争造成的抖动。
 */
public final class FloatRingBuffer {

    private final float[] mData;
    private final int mMask;
    private final AtomicLong mWriteSeq = new AtomicLong(0L);
    private final AtomicLong mReadSeq = new AtomicLong(0L);

    /**
     * @param capacity 期望容量，内部向上取到 2 的幂
     */
    public FloatRingBuffer(int capacity) {
        int c = 1024;
        while (c < capacity) c <<= 1;
        mData = new float[c];
        mMask = c - 1;
    }

    public int capacity() { return mData.length; }

    /** 当前可读采样数 */
    public int available() {
        long w = mWriteSeq.get();
        long r = mReadSeq.get();
        return (int) (w - r);
    }

    /** 当前可写空间 */
    public int space() { return mData.length - available(); }

    /** 非阻塞写入，返回实际写入采样数 */
    public int write(float[] src, int off, int len) {
        long w = mWriteSeq.get();
        long r = mReadSeq.get();
        int avail = mData.length - (int) (w - r);
        int k = Math.min(len, avail);
        if (k <= 0) return 0;
        for (int i = 0; i < k; i++) {
            mData[(int) ((w + i) & mMask)] = src[off + i];
        }
        mWriteSeq.lazySet(w + k);
        return k;
    }

    /** 非阻塞读取，返回实际读出采样数 */
    public int read(float[] dst, int off, int len) {
        long r = mReadSeq.get();
        long w = mWriteSeq.get();
        int avail = (int) (w - r);
        int k = Math.min(len, avail);
        if (k <= 0) return 0;
        for (int i = 0; i < k; i++) {
            dst[off + i] = mData[(int) ((r + i) & mMask)];
        }
        mReadSeq.lazySet(r + k);
        return k;
    }

    /**
     * 阻塞读取：最多等待 timeoutMs，返回实际读出采样数。
     * 采用轻量自旋 + 让步，延迟在微秒级，适合音频输出线程。
     */
    public int readBlocking(float[] dst, int off, int len, long timeoutMs) {
        int total = 0;
        long deadline = System.nanoTime() + timeoutMs * 1_000_000L;
        while (total < len) {
            int k = read(dst, off + total, len - total);
            if (k > 0) {
                total += k;
            } else {
                if (System.nanoTime() >= deadline) break;
                Thread.yield();
            }
        }
        return total;
    }

    /** 清空（消费者调用） */
    public void clear() {
        long w = mWriteSeq.get();
        mReadSeq.lazySet(w);
    }
}
