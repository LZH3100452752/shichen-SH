package com.hwdecoder;

/**
 * 10 段参数化均衡器（ISO 中心频率）。
 * <p>
 * 使用 Biquad peaking/shelf 滤波器，纯软件实现、不依赖系统音效框架，
 * 因此对任何 AudioTrack 会话 / OpenSL ES 输出都生效，且无厂商 ROM 差异。
 */
public final class Equalizer implements AudioProcessor {

    private static final double[] FREQS = {
            31.25, 62.5, 125, 250, 500, 1000, 2000, 4000, 8000, 16000
    };
    private static final double Q = 1.1;

    private final BiquadFilter[] mFilters = new BiquadFilter[FREQS.length];
    private final float[] mGainsDb = new float[FREQS.length];
    private float mPreampDb = 0f;
    private boolean mEnabled = true;
    private int mSampleRate = 48000;
    private int mChannels = 2;

    public Equalizer() {
        for (int i = 0; i < mFilters.length; i++) {
            mFilters[i] = new BiquadFilter();
        }
    }

    public int getBandCount() { return FREQS.length; }

    public double getBandFreq(int band) { return FREQS[band]; }

    /** 设置某一段增益（dB，-12 ~ +12） */
    public void setBandGain(int band, float db) {
        if (band < 0 || band >= FREQS.length) return;
        mGainsDb[band] = db < -12f ? -12f : (db > 12f ? 12f : db);
        updateBand(band);
    }

    public float getBandGain(int band) {
        if (band < 0 || band >= FREQS.length) return 0f;
        return mGainsDb[band];
    }

    /** 前置增益（dB，-12 ~ +12），用于补偿整体音量变化 */
    public void setPreampDb(float db) {
        mPreampDb = db < -12f ? -12f : (db > 12f ? 12f : db);
    }

    public void setEnabled(boolean enabled) { mEnabled = enabled; }

    public void reset() {
        for (int i = 0; i < mFilters.length; i++) {
            mFilters[i].setBypass(true);
        }
    }

    @Override
    public void init(int sampleRate, int channels) {
        mSampleRate = sampleRate;
        mChannels = channels;
        for (BiquadFilter f : mFilters) {
            f.init(channels);
        }
        for (int i = 0; i < mFilters.length; i++) {
            updateBand(i);
        }
    }

    private void updateBand(int band) {
        BiquadFilter f = mFilters[band];
        float db = mGainsDb[band] + mPreampDb;
        if (Math.abs(db) < 0.01f) {
            f.setBypass(true);
            return;
        }
        if (band == 0) {
            f.setLowShelf(mSampleRate, FREQS[0], 0.707, db);
        } else if (band == FREQS.length - 1) {
            f.setHighShelf(mSampleRate, FREQS[band], 0.707, db);
        } else {
            f.setPeaking(mSampleRate, FREQS[band], Q, db);
        }
    }

    @Override
    public void process(float[] buf, int off, int len) {
        if (!mEnabled) return;
        // 增益为 0 的频段已在 updateBand 中置为 bypass，process 内部直接跳过
        for (int i = 0; i < mFilters.length; i++) {
            mFilters[i].process(buf, off, len);
        }
    }

    @Override
    public void release() {
        for (BiquadFilter f : mFilters) {
            f.setBypass(true);
        }
    }
}
