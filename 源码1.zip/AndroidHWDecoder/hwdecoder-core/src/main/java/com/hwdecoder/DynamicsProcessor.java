package com.hwdecoder;

/**
 * 动态处理器：前馈压缩器 + 峰值限幅器。
 * <p>
 * - 包络跟随器带 attack/release 平滑，避免增益快速变化产生失真；
 * - 软膝（soft knee）压缩曲线，过渡自然；
 * - makeup gain 补偿压缩带来的响度损失；
 * - 末端限幅保证送入 int16 输出时不溢出。
 * 用于压制放大后的爆音、统一片源响度差异。
 */
public final class DynamicsProcessor implements AudioProcessor {

    private static final float EPS = 1e-6f;

    private float mThresholdDb = -18f;
    private float mRatio = 3f;
    private float mAttackMs = 8f;
    private float mReleaseMs = 150f;
    private float mKneeDb = 6f;
    private float mMakeupDb = 0f;
    private float mLimiterCeiling = 0.98f;
    private boolean mEnabled = true;

    private float mEnv;            // 包络（线性幅度）
    private float mAttackCoef;
    private float mReleaseCoef;
    private int mSampleRate = 48000;

    public DynamicsProcessor() {}

    public void setThresholdDb(float db) { mThresholdDb = db; updateCoeffs(); }

    public void setRatio(float ratio) { mRatio = ratio < 1f ? 1f : ratio; }

    public void setAttackMs(float ms) { mAttackMs = ms < 0.1f ? 0.1f : ms; updateCoeffs(); }

    public void setReleaseMs(float ms) { mReleaseMs = ms < 1f ? 1f : ms; updateCoeffs(); }

    public void setKneeDb(float db) { mKneeDb = db < 0f ? 0f : db; }

    public void setMakeupDb(float db) { mMakeupDb = db; }

    public void setEnabled(boolean enabled) { mEnabled = enabled; }

    @Override
    public void init(int sampleRate, int channels) {
        mSampleRate = sampleRate;
        mEnv = 0f;
        updateCoeffs();
    }

    private void updateCoeffs() {
        mAttackCoef = (float) Math.exp(-1.0 / (mAttackMs * 0.001 * mSampleRate));
        mReleaseCoef = (float) Math.exp(-1.0 / (mReleaseMs * 0.001 * mSampleRate));
    }

    @Override
    public void process(float[] buf, int off, int len) {
        if (!mEnabled) return;
        float env = mEnv;
        float attackCoef = mAttackCoef;
        float releaseCoef = mReleaseCoef;
        float thresholdDb = mThresholdDb;
        float ratio = mRatio;
        float knee = mKneeDb;
        float makeup = (float) Math.pow(10.0, mMakeupDb / 20.0);
        float ceiling = mLimiterCeiling;

        for (int i = off; i < off + len; i++) {
            float x = buf[i];
            float mag = x < 0f ? -x : x;

            // 一阶包络跟随（attack/release 双系数）
            float coef = mag > env ? attackCoef : releaseCoef;
            env = mag + coef * (env - mag);

            // 增益计算机（软膝）
            float envDb = 20f * (float) Math.log10(env + EPS);
            float overDb = envDb - thresholdDb;
            float gainDb;
            if (knee <= 0f) {
                gainDb = overDb <= 0f ? 0f : -overDb * (1f - 1f / ratio);
            } else if (overDb < -knee / 2f) {
                gainDb = 0f;
            } else if (overDb > knee / 2f) {
                gainDb = -overDb * (1f - 1f / ratio);
            } else {
                float t = overDb + knee / 2f;
                gainDb = -(1f - 1f / ratio) * (t * t) / (2f * knee);
            }

            float y = x * (float) Math.pow(10.0, gainDb / 20.0) * makeup;

            // 峰值限幅（软膝后仍可能超限）
            float a = y < 0f ? -y : y;
            if (a > ceiling) {
                float over = a - ceiling;
                float comp = ceiling + (1f - ceiling) * (float) Math.tanh(over / (1f - ceiling + EPS));
                y = y < 0f ? -comp : comp;
            }
            buf[i] = y;
        }
        mEnv = env;
    }

    @Override
    public void reset() {
        mEnv = 0f;
    }

    @Override
    public void release() {}
}
