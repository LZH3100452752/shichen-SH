package com.hwdecoder;

/**
 * 解码器事件回调。所有回调都在主线程派发，可直接操作 UI。
 */
public interface HWDecoderListener {

    /** 状态变化 */
    default void onStateChanged(PlayerState state) {}

    /** prepare 完成，width/height/durationUs 已就绪 */
    default void onPrepared(int width, int height, long durationUs) {}

    /** 视频尺寸变化（例如解码中途旋转） */
    default void onVideoSizeChanged(int width, int height) {}

    /** HDR 视频信息（PQ / HLG） */
    default void onVideoHdrChanged(boolean hdr) {}

    /** 单帧步进完成（暂停态逐帧前进，ptsUs 为该帧时间戳） */
    default void onFrameStepped(long ptsUs) {}

    /** 起播预缓冲完成（音频已启动，视频门控已打开） */
    default void onAudioPrebuffered() {}

    /** 播放进度（周期回调） */
    default void onProgress(long positionUs, long durationUs) {}

    /** 播放完成（单曲或播放列表末尾） */
    default void onCompletion() {}

    /** 自动切歌 */
    default void onPlaylistAdvanced(int index, String source) {}

    /** seek 完成（首帧已渲染） */
    default void onSeekCompleted(long positionUs) {}

    /** 出错 */
    default void onError(int errorCode, String message) {}

    /** 周期性性能统计 */
    default void onStats(StatsCollector.Stats stats) {}

    /** 音量放大倍数变化（1.0 = 100%） */
    default void onVolumeChanged(float gain) {}
}
