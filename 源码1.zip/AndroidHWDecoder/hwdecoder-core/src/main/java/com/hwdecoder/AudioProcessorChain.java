package com.hwdecoder;

import java.util.ArrayList;
import java.util.List;

/**
 * DSP 处理链：按固定顺序串行执行多个音频处理器。
 * <p>
 * 推荐顺序：
 * 1. Equalizer          —— 频段塑形
 * 2. DynamicsProcessor  —— 压缩/限幅（控制峰值，为放大留出余量）
 * 3. LoudnessNormalizer —— 响度归一化
 * 4. VolumeBooster      —— 音量放大 + 软限幅（链路末端，最终收敛）
 */
public final class AudioProcessorChain implements AudioProcessor {

    private final List<AudioProcessor> mProcessors = new ArrayList<>();
    private int mSampleRate;
    private int mChannels;
    private boolean mInited;

    public AudioProcessorChain() {}

    public AudioProcessorChain add(AudioProcessor p) {
        if (p == null) return this;
        mProcessors.add(p);
        if (mInited) p.init(mSampleRate, mChannels);
        return this;
    }

    public void remove(AudioProcessor p) {
        mProcessors.remove(p);
    }

    public void clear() {
        for (AudioProcessor p : mProcessors) p.release();
        mProcessors.clear();
    }

    @SuppressWarnings("unchecked")
    public <T extends AudioProcessor> T get(Class<T> clazz) {
        for (AudioProcessor p : mProcessors) {
            if (clazz.isInstance(p)) return (T) p;
        }
        return null;
    }

    public int size() { return mProcessors.size(); }

    @Override
    public void init(int sampleRate, int channels) {
        mSampleRate = sampleRate;
        mChannels = channels;
        mInited = true;
        for (AudioProcessor p : mProcessors) {
            p.init(sampleRate, channels);
        }
    }

    @Override
    public void process(float[] buf, int off, int len) {
        for (AudioProcessor p : mProcessors) {
            p.process(buf, off, len);
        }
    }

    @Override
    public void reset() {
        for (AudioProcessor p : mProcessors) {
            p.reset();
        }
    }

    @Override
    public void release() {
        for (AudioProcessor p : mProcessors) {
            p.release();
        }
        mProcessors.clear();
        mInited = false;
    }
}
