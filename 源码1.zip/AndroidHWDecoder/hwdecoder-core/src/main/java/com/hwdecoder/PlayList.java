package com.hwdecoder;

import java.util.ArrayList;
import java.util.List;

/**
 * 简易播放列表：支持列表播放、单曲循环、列表循环。
 */
public final class PlayList {

    public enum RepeatMode { OFF, ONE, ALL }

    private final List<String> mSources = new ArrayList<>();
    private int mIndex;
    private RepeatMode mRepeatMode = RepeatMode.OFF;

    public PlayList() {}

    public PlayList(String single) {
        mSources.add(single);
    }

    public void add(String source) {
        mSources.add(source);
    }

    public void addAll(List<String> sources) {
        mSources.addAll(sources);
    }

    public void clear() {
        mSources.clear();
        mIndex = 0;
    }

    public int size() { return mSources.size(); }

    public int getIndex() { return mIndex; }

    public String getCurrent() {
        if (mSources.isEmpty()) return null;
        if (mIndex < 0) mIndex = 0;
        if (mIndex >= mSources.size()) mIndex = mSources.size() - 1;
        return mSources.get(mIndex);
    }

    public String get(int index) {
        if (index < 0 || index >= mSources.size()) return null;
        return mSources.get(index);
    }

    public void setRepeatMode(RepeatMode mode) { mRepeatMode = mode; }

    public RepeatMode getRepeatMode() { return mRepeatMode; }

    /**
     * 播放结束后的下一步。
     *
     * @return 下一个应播放的索引；-1 表示停止
     */
    public int advance() {
        if (mSources.isEmpty()) return -1;
        switch (mRepeatMode) {
            case ONE:
                return mIndex;
            case ALL:
                mIndex = (mIndex + 1) % mSources.size();
                return mIndex;
            case OFF:
            default:
                if (mIndex + 1 < mSources.size()) {
                    mIndex++;
                    return mIndex;
                }
                return -1;
        }
    }

    public boolean hasPrevious() {
        return mIndex > 0 || mRepeatMode == RepeatMode.ALL;
    }

    public int previous() {
        if (mSources.isEmpty()) return -1;
        if (mIndex > 0) {
            mIndex--;
        } else if (mRepeatMode == RepeatMode.ALL) {
            mIndex = mSources.size() - 1;
        }
        return mIndex;
    }

    /** 跳转到指定索引 */
    public boolean select(int index) {
        if (index < 0 || index >= mSources.size()) return false;
        mIndex = index;
        return true;
    }
}
