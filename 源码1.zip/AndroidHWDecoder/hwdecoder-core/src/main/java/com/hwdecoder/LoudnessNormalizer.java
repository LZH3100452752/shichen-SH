package com.hwdecoder;

/**
 * 响度归一化（EBU R128-lite）。
 * <p>
 * 使用 R128 的 K-weighting 两级滤波器（高频搁架 + RLB 高通）测量加权响度，
 * 以 400ms 块计算平均响度，通过平滑增益把输出拉到目标 LUFS，
 * 解决不同片源音量差异大的问题（例如综艺节目忽大忽小）。
 * 增益限制在 ±12 dB，且带 1s 时间常数平滑，听感自然。
 */
public final class LoudnessNormalizer implements AudioProcessor {

    private static final float EPS = 1e-7f;
    private static final long BLOCK_FRAMES = 400; // ms

    private final BiquadFilter mPreFilter = new BiquadFilter();  // 高频搁架 (+4dB @ ~1.5kHz)
    private final BiquadFilter mRlbFilter = new BiquadFilter();  // RLB 高通 (~38Hz @48k)

    private float mTargetLufs = -16f;
    private boolean mEnabled = true;

    private int mSampleRate = 48000;
    private int mChannels = 2;
    private float mGainDb;                 // 当前应用增益（平滑后）
    private double mBlockSumSq;
    private long mBlockCount;
    private float[] mWeighted;

    public LoudnessNormalizer() {}

    public void setTargetLufs(float lufs) {
        mTargetLufs = lufs < -40f ? -40f : (lufs > -6f ? -6f : lufs);
    }

    public void setEnabled(boolean enabled) { mEnabled = enabled; }

    public float getCurrentGainDb() { return mGainDb; }

    @Override
    public void init(int sampleRate, int channels) {
        mSampleRate = sampleRate;
        mChannels = channels;
        mWeighted = new float[Math.max(1024, channels * 4096)];
        mPreFilter.init(channels);
        mRlbFilter.init(channels);
        // K-weighting 系数随采样率缩放
        double fs = sampleRate;
        mPreFilter.setHighShelf(fs, 1681.974450955533, 0.7071752369554196, 3.999843853973347);
        mRlbFilter.setHighPass(fs, 38.13547087602444, 0.5003270373238773);
        mGainDb = 0f;
        mBlockSumSq = 0;
        mBlockCount = 0;
    }

    @Override
    public void process(float[] buf, int off, int len) {
        if (!mEnabled || mWeighted == null) return;
        int frames = len / mChannels;
        if (frames <= 0) return;

        // 1. 加权滤波
        if (frames * mChannels > mWeighted.length) {
            // 块过大时分批处理
            int done = 0;
            while (done < frames) {
                int n = Math.min(frames - done, mWeighted.length / mChannels);
                System.arraycopy(buf, off + done * mChannels, mWeighted, 0, n * mChannels);
                mPreFilter.process(mWeighted, 0, n * mChannels);
                mRlbFilter.process(mWeighted, 0, n * mChannels);
                accumulateAndApply(buf, off + done * mChannels, mWeighted, n * mChannels);
                done += n;
            }
            return;
        }
        System.arraycopy(buf, off, mWeighted, 0, len);
        mPreFilter.process(mWeighted, 0, len);
        mRlbFilter.process(mWeighted, 0, len);
        accumulateAndApply(buf, off, mWeighted, len);
    }

    private void accumulateAndApply(float[] out, int outOff, float[] weighted, int len) {
        // 2. 累加加权均方值
        for (int i = 0; i < len; i++) {
            double w = weighted[i];
            mBlockSumSq += w * w;
        }
        mBlockCount += len / mChannels;

        // 3. 每 400ms 更新一次目标增益
        if (mBlockCount >= (long) (mSampleRate * BLOCK_FRAMES / 1000.0)) {
            double totalSamples = (double) mBlockCount * mChannels;
            double meanSq = mBlockSumSq / Math.max(1.0, totalSamples);
            double loudness = -0.691 + 10.0 * Math.log10(Math.max(meanSq, EPS));
            float desiredDb = (float) (mTargetLufs - loudness);
            if (desiredDb > 12f) desiredDb = 12f;
            if (desiredDb < -12f) desiredDb = -12f;
            // 1s 时间常数平滑（按块数近似）
            float alpha = 0.2f;
            mGainDb = mGainDb * (1f - alpha) + desiredDb * alpha;
            mBlockSumSq = 0;
            mBlockCount = 0;
        }

        // 4. 应用增益
        float gain = (float) Math.pow(10.0, mGainDb / 20.0);
        for (int i = 0; i < len; i++) {
            out[outOff + i] *= gain;
        }
    }

    @Override
    public void reset() {
        mGainDb = 0f;
        mBlockSumSq = 0;
        mBlockCount = 0;
        mPreFilter.setBypass(true);
        mRlbFilter.setBypass(true);
    }

    @Override
    public void release() {}
}
