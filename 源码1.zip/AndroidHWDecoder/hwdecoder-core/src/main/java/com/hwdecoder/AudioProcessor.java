package com.hwdecoder;

/**
 * 音频处理器接口。DSP 链路由若干处理器串行组成，
 * 处理交错的 float PCM（范围不受 ±1.0 限制，放大后由末端限幅器收敛）。
 */
public interface AudioProcessor {

    /** 初始化（首次拿到采样率/声道数时调用） */
    void init(int sampleRate, int channels);

    /** 就地处理 [off, off+len) 区间（交错多声道） */
    void process(float[] buf, int off, int len);

    /** seek / flush 时重置内部状态 */
    void reset();

    /** 释放资源 */
    void release();

    /** 处理引入的延迟（ms），用于统计展示 */
    default int getLatencyMs() { return 0; }
}
