package com.hwdecoder;

/**
 * 频谱分析器（FFT，供可视化使用）。
 * <p>
 * 数据流：音频解码线程 push 单声道混合采样（无锁环形缓冲），
 * UI 线程 pull 时做一次 1024 点实数 FFT（Hann 窗），
 * 输出按对数分组的频段幅值（0~1 归一化）。
 * <p>
 * push 为 O(1) 无分配；pull 为 O(N log N) 且仅在 UI 需要时执行，
 * 不影响解码热路径。
 */
public final class SpectrumAnalyzer {

    private static final int FFT_SIZE = 1024;      // 2 的幂
    private static final int HISTORY = 4;          // 环形缓冲长度（批次数）

    private final float[] mRing = new float[FFT_SIZE * HISTORY];
    private int mRingPos;                          // 写入位置（采样）
    private int mAvailable;                        // 可用采样数（累计，回卷前）
    private final float[] mWindow = new float[FFT_SIZE];
    private final float[] mRe = new float[FFT_SIZE];
    private final float[] mIm = new float[FFT_SIZE];
    private final int[] mBitRev = new int[FFT_SIZE];
    private final float[] mMagnitudes = new float[FFT_SIZE / 2];

    /** 频段数（对数分组，覆盖 ~30Hz ~ 16kHz） */
    private final int mBands;
    private final float[] mBandValues;
    private final int[] mBandLo;
    private final int[] mBandHi;

    public SpectrumAnalyzer(int sampleRate) {
        // Hann 窗
        for (int i = 0; i < FFT_SIZE; i++) {
            mWindow[i] = 0.5f - 0.5f * (float) Math.cos(2.0 * Math.PI * i / (FFT_SIZE - 1));
        }
        // 位反转表
        int bits = Integer.numberOfTrailingZeros(FFT_SIZE);
        for (int i = 0; i < FFT_SIZE; i++) {
            int rev = Integer.reverse(i) >>> (32 - bits);
            mBitRev[i] = rev;
        }
        // 对数频段：以 1/6 倍频程从 30Hz 到 min(16k, nyquist*0.9)
        int sr = sampleRate > 0 ? sampleRate : 48000;
        float nyquist = sr / 2f;
        float fLo = 30f;
        float fHi = Math.min(16000f, nyquist * 0.9f);
        int bands = 24;
        mBands = bands;
        mBandValues = new float[bands];
        mBandLo = new int[bands];
        mBandHi = new int[bands];
        float binHz = (float) sr / FFT_SIZE;
        for (int b = 0; b < bands; b++) {
            float f0 = fLo * (float) Math.pow(fHi / fLo, (double) b / bands);
            float f1 = fLo * (float) Math.pow(fHi / fLo, (double) (b + 1) / bands);
            int lo = Math.max(1, Math.round(f0 / binHz));
            int hi = Math.min(mMagnitudes.length - 1, Math.round(f1 / binHz));
            if (hi < lo) hi = lo;
            mBandLo[b] = lo;
            mBandHi[b] = hi;
        }
    }

    /** 推入单声道采样（float，-1~1 附近） */
    public void push(float[] data, int off, int len) {
        int n = Math.min(len, FFT_SIZE);
        for (int i = 0; i < n; i++) {
            mRing[mRingPos] = data[off + i];
            mRingPos = (mRingPos + 1) % mRing.length;
            mAvailable++;
        }
    }

    public int getBandCount() {
        return mBands;
    }

    /**
     * 取最近一窗的频段幅值（0~1，已平滑）。
     *
     * @param out 长度 >= getBandCount() 的输出数组
     * @return 实际写入的频段数
     */
    public int getBands(float[] out) {
        int count = Math.min(out.length, mBands);
        if (mAvailable < FFT_SIZE) {
            for (int b = 0; b < count; b++) out[b] = 0f;
            return count;
        }
        // 取最近 FFT_SIZE 个采样（从环形缓冲拼出，应用 Hann 窗）
        int start = (mRingPos - FFT_SIZE + mRing.length * 2) % mRing.length;
        for (int i = 0; i < FFT_SIZE; i++) {
            float v = mRing[(start + i) % mRing.length];
            mRe[mBitRev[i]] = v * mWindow[i];
            mIm[mBitRev[i]] = 0f;
        }
        fft();
        // 计算幅值并做对数压缩
        for (int k = 0; k < mMagnitudes.length; k++) {
            float re = mRe[k];
            float im = mIm[k];
            float mag = (float) Math.sqrt(re * re + im * im) / (FFT_SIZE / 4f);
            mMagnitudes[k] = mag;
        }
        for (int b = 0; b < count; b++) {
            float peak = 0f;
            for (int k = mBandLo[b]; k <= mBandHi[b]; k++) {
                if (mMagnitudes[k] > peak) peak = mMagnitudes[k];
            }
            // 归一化到 0~1（对数压缩，低音量也可见）
            float v = (float) (Math.log10(1.0 + 9.0 * Math.min(1f, peak)) );
            // 平滑（趋向上一次的值，避免闪烁）
            mBandValues[b] = mBandValues[b] * 0.6f + v * 0.4f;
            out[b] = mBandValues[b];
        }
        return count;
    }

    /** 重置（seek / flush） */
    public void reset() {
        java.util.Arrays.fill(mRing, 0f);
        mRingPos = 0;
        mAvailable = 0;
        java.util.Arrays.fill(mBandValues, 0f);
    }

    // ---------------- 实数 FFT（迭代 Radix-2）----------------

    private void fft() {
        int n = FFT_SIZE;
        for (int len = 2; len <= n; len <<= 1) {
            double ang = -2.0 * Math.PI / len;
            float wRe = (float) Math.cos(ang);
            float wIm = (float) Math.sin(ang);
            for (int i = 0; i < n; i += len) {
                float curRe = 1f, curIm = 0f;
                for (int j = 0; j < len / 2; j++) {
                    float uRe = mRe[i + j];
                    float uIm = mIm[i + j];
                    float vRe = mRe[i + j + len / 2] * curRe - mIm[i + j + len / 2] * curIm;
                    float vIm = mRe[i + j + len / 2] * curIm + mIm[i + j + len / 2] * curRe;
                    mRe[i + j] = uRe + vRe;
                    mIm[i + j] = uIm + vIm;
                    mRe[i + j + len / 2] = uRe - vRe;
                    mIm[i + j + len / 2] = uIm - vIm;
                    float nextRe = curRe * wRe - curIm * wIm;
                    curIm = curRe * wIm + curIm * wRe;
                    curRe = nextRe;
                }
            }
        }
    }
}
