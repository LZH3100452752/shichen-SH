package com.hwdecoder;

import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.os.Build;
import android.os.Process;

import com.hwdecoder.audio.AudioOutput;
import com.hwdecoder.audio.AudioTrackOutput;
import com.hwdecoder.audio.OpenSLOutput;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * 音频硬件解码单元。
 * <p>
 * 设计要点：
 * 1. 准备（输出设备/解码器创建）与解码循环分离，解码线程只在播放开始后运行；
 * 2. 解码线程独立高优先级（THREAD_PRIORITY_URGENT_AUDIO）并绑定大核；
 * 3. 优先请求 ENCODING_PCM_FLOAT 输出（API 24+），使音量放大不被 16bit 量化限制；
 * 4. 解码 -> DSP 链（声道路由/EQ/压缩/响度归一/音量放大限幅）-> 输出，全 float 处理；
 * 5. 音频为主时钟：每写入一段后以实际播放位置校准 MediaClock，长播不漂移；
 * 6. seek 后丢弃目标时间之前的采样块，保证起播准确；
 * 7. 输出后端可选 AudioTrack（主）或 OpenSL ES（低延迟/原生 DSP），可自动回退；
 * 8. 缓冲区对象复用，解码热路径零分配；
 * 9. 起播预缓冲：先解码一小段内容再启动输出设备，避免起播欠载卡顿；
 * 10. 多音轨选择、频谱数据输出（供可视化）。
 */
final class AudioDecoder implements Runnable {

    interface Host {
        DecoderConfig config();

        MediaClock clock();

        StatsCollector stats();

        android.content.Context context();

        /** 音频就绪：DSP 链已建立，可供外部实时调参 */
        void onAudioReady(AudioProcessorChain dspChain, String codecName, boolean hardware);

        /** 音频流结束，或不存在音频轨 */
        void onAudioEos();

        /** 不存在音频轨（纯视频文件），prepare 阶段调用一次 */
        void onAudioTrackAbsent();

        /** 起播预缓冲完成：可以打开视频渲染门控与主时钟 */
        void onAudioPrebuffered();

        void onDecoderError(int errorCode, String message);
    }

    private static final long INPUT_TIMEOUT_US = 10_000L;
    private static final long OUTPUT_TIMEOUT_US = 10_000L;
    private static final long PAUSE_POLL_MS = 20L;

    private final Host mHost;
    private final String mSource;
    private final int mAudioTrackIndex; // -1 = 第一个音频轨

    private MediaExtractor mExtractor;
    private MediaCodec mCodec;
    private String mMime;
    private String mCodecName;
    private boolean mHardware;

    private AudioOutput mOutput;
    private AudioProcessorChain mDspChain;
    private ChannelRouter mChannelRouter;
    private Equalizer mEqualizer;
    private VolumeBooster mVolumeBooster;
    private SpectrumAnalyzer mSpectrum;
    private int mSampleRate;
    private int mChannels;
    private boolean mFloatPcm;
    private boolean mTrackAbsent;

    // 复用缓冲（解码热路径零分配）
    private float[] mScratchFloats;
    private short[] mScratchShorts;
    private float[] mMonoScratch;

    // 起播预缓冲
    private volatile boolean mPrebuffering;
    private volatile boolean mCanPrebuffer;
    private long mPrebufferTargetUs;
    private long mPrebufferStartPtsUs = -1L;
    private long mPrebufferDeadlineNs;

    private Thread mDecodeThread;
    private volatile boolean mQuit;
    private volatile boolean mPaused;
    private volatile boolean mPrepared;
    private volatile boolean mSeekRequested;
    private volatile long mSeekTargetUs;
    private volatile long mSkipUntilUs = Long.MIN_VALUE;
    private volatile boolean mInputEos;
    private volatile boolean mOutputEos;
    private volatile boolean mAlignClock = true;
    private volatile boolean mEosDelivered;
    private volatile float mPendingVolume = -1f;

    private final MediaCodec.BufferInfo mBufferInfo = new MediaCodec.BufferInfo();

    AudioDecoder(Host host, String source, int audioTrackIndex) {
        mHost = host;
        mSource = source;
        mAudioTrackIndex = audioTrackIndex;
    }

    /** 输出设备是否自行管理缓冲（OpenSL ES 有原生环形缓冲，无需 Java 侧预缓冲） */
    boolean willPrebuffer() {
        return mCanPrebuffer;
    }

    /** 是否存在音频轨 */
    boolean isTrackAbsent() {
        return mTrackAbsent;
    }

    // ---------------- 生命周期 ----------------

    /** 在独立线程完成准备（打开源、输出设备、解码器、DSP 链） */
    void prepareAsync() {
        Thread t = new Thread(() -> {
            Process.setThreadPriority(Process.THREAD_PRIORITY_DEFAULT);
            try {
                if (prepare()) {
                    mPrepared = true;
                    mHost.onAudioReady(mDspChain, mCodecName, mHardware);
                }
            } catch (Throwable t2) {
                mHost.onDecoderError(HWDecoder.ERROR_PREPARE,
                        "audio prepare failed: " + t2);
            }
        }, "hwdec-audio-prepare");
        t.start();
    }

    /** 开始解码循环（幂等） */
    private void ensureDecodeThreadStarted() {
        if (mDecodeThread != null || !mPrepared) return;
        mQuit = false;
        mDecodeThread = new Thread(this, "hwdec-audio");
        mDecodeThread.start();
    }

    void pause() {
        mPaused = true;
        if (mOutput != null) mOutput.pause();
        mHost.clock().setPaused(true);
    }

    /**
     * 恢复播放。
     *
     * @param deferStart true = 起播预缓冲：先解码一小段再启动输出设备与主时钟
     */
    void resumePlayback(boolean deferStart) {
        mPaused = false;
        ensureDecodeThreadStarted();
        if (mOutput == null) {
            mHost.clock().setPaused(false);
            return;
        }
        if (deferStart && mCanPrebuffer) {
            mPrebuffering = true;
            mPrebufferTargetUs = Math.min(mHost.config().getPreBufferMs(), 150L) * 1000L;
            mPrebufferStartPtsUs = -1L;
            mPrebufferDeadlineNs = System.nanoTime() + 300_000_000L;
        } else {
            mPrebuffering = false;
            mOutput.start();
            mHost.clock().setPaused(false);
        }
    }

    void requestSeek(long targetUs) {
        if (!mPrepared) return;
        mSeekTargetUs = targetUs;
        mSeekRequested = true;
        mSkipUntilUs = Long.MIN_VALUE;
        mAlignClock = false;
        // seek 打断预缓冲：立即启动输出并打开视频门控
        if (mPrebuffering) {
            mPrebuffering = false;
            if (mOutput != null) mOutput.start();
            mHost.clock().setPaused(false);
            mHost.onAudioPrebuffered();
        }
        if (mOutput != null) mOutput.flush();
        mHost.clock().setPositionUs(targetUs);
    }

    void quit() {
        mQuit = true;
        mPaused = false;
    }

    boolean isDone() {
        return mOutputEos;
    }

    AudioProcessorChain getDspChain() {
        return mDspChain;
    }

    Equalizer getEqualizer() {
        return mEqualizer;
    }

    /** 频谱分析器（prepare 后可用，pull 模式取数据） */
    SpectrumAnalyzer getSpectrumAnalyzer() {
        return mSpectrum;
    }

    /** 声道路由（声道模式：立体声/交换/单声道/仅左/仅右） */
    void setChannelMode(int mode) {
        if (mChannelRouter != null) {
            mChannelRouter.setMode(mode);
        }
    }

    int getChannelMode() {
        return mChannelRouter != null ? mChannelRouter.getMode()
                : ChannelRouter.MODE_STEREO;
    }

    /** 设置音量（线性增益 0~8） */
    void setVolume(float gain) {
        if (mVolumeBooster != null) {
            mVolumeBooster.setGain(gain);
        } else {
            mPendingVolume = gain;
        }
    }

    /** 设置倍速（透传输出后端：WSOLA 或设备侧重采样） */
    void setSpeed(float speed) {
        if (mOutput != null) {
            mOutput.setPitchPreserve(mHost.config().isPitchPreserve());
            mOutput.setSpeed(speed);
        }
    }

    /** 变速不变调开关（下次变速或立即生效，由后端实现决定） */
    void setPitchPreserve(boolean preserve) {
        if (mOutput != null) {
            mOutput.setPitchPreserve(preserve);
        }
    }

    float getVolume() {
        return mVolumeBooster != null ? mVolumeBooster.getGain() : mPendingVolume;
    }

    AudioOutput getOutput() {
        return mOutput;
    }

    // ---------------- 解码主循环 ----------------

    @Override
    public void run() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        // 解码线程绑定大核：高倍速/低延迟场景下的算力保障（默认关闭，按需开启）
        if (mHost.config() != null && mHost.config().isBigCoreBinding() && NativeLib.isAvailable()) {
            try {
                NativeLib.nativeBindThreadToBigCore();
            } catch (Throwable ignored) {
                // 个别设备/内核不支持 affinity 设置，静默降级
            }
        }
        try {
            while (!mQuit) {
                if (mPaused) {
                    Thread.sleep(PAUSE_POLL_MS);
                    continue;
                }
                if (mSeekRequested) {
                    doSeek();
                    continue;
                }
                if (mInputEos && !mOutputEos) {
                    drainOutput();
                    if (mOutputEos) {
                        // 排空变速保持缓冲，保证尾音完整
                        if (mOutput != null) {
                            try {
                                mOutput.drain();
                            } catch (Throwable ignored) {
                            }
                        }
                        if (!mEosDelivered) {
                            mEosDelivered = true;
                            mHost.onAudioEos();
                        }
                        break;
                    }
                    continue;
                }
                feedInput();
                drainOutput();
            }
        } catch (Throwable t) {
            if (!mQuit) {
                mHost.onDecoderError(HWDecoder.ERROR_DECODE,
                        "audio decode failed: " + t);
            }
        } finally {
            releaseAll();
            mDecodeThread = null;
        }
    }

    // ---------------- 初始化 ----------------

    private boolean prepare() {
        mExtractor = new MediaExtractor();
        try {
            setDataSourceCompat(mExtractor, mSource, mHost.context());
        } catch (Throwable t) {
            mHost.onDecoderError(HWDecoder.ERROR_PREPARE, "open audio source failed: " + t);
            return false;
        }

        int track = -1;
        int seen = 0;
        for (int i = 0; i < mExtractor.getTrackCount(); i++) {
            MediaFormat f = mExtractor.getTrackFormat(i);
            String mime = f.getString(MediaFormat.KEY_MIME);
            if (mime != null && mime.startsWith("audio/")) {
                if (mAudioTrackIndex < 0) {
                    track = i;
                    break;
                }
                if (seen == mAudioTrackIndex) {
                    track = i;
                    break;
                }
                seen++;
            }
        }
        if (track < 0) {
            // 纯视频文件：没有音频单元
            mTrackAbsent = true;
            mOutputEos = true;
            mEosDelivered = true;
            mHost.onAudioEos();
            mHost.onAudioTrackAbsent();
            return false;
        }
        mExtractor.selectTrack(track);
        MediaFormat format = mExtractor.getTrackFormat(track);
        mMime = format.getString(MediaFormat.KEY_MIME);
        try {
            mSampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE);
        } catch (Throwable ignored) {
            mSampleRate = 44100;
        }
        try {
            mChannels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
        } catch (Throwable ignored) {
            mChannels = 2;
        }
        if (mChannels <= 0) mChannels = 1;
        if (mChannels > 8) mChannels = 8;

        // ---- 先选择音频解码器（configure 后才知道真实输出参数）----
        DecoderConfig cfg = mHost.config();
        boolean created = false;
        Throwable lastError = null;
        for (MediaCodecInfo info : CodecSelector.candidates(mMime)) {
            boolean hw = CodecSelector.isHardwareAccelerated(info);
            if (cfg.isHardwareOnly() && !hw) continue;
            if (!cfg.isSoftwareFallback() && !hw) continue;
            try {
                mCodec = MediaCodec.createByCodecName(info.getName());
                mCodecName = info.getName();
                mHardware = hw;
                configureCodec(format);
                created = true;
                break;
            } catch (Throwable t) {
                lastError = t;
                releaseCodec();
                mCodec = null;
            }
        }
        if (!created) {
            mHost.onDecoderError(HWDecoder.ERROR_UNSUPPORTED,
                    "no decoder for " + mMime + (lastError != null ? ": " + lastError : ""));
            return false;
        }

        // ---- 打开输出后端（AUTO: AudioTrack 优先，失败切 OpenSL ES）----
        // 显式指定 AUDIO_TRACK 时失败即失败（不回退 OpenSL ES），尊重调用方意图
        AudioOutput output = null;
        if (cfg.getAudioBackend() != DecoderConfig.AudioBackend.OPEN_SL_ES) {
            AudioTrackOutput ato = new AudioTrackOutput();
            if (ato.open(mSampleRate, mChannels, cfg.getAudioBufferMs(),
                    cfg.isLowLatencyAudio()) == AudioOutput.RESULT_OK) {
                output = ato;
            }
        }
        if (output == null && cfg.getAudioBackend() == DecoderConfig.AudioBackend.AUTO) {
            OpenSLOutput oso = new OpenSLOutput();
            if (oso.open(mSampleRate, mChannels, cfg.getAudioBufferMs(),
                    cfg.isLowLatencyAudio()) == AudioOutput.RESULT_OK) {
                output = oso;
            }
        }
        if (output == null) {
            mHost.onDecoderError(HWDecoder.ERROR_AUDIO_DEVICE, "no audio output available");
            return false;
        }
        mOutput = output;
        mCanPrebuffer = !output.managesOwnBuffering();
        if (cfg.getSpeed() != 1.0f) {
            mOutput.setPitchPreserve(cfg.isPitchPreserve());
            mOutput.setSpeed(cfg.getSpeed());
        }

        // ---- 构建 DSP 链（声道路由置首，后续各级按序处理）----
        mDspChain = new AudioProcessorChain();
        mChannelRouter = new ChannelRouter(mChannels);
        mEqualizer = new Equalizer();
        DynamicsProcessor dynamics = new DynamicsProcessor();
        LoudnessNormalizer loudness = new LoudnessNormalizer();
        mVolumeBooster = new VolumeBooster(cfg.getVolume());
        mSpectrum = new SpectrumAnalyzer(mSampleRate);
        if (cfg.isEnableDsp()) {
            mDspChain.add(mChannelRouter);
            mDspChain.add(mEqualizer);
            mDspChain.add(dynamics);
            if (cfg.isLoudnessNorm()) {
                loudness.setTargetLufs(cfg.getLoudnessTargetLufs());
                mDspChain.add(loudness);
            }
            mDspChain.add(mVolumeBooster);
        } else {
            // 未启用 DSP 时仍保留音量放大与声道路由（核心功能）
            mDspChain.add(mChannelRouter);
            mDspChain.add(mVolumeBooster);
        }
        mDspChain.init(mSampleRate, mChannels);

        if (mPendingVolume > 0) {
            mVolumeBooster.setGain(mPendingVolume);
        }
        mHost.stats().setCodecInfo(null, false, mCodecName, mHardware);
        return true;
    }

    private void configureCodec(MediaFormat srcFormat) {
        MediaFormat format = new MediaFormat();
        try {
            String mime = srcFormat.getString(MediaFormat.KEY_MIME);
            format.setString(MediaFormat.KEY_MIME, mime != null ? mime : mMime);
        } catch (Throwable ignored) {
            format.setString(MediaFormat.KEY_MIME, mMime);
        }
        format.setInteger(MediaFormat.KEY_SAMPLE_RATE, mSampleRate);
        format.setInteger(MediaFormat.KEY_CHANNEL_COUNT, mChannels);
        try {
            int maxInput = srcFormat.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE);
            if (maxInput > 0) format.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, maxInput);
        } catch (Throwable ignored) {
        }
        // 请求 float PCM 输出（API 24+），音量放大不失真
        if (Build.VERSION.SDK_INT >= 24) {
            format.setInteger(MediaFormat.KEY_PCM_ENCODING,
                    android.media.AudioFormat.ENCODING_PCM_FLOAT);
        }
        // 低延迟解码提示（Opus/AAC 等部分硬件解码器支持，降低内部缓冲）
        try {
            format.setInteger(MediaFormat.KEY_LOW_LATENCY, 1);
        } catch (Throwable ignored) {
        }
        format.setInteger(MediaFormat.KEY_PRIORITY, 0); // 实时优先级
        mCodec.configure(format, null, null, 0);
        mCodec.start();
        mInputEos = false;
        mOutputEos = false;
        // 探测实际 PCM 编码与输出参数
        MediaFormat outFmt = mCodec.getOutputFormat();
        try {
            int enc = outFmt.getInteger(MediaFormat.KEY_PCM_ENCODING);
            mFloatPcm = enc == android.media.AudioFormat.ENCODING_PCM_FLOAT;
        } catch (Throwable t) {
            mFloatPcm = false;
        }
        try {
            int sr = outFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE);
            if (sr > 0) mSampleRate = sr;
        } catch (Throwable ignored) {
        }
        try {
            int ch = outFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            if (ch > 0) mChannels = ch;
        } catch (Throwable ignored) {
        }
    }

    // ---------------- 送数据 / 收 PCM ----------------

    private void feedInput() {
        if (mInputEos || mCodec == null) return;
        int idx = mCodec.dequeueInputBuffer(INPUT_TIMEOUT_US);
        if (idx < 0) return;
        ByteBuffer buffer = mCodec.getInputBuffer(idx);
        if (buffer == null) return;
        int size = mExtractor.readSampleData(buffer, 0);
        if (size < 0) {
            mCodec.queueInputBuffer(idx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
            mInputEos = true;
            return;
        }
        long pts = mExtractor.getSampleTime();
        mCodec.queueInputBuffer(idx, 0, size, pts, 0);
        mHost.stats().onBytesDecoded(size);
        mExtractor.advance();
    }

    private void drainOutput() {
        int idx = mCodec.dequeueOutputBuffer(mBufferInfo, OUTPUT_TIMEOUT_US);
        if (idx < 0) return;

        long pts = mBufferInfo.presentationTimeUs;
        // seek 后丢弃目标时间之前的采样
        if (mSkipUntilUs != Long.MIN_VALUE) {
            if (pts < mSkipUntilUs) {
                mCodec.releaseOutputBuffer(idx, false);
                if ((mBufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    mOutputEos = true;
                }
                return;
            }
            mSkipUntilUs = Long.MIN_VALUE;
            mAlignClock = true;
        }

        if ((mBufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
            mOutputEos = true;
        }

        int size = mBufferInfo.size;
        if (size > 0) {
            ByteBuffer out = mCodec.getOutputBuffer(idx);
            if (out != null) {
                out.position(mBufferInfo.offset);
                out.limit(mBufferInfo.offset + size);
                int floats = size / (mFloatPcm ? 4 : 2);
                ensureScratch(floats);
                if (mFloatPcm) {
                    out.order(ByteOrder.nativeOrder());
                    out.asFloatBuffer().get(mScratchFloats, 0, floats);
                } else {
                    out.order(ByteOrder.nativeOrder());
                    java.nio.ShortBuffer sb = out.asShortBuffer();
                    sb.get(mScratchShorts, 0, floats);
                    for (int i = 0; i < floats; i++) {
                        mScratchFloats[i] = mScratchShorts[i] / 32768f;
                    }
                }
                // DSP 链处理（float 域）
                mDspChain.process(mScratchFloats, 0, floats);
                // 频谱数据（单声道混合，供可视化）
                if (mSpectrum != null) {
                    int frames = floats / mChannels;
                    if (mMonoScratch == null || mMonoScratch.length < frames) {
                        mMonoScratch = new float[Math.max(frames, 4096)];
                    }
                    if (mChannels == 1) {
                        mSpectrum.push(mScratchFloats, 0, frames);
                    } else {
                        for (int f = 0; f < frames; f++) {
                            float sum = 0f;
                            int base = f * mChannels;
                            for (int c = 0; c < mChannels; c++) sum += mScratchFloats[base + c];
                            mMonoScratch[f] = sum / mChannels;
                        }
                        mSpectrum.push(mMonoScratch, 0, frames);
                    }
                }
                int frames = mOutput.write(mScratchFloats, 0, floats, pts);
                if (frames > 0) {
                    mHost.stats().onAudioDecoded(frames);
                }
                // 起播预缓冲门控：解码足量内容后启动输出设备与主时钟
                if (mPrebuffering) {
                    checkPrebuffer(pts);
                }
                // 音频为主时钟：用实际播放位置校准
                if (mAlignClock && !mPaused && !mPrebuffering) {
                    long pos = mOutput.getPlaybackPositionUs();
                    if (pos > 0) {
                        mHost.clock().alignTo(pos, System.nanoTime());
                    }
                }
            }
        }
        mCodec.releaseOutputBuffer(idx, false);
    }

    private void ensureScratch(int floats) {
        if (mScratchFloats == null || mScratchFloats.length < floats) {
            mScratchFloats = new float[Math.max(floats, 8192)];
            mScratchShorts = new short[mScratchFloats.length];
        }
    }

    /**
     * 起播预缓冲门控检查：解码内容达到目标（或超时）后启动输出设备，
     * 并通知宿主打开视频渲染门控与主时钟。
     */
    private void checkPrebuffer(long ptsUs) {
        if (mPrebufferStartPtsUs < 0) mPrebufferStartPtsUs = ptsUs;
        boolean enough = (ptsUs - mPrebufferStartPtsUs) >= mPrebufferTargetUs;
        boolean buffered = mOutput != null
                && mOutput.getBufferedMs() >= mPrebufferTargetUs / 1000L;
        boolean timeout = System.nanoTime() >= mPrebufferDeadlineNs;
        if (enough || buffered || timeout) {
            mPrebuffering = false;
            if (mOutput != null) mOutput.start();
            mHost.clock().setPaused(false);
            mHost.onAudioPrebuffered();
        }
    }

    // ---------------- seek / 释放 ----------------

    private void doSeek() {
        long target = mSeekTargetUs;
        mSeekRequested = false;
        try {
            if (mCodec != null) {
                mCodec.flush();
                mCodec.start();
            }
            mExtractor.seekTo(target, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            mInputEos = false;
            mOutputEos = false;
            mEosDelivered = false;
            mSkipUntilUs = target; // 精确起播：解码并丢弃早于目标的采样
        } catch (Throwable t) {
            mHost.onDecoderError(HWDecoder.ERROR_DECODE, "audio seek failed: " + t);
        }
    }

    private void releaseCodec() {
        if (mCodec != null) {
            try {
                mCodec.stop();
            } catch (Throwable ignored) {
            }
            try {
                mCodec.release();
            } catch (Throwable ignored) {
            }
            mCodec = null;
        }
        if (mExtractor != null) {
            try {
                mExtractor.release();
            } catch (Throwable ignored) {
            }
            mExtractor = null;
        }
    }

    private void releaseAll() {
        releaseCodec();
        if (mDspChain != null) {
            mDspChain.release();
            mDspChain = null;
        }
        if (mOutput != null) {
            mOutput.close();
            mOutput = null;
        }
    }

    private static void setDataSourceCompat(MediaExtractor extractor, String source,
                                            android.content.Context context) throws Exception {
        if (source == null) throw new IllegalArgumentException("null source");
        if (source.startsWith("content://") && context != null) {
            extractor.setDataSource(context, android.net.Uri.parse(source), null);
        } else {
            extractor.setDataSource(source);
        }
    }
}
