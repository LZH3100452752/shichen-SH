package com.hwdecoder.audio;

/**
 * WSOLA（Waveform Similarity Overlap-Add）变速不变调重采样器。
 * <p>
 * 倍速播放时保持音调不变（不会变尖），解决高倍速下的听感问题。
 * 与原生层 {@code hwd::WsolaResampler} 算法一致：
 * <ul>
 *   <li>Hann 窗分析/合成段，段间 overlap-add；</li>
 *   <li>每段在输入基准位置 ±Delta 范围内做波形相似度搜索（归一化互相关），
 *       选取最「自然延续」的位置，抑制颤音与金属感；</li>
 *   <li>相似度搜索只取声道 0、步长 2 抽样，控制 CPU 开销；</li>
 *   <li>流式语义：未消费的输入尾部由调用方保留，跨调用连续。</li>
 * </ul>
 * 非线程安全：由音频输出单线程调用。
 */
final class WsolaResampler {

    private final int mCh;
    private final int mWin;
    private final int mHop;
    private final int mDelta;
    private final float[] mWindow;
    private final float[] mSeg;
    private final float[] mTail;
    private final float[] mRef;
    private int mLastStart;
    private boolean mHasHistory;
    private int mSegIndex;

    WsolaResampler(int channels, int winFrames, int hopFrames, int deltaFrames) {
        mCh = channels > 0 ? channels : 1;
        mWin = Math.max(64, winFrames);
        mHop = Math.max(16, hopFrames);
        mDelta = Math.max(8, deltaFrames);
        mWindow = new float[mWin];
        for (int i = 0; i < mWin; i++) {
            mWindow[i] = 0.5f - 0.5f * (float) Math.cos(2.0 * Math.PI * i / (mWin - 1));
        }
        mSeg = new float[mWin * mCh];
        mTail = new float[(mWin - mHop) * mCh];
        mRef = new float[mWin * mCh];
        reset();
    }

    void reset() {
        java.util.Arrays.fill(mSeg, 0f);
        java.util.Arrays.fill(mTail, 0f);
        java.util.Arrays.fill(mRef, 0f);
        mLastStart = 0;
        mHasHistory = false;
        mSegIndex = 0;
    }

    /** 产出 outFrames 帧所需的输入帧数下限 */
    static int requiredInput(int outFrames, float ratio, int winFrames, int deltaFrames,
                             int hopFrames) {
        int ss = Math.round(hopFrames * ratio);
        if (ss < 1) ss = 1;
        int segs = (outFrames + hopFrames - 1) / hopFrames;
        return ss * (segs - 1) + winFrames + deltaFrames;
    }

    /**
     * 处理一段（流式）。
     *
     * @param in          输入（交错，帧为单位计数）
     * @param inFrames    输入可用帧数
     * @param out         输出缓冲（至少 maxOut 帧）
     * @param maxOut      期望产出帧数
     * @param ratio       输入/输出 比（= 倍速，&gt;1 表示加速）
     * @param channels    声道数
     * @param consumedOut 输出参数（长度 1）：可消费的输入帧数
     * @return 实际产出的帧数
     */
    int process(float[] in, int inFrames, float[] out, int maxOut,
                float ratio, int channels, int[] consumedOut) {
        int ch = channels > 0 ? channels : mCh;
        int ss = Math.round(mHop * ratio);
        if (ss < 1) ss = 1;
        int produced = 0;
        int consumed = 0;
        mSegIndex = 0; // 每次调用从输入起点开始（未消费尾部已由调用方保留）

        while (produced < maxOut) {
            int base = mSegIndex * ss;
            // 输入充足性：最坏偏移 +mDelta 后仍需完整一窗
            if (base + mWin + mDelta > inFrames) break;

            // 相似度参考窗：「上一段起点 + mHop」处的自然延续
            int refStart = mLastStart + mHop;
            if (refStart < 0) refStart = 0;
            if (refStart + mWin > inFrames) refStart = inFrames - mWin;
            if (refStart < 0) refStart = 0;
            System.arraycopy(in, refStart * ch, mRef, 0, mWin * ch);

            int bestOff = 0;
            if (mHasHistory) {
                float bestScore = -1e30f;
                for (int off = -mDelta; off <= mDelta; off++) {
                    int start = base + off;
                    if (start < 0) start = 0;
                    if (start + mWin > inFrames) start = inFrames - mWin;
                    // 归一化互相关（声道 0，步长 2 抽样）
                    float num = 0f, da = 0f, db = 0f;
                    for (int k = 0; k < mWin; k += 2) {
                        float a = in[start * ch];
                        float b = mRef[k * ch];
                        num += a * b;
                        da += a * a;
                        db += b * b;
                    }
                    float denom = (float) Math.sqrt(da * db) + 1e-9f;
                    float score = num / denom;
                    score -= Math.abs(off) * 1e-5f; // 轻微偏移惩罚
                    if (score > bestScore) {
                        bestScore = score;
                        bestOff = off;
                    }
                }
            }

            int start = base + bestOff;
            if (start < 0) start = 0;
            if (start + mWin > inFrames) start = inFrames - mWin;
            mLastStart = start;
            mHasHistory = true;

            // 提取段并加 Hann 窗（边界不足补零）
            java.util.Arrays.fill(mSeg, 0f);
            int avail = inFrames - start;
            int n = Math.min(mWin, avail);
            if (n > 0) {
                System.arraycopy(in, start * ch, mSeg, 0, n * ch);
            }
            for (int f = 0; f < mWin; f++) {
                float w = mWindow[f];
                for (int c = 0; c < ch; c++) {
                    mSeg[f * ch + c] *= w;
                }
            }
            // overlap-add 输出前 mHop 帧
            for (int j = 0; j < mHop && produced < maxOut; j++, produced++) {
                for (int c = 0; c < ch; c++) {
                    float v = mSeg[j * ch + c];
                    if (j < mWin - mHop) v += mTail[j * ch + c];
                    out[produced * ch + c] = v;
                }
            }
            // 保存尾部供下一段 overlap
            for (int j = mHop; j < mWin; j++) {
                for (int c = 0; c < ch; c++) {
                    mTail[(j - mHop) * ch + c] = mSeg[j * ch + c];
                }
            }
            mSegIndex++;
            consumed = start; // 尾部 [consumed, inFrames) 留给下次调用
        }
        consumedOut[0] = consumed;
        return produced;
    }
}
