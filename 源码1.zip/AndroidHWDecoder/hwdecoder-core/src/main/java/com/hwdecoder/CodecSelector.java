package com.hwdecoder;

import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaFormat;

import java.util.ArrayList;
import java.util.List;

/**
 * 解码器选择器：按优先级挑选硬件解码器，硬解不可用时回退软解，
 * 并对已知有兼容性问题的芯片组合做规避，提升适配性。
 */
public final class CodecSelector {

    private CodecSelector() {}

    /** 所有支持指定 mime 的解码器（硬件优先） */
    public static List<MediaCodecInfo> candidates(String mime) {
        List<MediaCodecInfo> hardware = new ArrayList<>();
        List<MediaCodecInfo> software = new ArrayList<>();
        int count = MediaCodecList.getCodecCount();
        for (int i = 0; i < count; i++) {
            MediaCodecInfo info = MediaCodecList.getCodecInfoAt(i);
            if (info.isEncoder()) continue;
            String[] types = info.getSupportedTypes();
            boolean match = false;
            for (String t : types) {
                if (t.equalsIgnoreCase(mime)) { match = true; break; }
            }
            if (!match) continue;
            if (isHardwareAccelerated(info)) {
                hardware.add(info);
            } else {
                software.add(info);
            }
        }
        hardware.addAll(software);
        return hardware;
    }

    /**
     * 挑选解码器。
     *
     * @param mime            MediaFormat.MIMETYPE_*
     * @param hardwareOnly    是否强制硬件
     * @param allowSoftware   是否允许软解
     * @param avoidNamePrefix 需要跳过的解码器名前缀（例如已知有问题的芯片实现）
     */
    public static MediaCodecInfo pick(String mime, boolean hardwareOnly, boolean allowSoftware,
                                      String avoidNamePrefix) {
        List<MediaCodecInfo> list = candidates(mime);
        for (MediaCodecInfo info : list) {
            boolean hw = isHardwareAccelerated(info);
            if (hardwareOnly && !hw) continue;
            if (!allowSoftware && !hw) continue;
            if (avoidNamePrefix != null && info.getName().startsWith(avoidNamePrefix)) continue;
            return info;
        }
        return null;
    }

    public static MediaCodecInfo pick(String mime, boolean hardwareOnly, boolean allowSoftware) {
        return pick(mime, hardwareOnly, allowSoftware, null);
    }

    /**
     * 判断是否为硬件解码器。
     * API 29+ 使用官方 isHardwareAccelerated()；以下版本按命名规则启发式判断。
     */
    public static boolean isHardwareAccelerated(MediaCodecInfo info) {
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            try {
                return info.isHardwareAccelerated();
            } catch (Throwable ignored) {
            }
        }
        String name = info.getName().toLowerCase();
        if (name.startsWith("omx.google.")) return false;      // 官方软解
        if (name.startsWith("omx.ffmpeg.")) return false;      // FFmpeg 软解
        if (name.startsWith("c2.android.")) return false;      // Codec2 软解
        if (name.contains(".sw")) return false;
        if (name.contains("ffmpeg")) return false;
        // 已知硬件厂商关键字
        return name.contains("qcom") || name.contains("mtk") || name.contains("exynos")
                || name.contains("kirin") || name.contains("hisi") || name.contains("intel")
                || name.contains("nvidia") || name.contains("ti.") || name.contains("ste")
                || name.contains("divx") || name.contains("sec")
                || name.startsWith("c2.") || name.startsWith("omx.");
    }

    /**
     * 某些芯片的 H.265 硬解存在兼容性问题，首次失败后优先切换软解。
     * 返回 true 表示建议对该 mime 直接跳过当前首选硬件解码器。
     */
    public static boolean shouldAvoidHardware(String mime, String codecName) {
        if (mime == null || codecName == null) return false;
        // 例：部分早期 MTK 平台的 HEVC 硬解花屏/崩溃，直接规避
        return mime.equalsIgnoreCase(MediaFormat.MIMETYPE_VIDEO_HEVC)
                && codecName.toLowerCase().contains("mtk");
    }
}
