# 库模块消费端混淆规则：保留 JNI 入口与对外回调接口
-keepclasseswithmembernames class * {
    native <methods>;
}
-keep interface com.hwdecoder.HWDecoderListener { *; }
