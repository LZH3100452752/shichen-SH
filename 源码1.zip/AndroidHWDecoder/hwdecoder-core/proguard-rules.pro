# 核心库混淆规则（默认不混淆，保留 JNI 相关符号）
-keep class com.hwdecoder.NativeLib { *; }
-keep class com.hwdecoder.HWDecoder { *; }
-keep class com.hwdecoder.DecoderConfig { *; }
-keep class com.hwdecoder.HWDecoderListener { *; }
