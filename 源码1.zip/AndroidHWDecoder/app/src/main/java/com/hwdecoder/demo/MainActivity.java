package com.hwdecoder.demo;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.hwdecoder.AudioProcessorChain;
import com.hwdecoder.ChannelRouter;
import com.hwdecoder.DecoderConfig;
import com.hwdecoder.DynamicsProcessor;
import com.hwdecoder.Equalizer;
import com.hwdecoder.HWDecoder;
import com.hwdecoder.HWDecoderListener;
import com.hwdecoder.LoudnessNormalizer;
import com.hwdecoder.PlayerState;
import com.hwdecoder.SpectrumAnalyzer;
import com.hwdecoder.StatsCollector;
import com.hwdecoder.TrackInfo;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * 演示 Activity：展示 HWDecoder 的完整用法。
 * <p>
 * 功能：打开本地/网络视频、播放/暂停/上下曲、拖动进度、音量放大（0~800%）、
 * 倍速（0.5~8x，变速不变调）、10 段均衡器、性能统计浮层、音轨选择、A-B 循环、
 * 单帧步进、截图、声道路由、频谱可视化、HDR 标识。
 */
public class MainActivity extends Activity implements SurfaceHolder.Callback, HWDecoderListener {

    private static final int REQ_OPEN = 1001;
    private static final String[] SPEEDS =
            {"0.5x", "0.75x", "1.0x", "1.25x", "1.5x", "2.0x", "3.0x", "4.0x", "6.0x", "8.0x"};
    private static final float[] SPEED_VALUES =
            {0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f, 3.0f, 4.0f, 6.0f, 8.0f};

    private HWDecoder mDecoder;
    private SurfaceView mSurfaceView;
    private SurfaceHolder mHolder;

    private SeekBar mSeekBar;
    private SeekBar mVolumeBar;
    private TextView mTimeText;
    private TextView mVolumeText;
    private TextView mStatsText;
    private TextView mHdrText;
    private Button mPlayBtn;
    private Spinner mSpeedSpinner;
    private CheckBox mDspBox;
    private CheckBox mStatsBox;
    private CheckBox mPitchBox;
    private LinearLayout mEqContainer;

    private boolean mSeekDragging;
    private boolean mSurfaceReady;
    private long mDurationUs;
    private List<String> mPendingSources;
    private final List<SeekBar> mEqBars = new ArrayList<>();
    private long mLoopAUs = -1L; // A-B 循环 A 点
    private final float[] mSpectrumScratch = new float[32];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mSurfaceView = findViewById(R.id.surface_view);
        mHolder = mSurfaceView.getHolder();
        mHolder.addCallback(this);

        mSeekBar = findViewById(R.id.seek_bar);
        mVolumeBar = findViewById(R.id.seek_volume);
        mTimeText = findViewById(R.id.tv_time);
        mVolumeText = findViewById(R.id.tv_volume);
        mStatsText = findViewById(R.id.stats_text);
        mHdrText = findViewById(R.id.tv_hdr);
        mPlayBtn = findViewById(R.id.btn_play);
        mSpeedSpinner = findViewById(R.id.spinner_speed);
        mDspBox = findViewById(R.id.cb_dsp);
        mStatsBox = findViewById(R.id.cb_stats);
        mPitchBox = findViewById(R.id.cb_pitch);
        mEqContainer = findViewById(R.id.eq_container);

        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                if (fromUser && mDurationUs > 0) {
                    mTimeText.setText(formatTime(progress * mDurationUs / 10000L) + " / "
                            + formatTime(mDurationUs));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
                mSeekDragging = true;
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                mSeekDragging = false;
                if (mDurationUs > 0) {
                    mDecoder.seekTo(bar.getProgress() * mDurationUs / 10000L);
                }
            }
        });

        mVolumeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                float gain = progress / 100f;
                mVolumeText.setText(progress + "%");
                if (mDecoder != null) mDecoder.setVolume(gain);
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {}

            @Override
            public void onStopTrackingTouch(SeekBar bar) {}
        });

        ArrayAdapter<String> speedAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, SPEEDS);
        speedAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mSpeedSpinner.setAdapter(speedAdapter);
        mSpeedSpinner.setSelection(2); // 1.0x
        mSpeedSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                if (mDecoder != null && position >= 0 && position < SPEED_VALUES.length) {
                    mDecoder.setSpeed(SPEED_VALUES[position]);
                }
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        // 声道路由
        Spinner channelSpinner = findViewById(R.id.spinner_channel);
        ArrayAdapter<CharSequence> channelAdapter = ArrayAdapter.createFromResource(
                this, R.array.channel_modes, android.R.layout.simple_spinner_item);
        channelAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        channelSpinner.setAdapter(channelAdapter);
        channelSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                if (mDecoder != null) mDecoder.setChannelMode(position);
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        // 变速不变调
        mPitchBox.setOnCheckedChangeListener((buttonView, checked) -> {
            if (mDecoder != null) mDecoder.setPitchPreserve(checked);
        });

        // 音轨选择
        findViewById(R.id.btn_track).setOnClickListener(v -> showTrackDialog());

        // A-B 循环：第一次点设 A，第二次设 B 并开启，第三次清除
        findViewById(R.id.btn_loop).setOnClickListener(v -> toggleLoop());

        // 单帧步进
        findViewById(R.id.btn_step).setOnClickListener(v -> {
            if (mDecoder != null) mDecoder.stepFrame();
        });

        // 截图
        findViewById(R.id.btn_capture).setOnClickListener(v -> captureFrame());

        mDspBox.setOnCheckedChangeListener((buttonView, checked) -> applyDspEnabled(checked));
        mStatsBox.setOnCheckedChangeListener((buttonView, checked) ->
                mStatsText.setVisibility(checked ? View.VISIBLE : View.GONE));

        findViewById(R.id.btn_open).setOnClickListener(v -> openFile());
        mPlayBtn.setOnClickListener(v -> {
            if (mDecoder != null) mDecoder.togglePlayPause();
        });
        findViewById(R.id.btn_prev).setOnClickListener(v -> {
            if (mDecoder != null) mDecoder.previous();
        });
        findViewById(R.id.btn_next).setOnClickListener(v -> {
            if (mDecoder != null) mDecoder.next();
        });

        buildEqPanel();

        mDecoder = new HWDecoder(this);
        mDecoder.setListener(this);

        // 支持被其它应用以 VIEW 视频方式唤起
        handleIntent(getIntent());
    }

    private void buildEqPanel() {
        mEqContainer.removeAllViews();
        mEqBars.clear();
        Equalizer eq = mDecoder != null ? mDecoder.getEqualizer() : null;
        if (eq == null) {
            // prepare 前先用默认频点占位，prepare 后回填
            double[] freqs = {31, 63, 125, 250, 500, 1000, 2000, 4000, 8000, 16000};
            for (double f : freqs) {
                mEqContainer.addView(makeEqColumn((int) f, null, -1));
            }
            return;
        }
        for (int i = 0; i < eq.getBandCount(); i++) {
            mEqContainer.addView(makeEqColumn((int) eq.getBandFreq(i), eq, i));
        }
    }

    private View makeEqColumn(int freq, Equalizer eq, int band) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(4, 2, 4, 2);

        TextView label = new TextView(this);
        label.setText(freq + "Hz");
        label.setTextColor(0xFFFFFFFF);
        label.setTextSize(9);
        label.setGravity(android.view.Gravity.CENTER);
        col.addView(label);

        SeekBar bar = new SeekBar(this);
        bar.setMax(240);
        bar.setProgress(120);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(72,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        bar.setLayoutParams(lp);
        if (eq != null) {
            bar.setProgress((int) (120 + eq.getBandGain(band) * 10));
        }
        TextView dbText = new TextView(this);
        dbText.setText("0dB");
        dbText.setTextColor(0xFFFFFF00);
        dbText.setTextSize(9);
        dbText.setGravity(android.view.Gravity.CENTER);

        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float db = (progress - 120) / 10f;
                dbText.setText(db + "dB");
                if (eq != null) eq.setBandGain(band, db);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        mEqBars.add(bar);
        col.addView(bar);

        col.addView(dbText);

        return col;
    }

    private void applyDspEnabled(boolean enabled) {
        AudioProcessorChain chain = mDecoder.getDspChain();
        if (chain == null) return;
        Equalizer eq = chain.get(Equalizer.class);
        if (eq != null) eq.setEnabled(enabled);
        DynamicsProcessor dyn = chain.get(DynamicsProcessor.class);
        if (dyn != null) dyn.setEnabled(enabled);
        LoudnessNormalizer ln = chain.get(LoudnessNormalizer.class);
        if (ln != null) ln.setEnabled(enabled);
    }

    // ---- 音轨选择 ----

    private void showTrackDialog() {
        if (mDecoder == null) return;
        List<TrackInfo> tracks = mDecoder.getTrackList();
        if (tracks == null || tracks.isEmpty()) {
            Toast.makeText(this, "轨道信息不可用", Toast.LENGTH_SHORT).show();
            return;
        }
        List<TrackInfo> audios = new ArrayList<>();
        for (TrackInfo t : tracks) {
            if (t.type == TrackInfo.TYPE_AUDIO) audios.add(t);
        }
        if (audios.isEmpty()) {
            Toast.makeText(this, "无音频轨", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] names = new String[audios.size()];
        for (int i = 0; i < audios.size(); i++) names[i] = audios.get(i).describe();
        new android.app.AlertDialog.Builder(this)
                .setTitle("选择音轨")
                .setItems(names, (dialog, which) -> {
                    if (mDecoder.selectAudioTrack(audios.get(which).index)) {
                        Toast.makeText(this, "已切换: " + names[which], Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    // ---- A-B 循环 ----

    private void toggleLoop() {
        if (mDecoder == null) return;
        if (mDecoder.isLooping()) {
            mDecoder.clearLoopRange();
            mLoopAUs = -1L;
            Toast.makeText(this, "A-B 循环已清除", Toast.LENGTH_SHORT).show();
            return;
        }
        long pos = mDecoder.getPositionUs();
        if (mLoopAUs < 0) {
            mLoopAUs = pos;
            Toast.makeText(this, "A 点: " + formatTime(pos) + "，再次点击设 B", Toast.LENGTH_SHORT).show();
        } else {
            if (pos <= mLoopAUs) {
                Toast.makeText(this, "B 点需晚于 A 点", Toast.LENGTH_SHORT).show();
                return;
            }
            mDecoder.setLoopRange(mLoopAUs, pos);
            Toast.makeText(this, "A-B 循环: " + formatTime(mLoopAUs) + " ~ " + formatTime(pos),
                    Toast.LENGTH_SHORT).show();
            mLoopAUs = -1L;
        }
    }

    // ---- 截图 ----

    private void captureFrame() {
        if (mDecoder == null || mSurfaceView == null) return;
        mDecoder.captureFrame(mSurfaceView, new HWDecoder.CaptureCallback() {
            @Override
            public void onCaptured(android.graphics.Bitmap bitmap) {
                try {
                    File dir = new File(getExternalFilesDir(null), "captures");
                    if (!dir.exists()) dir.mkdirs();
                    File f = new File(dir, "frame_" + System.currentTimeMillis() + ".png");
                    FileOutputStream fos = new FileOutputStream(f);
                    bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, fos);
                    fos.close();
                    Toast.makeText(MainActivity.this, "已保存: " + f.getAbsolutePath(),
                            Toast.LENGTH_LONG).show();
                } catch (Throwable t) {
                    Toast.makeText(MainActivity.this, "保存失败: " + t, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onError(String message) {
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void openFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("video/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(intent, REQ_OPEN);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_OPEN || resultCode != RESULT_OK || data == null) return;
        List<String> sources = new ArrayList<>();
        if (data.getData() != null) {
            sources.add(data.getData().toString());
        }
        if (data.getClipData() != null) {
            int n = data.getClipData().getItemCount();
            for (int i = 0; i < n; i++) {
                Uri u = data.getClipData().getItemAt(i).getUri();
                if (u != null) sources.add(u.toString());
            }
        }
        if (sources.isEmpty()) return;
        playSources(sources);
    }

    private void playSources(List<String> sources) {
        // Surface 未就绪时先挂起，等 surfaceCreated 后再启动（视频解码必须有 Surface）
        if (!mSurfaceReady) {
            mPendingSources = sources;
            return;
        }
        int speedPos = mSpeedSpinner.getSelectedItemPosition();
        float speed = speedPos >= 0 && speedPos < SPEED_VALUES.length ? SPEED_VALUES[speedPos] : 1f;
        DecoderConfig.Builder builder = DecoderConfig.builder()
                .source(sources.get(0))
                .volume(mVolumeBar.getProgress() / 100f)
                .autoPlay(true)
                .enableDsp(true)
                .statsIntervalMs(1000)
                .speed(speed)
                .pitchPreserve(mPitchBox.isChecked())
                .preBufferMs(250)
                .bigCoreBinding(true)
                .pauseOnBecomingNoisy(true);
        if (mSurfaceReady) {
            builder.surface(mHolder.getSurface());
        }
        DecoderConfig cfg = builder.build();
        if (sources.size() > 1) {
            mDecoder.setPlayList(sources, cfg);
        } else {
            mDecoder.setDataSource(cfg);
        }
        mDecoder.prepareAsync();
        mPlayBtn.setText(R.string.pause);
    }

    private void handleIntent(Intent intent) {
        if (intent == null) return;
        Uri uri = intent.getData();
        if (uri == null) return;
        String scheme = uri.getScheme();
        if ("http".equals(scheme) || "https".equals(scheme)) {
            List<String> sources = new ArrayList<>();
            sources.add(uri.toString());
            playSources(sources);
        } else {
            List<String> sources = new ArrayList<>();
            sources.add(uri.toString());
            playSources(sources);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    // ---- SurfaceHolder.Callback ----

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        mSurfaceReady = true;
        mDecoder.setSurface(holder.getSurface());
        mDecoder.setSurfaceSize(holder.getSurfaceFrame().width(),
                holder.getSurfaceFrame().height());
        if (mPendingSources != null) {
            List<String> pending = mPendingSources;
            mPendingSources = null;
            playSources(pending);
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        mDecoder.setSurface(holder.getSurface());
        mDecoder.setSurfaceSize(width, height);
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        mSurfaceReady = false;
    }

    // ---- HWDecoderListener ----

    @Override
    public void onStateChanged(PlayerState state) {
        runOnUiThread(() -> {
            switch (state) {
                case PLAYING:
                    mPlayBtn.setText(R.string.pause);
                    break;
                case PAUSED:
                case COMPLETED:
                    mPlayBtn.setText(R.string.play);
                    break;
                case ERROR:
                    mPlayBtn.setText(R.string.play);
                    break;
                default:
                    break;
            }
        });
    }

    @Override
    public void onPrepared(int width, int height, long durationUs) {
        runOnUiThread(() -> {
            mDurationUs = durationUs;
            buildEqPanel(); // 用真实频点重建 EQ 面板
            Toast.makeText(this, width + "x" + height + "  " + formatTime(durationUs),
                    Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public void onProgress(long positionUs, long durationUs) {
        runOnUiThread(() -> {
            if (!mSeekDragging && durationUs > 0) {
                int pct = (int) (positionUs * 10000 / durationUs);
                mSeekBar.setProgress(pct);
            }
            mTimeText.setText(formatTime(positionUs) + " / " + formatTime(durationUs));
        });
    }

    @Override
    public void onCompletion() {
        runOnUiThread(() -> mPlayBtn.setText(R.string.play));
    }

    @Override
    public void onError(int errorCode, String message) {
        runOnUiThread(() -> Toast.makeText(this, "错误[" + errorCode + "]: " + message,
                Toast.LENGTH_LONG).show());
    }

    @Override
    public void onStats(StatsCollector.Stats stats) {
        runOnUiThread(() -> {
            if (!mStatsBox.isChecked()) return;
            StringBuilder sb = new StringBuilder();
            sb.append(String.format(
                    "解码 %s(%.1ffps) 丢帧%.1f%% | 音频 %s | 缓冲%dms | 码率%.0fkbps | underrun%d",
                    stats.videoCodec.isEmpty() ? "-" : stats.videoCodec,
                    stats.videoFps, stats.dropRatio * 100,
                    stats.audioCodec.isEmpty() ? "-" : stats.audioCodec,
                    stats.audioBufferMs, stats.bitrateKbps, stats.audioUnderruns));
            sb.append('\n');
            sb.append(buildSpectrumLine());
            mStatsText.setText(sb.toString());
        });
    }

    /** 频谱 ASCII 可视化：从核心库 SpectrumAnalyzer 取 24 段对数频段能量 */
    private String buildSpectrumLine() {
        if (mDecoder == null) return "";
        SpectrumAnalyzer sa = mDecoder.getSpectrumAnalyzer();
        if (sa == null) return "";
        float[] bands = mSpectrumScratch;
        int count = Math.min(sa.getBands(bands), 24);
        final char[] glyphs = {' ', '\u2581', '\u2582', '\u2583', '\u2584', '\u2585', '\u2586', '\u2587', '\u2588'};
        StringBuilder sb = new StringBuilder("\u266B ");
        for (int i = 0; i < count; i++) {
            float v = bands[i];
            if (v < 0f) v = 0f;
            if (v > 1f) v = 1f;
            int idx = (int) (v * (glyphs.length - 1));
            if (idx == 0 && v > 0.02f) idx = 1;
            sb.append(glyphs[idx]);
        }
        return sb.toString();
    }

    @Override
    public void onVideoHdrChanged(boolean hdr) {
        runOnUiThread(() -> {
            mHdrText.setText(hdr ? "HDR" : "SDR");
            mHdrText.setTextColor(hdr ? 0xFFFFD700 : 0xFFAAAAAA);
        });
    }

    @Override
    public void onFrameStepped(long ptsUs) {
        runOnUiThread(() -> mTimeText.setText(
                formatTime(ptsUs) + " / " + formatTime(mDurationUs)));
    }

    @Override
    public void onAudioPrebuffered() {
        // 起播预缓冲完成：主时钟与视频渲染门控已打开，可在此隐藏加载提示
    }

    @Override
    public void onVideoSizeChanged(int width, int height) {
        runOnUiThread(() -> {
            // 可在此调整 SurfaceView 比例，演示从略
        });
    }

    private static String formatTime(long us) {
        long totalSec = us / 1_000_000L;
        long sec = totalSec % 60;
        long min = (totalSec / 60) % 60;
        long hour = totalSec / 3600;
        if (hour > 0) {
            return String.format("%d:%02d:%02d", hour, min, sec);
        }
        return String.format("%02d:%02d", min, sec);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mDecoder != null && mDecoder.isPlaying()) {
            mDecoder.pause();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mDecoder != null) {
            mDecoder.release();
            mDecoder = null;
        }
    }
}
