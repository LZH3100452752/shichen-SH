# 保留 JNI 入口
-keepclasseswithmembernames class * {
    native <methods>;
}
# 保留解码器对外回调接口
-keep interface com.hwdecoder.HWDecoderListener { *; }
