#!/system/bin/sh
# =====================================================================
#  AutoRescue · late_start service
#  启动看门狗守护 + 可选的 WebUI 常驻服务
#  作者: 时尘  v2.2
# =====================================================================

MODDIR=${0%/*}
export MODDIR
. "$MODDIR/common/functions.sh"
. "$MODDIR/common/rescue.sh"
. "$MODDIR/common/scan.sh"
. "$MODDIR/common/guard.sh"

ar_init_dirs
ar_conf_defaults

ar_log INFO "===== service 阶段 ====="
ar_state_set last_stage "service"

# ---------------------------------------------------------------- 防护初始化
if [ "$(ar_conf_get guard_enable 1)" = "1" ]; then
    if [ ! -s "$AR_DATA/guard/baseline" ]; then
        ar_guard_baseline >/dev/null 2>&1
        ar_log INFO "防护基线已在开机时建立"
    fi
fi

# ---------------------------------------------------------------- 新模块体检
if [ "$(ar_conf_get auto_scan_new 1)" = "1" ]; then
    ( sleep 25; sh "$MODDIR/common/api.sh" scanall > "$AR_TMP/boot_scan.json" 2>/dev/null ) &
fi

# ---------------------------------------------------------------- 守护进程
if [ "$(ar_conf_get watchdog 1)" = "1" ]; then
    if [ -f "$AR_TMP/watchdog.pid" ]; then
        old=$(cat "$AR_TMP/watchdog.pid" 2>/dev/null)
        if [ -z "$old" ] || [ ! -d "/proc/$old" ]; then
            nohup sh "$MODDIR/common/watchdog.sh" >/dev/null 2>&1 &
            ar_log INFO "已启动看门狗守护"
        fi
    else
        nohup sh "$MODDIR/common/watchdog.sh" >/dev/null 2>&1 &
        ar_log INFO "已启动看门狗守护"
    fi
fi

# ---------------------------------------------------------------- WebUI 常驻
if [ "$(ar_conf_get webui_autostart 1)" = "1" ]; then
    BBX=$(ar_busybox)
    if [ -n "$BBX" ]; then
        port=$(ar_conf_get webui_port 8080)
        $BBX wget -q -O /dev/null "http://127.0.0.1:$port/index.html" 2>/dev/null \
            || sh "$MODDIR/action.sh" --silent >/dev/null 2>&1
    fi
fi

# ---------------------------------------------------------------- 开机冲突扫描(可选)
if [ "$(ar_conf_get conflict_scan_onboot 0)" = "1" ]; then
    sh "$MODDIR/common/api.sh" conflict > "$AR_TMP/last_conflict.json" 2>/dev/null &
fi

exit 0
