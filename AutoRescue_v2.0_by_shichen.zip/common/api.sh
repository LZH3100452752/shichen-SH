#!/system/bin/sh
# =====================================================================
#  AutoRescue · WebUI 后端 API
#  用法: sh common/api.sh <action> [参数...]
#        输出统一 JSON: {"ok":true,"data":...} / {"ok":false,"error":"..."}
#  作者: 时尘  v2.0
# =====================================================================

MODDIR="${MODDIR:-/data/adb/modules/auto_rescue}"
export MODDIR
. "$MODDIR/common/functions.sh"
. "$MODDIR/common/rescue.sh"
. "$MODDIR/common/scan.sh"
. "$MODDIR/common/guard.sh"
. "$MODDIR/common/scan.sh" 2>/dev/null
. "$MODDIR/common/guard.sh" 2>/dev/null

AR_WEBROOT="$MODDIR/webroot"


# ================================================================
#  v1.6 新增: 救援演练 / 诊断包导出 / 清理 / 模块文件查看
# ================================================================

# 等级已精简为 3 级(原 L3/L4/L5 -> 现 L1/L2/L3)
ar_level_title() {
    case "$1" in
        1) printf 'L1 禁用全部非白名单模块';;
        2) printf 'L2 连同白名单一起禁用';;
        3) printf 'L3 移除模块目录(最强)';;
        *) printf '未知等级';;
    esac
}
ar_level_desc() {
    case "$1" in
        1) printf '禁用所有模块, 但保留白名单与锁定项';;
        2) printf '白名单也不保留, 只留本守护模块自身';;
        3) printf '直接改名模块目录, 彻底移除挂载';;
        *) printf '';;
    esac
}

# 某模块是否会被某等级救援命中
#   $1=序号(1=最新) $2=等级 $3=是否非白名单(1/0) $4=是否本守护自身
ar_dry_hit() {
    local n="$1" lv="$2" nwl="$3" self="$4"
    [ "$self" = "1" ] && { printf 'no'; return 0; }
    [ "$nwl" = "1" ] || { printf 'no'; return 0; }
    # 等级已精简为 3 级:
    #   L1 = 全部非白名单(传入的 nwl 已区分是否白名单/锁定)
    #   L2 / L3 = 含白名单一起处理, 但守护自身与锁定项仍排除
    case "$lv" in
        1|2|3) printf 'yes';;
        *) printf 'no';;
    esac
}

# 救援演练: 计算各等级会禁用哪些模块, 不做任何改动
dryrun_title() {
    case "$1" in
        1) echo "L1 常规清场 (禁用全部非白名单模块)";;
        2) echo "L2 深度清场 (禁用全部模块, 只留守护自身)";;
        *) echo "L3 终极隔离 (移除全部模块挂载)";;
    esac
}

dryrun_json() {
    local lv id nm self nwl hit n total d
    local out="" items cnt
    total=0
    for lv in 1 2 3; do
        n=0; cnt=0; items=""
        # ar_module_dirs 已按 mtime 从新到旧返回完整路径
        for d in $(ar_module_dirs); do
            [ -n "$d" ] || continue
            id=$(basename "$d")
            [ -f "$d/disable" ] && continue
            case "$id" in *.ar_quarantine|*.ar_disabled) continue;; esac
            n=$((n+1))
            [ "$lv" = "1" ] && total=$n
            [ "$id" = "$AR_ID" ] && self=1 || self=0
            if ar_is_whitelisted "$id" 2>/dev/null; then nwl=0; else nwl=1; fi
            # 排除名单: 连 L2/L3 都不动, 演练里也要体现出来
            if ar_is_excluded "$id" 2>/dev/null; then nwl=0; self=1; fi
            hit=$(ar_dry_hit "$n" "$lv" "$nwl" "$self")
            if [ "$hit" = "yes" ]; then
                cnt=$((cnt+1))
                nm=$(ar_prop "$d" name "$id" 2>/dev/null)
                [ -z "$nm" ] && nm="$id"
                items="$items{\"id\":\"$(ar_json_esc "$id")\",\"name\":\"$(ar_json_esc "$nm")\",\"order\":$n,\"protected\":$([ "$self" = "1" ] && echo 1 || echo 0)},"
            fi
        done
        out="$out{\"level\":$lv,\"title\":\"$(ar_json_esc "$(ar_level_title "$lv")")\",\"desc\":\"$(ar_json_esc "$(ar_level_desc "$lv")")\",\"count\":$cnt,\"items\":[${items%,}]},"
    done
    printf '{"total_enabled":%s,"levels":[%s]}' "$total" "${out%,}"
}

# 导出诊断包到 /sdcard/AutoRescue
export_bundle() {
    local dir="/sdcard/AutoRescue"
    local ts; ts=$(date '+%Y%m%d_%H%M%S' 2>/dev/null)
    [ -z "$ts" ] && ts="export"
    local f="$dir/diag_$ts.txt"
    mkdir -p "$dir" 2>/dev/null || { fail "无法创建目录 $dir"; return 1; }
    {
        printf '===== AutoRescue 诊断包 =====\n'
        printf '生成时间: %s\n' "$(ar_now)"
        printf '模块版本: %s   作者: %s\n\n' "$AR_VER" "$AR_AUTHOR"
        printf '----- 设备信息 -----\n'
        device_json | tr ',' '\n' | sed 's/[{}"]//g'
        printf '\n----- 救援状态 -----\n'
        status_json | tr ',' '\n' | sed 's/[{}"]//g'
        printf '\n----- 启用中的模块 -----\n'
        local d
        for d in $(ar_module_dirs); do
            [ -n "$d" ] || continue
            printf '%s   %s\n' "$(basename "$d")" "$(ar_prop "$d" name "$(basename "$d")" 2>/dev/null)"
        done
        printf '\n----- 救援历史 -----\n'
        tail -n 30 "$AR_DATA/history.log" 2>/dev/null
        printf '\n----- 最近日志 -----\n'
        tail -n 120 "$AR_LOG" 2>/dev/null
    } > "$f" 2>/dev/null
    chmod 0644 "$f" 2>/dev/null
    if [ -s "$f" ]; then
        printf '{"path":"%s","size":%s}' "$(ar_json_esc "$f")" \
            "$(wc -c < "$f" 2>/dev/null | tr -d ' ')"
    else
        fail "导出失败"
    fi
}

# 清理: 清空日志 + 按保留数删旧快照
do_cleanup() {
    local keep; keep=$(ar_conf_get snapshot_keep 10)
    case "$keep" in ''|*[!0-9]*) keep=10;; esac
    local total removed=0
    total=$(ls -1 "$AR_SNAP"/*.meta 2>/dev/null | wc -l | tr -d ' ')
    case "$total" in ''|*[!0-9]*) total=0;; esac
    if [ "$total" -gt "$keep" ]; then
        removed=$((total - keep))
        ls -1t "$AR_SNAP"/*.meta 2>/dev/null | tail -n "$removed" | \
        while read -r mf; do
            [ -n "$mf" ] || continue
            sid=$(basename "$mf" .meta)
            rm -f "$AR_SNAP/$sid.meta" "$AR_SNAP/$sid.list" 2>/dev/null
        done
    fi
    : > "$AR_LOG" 2>/dev/null
    ar_log INFO "已执行清理: 日志已清空, 删除 $removed 个旧快照"
    printf '{"log_cleared":true,"snapshots_removed":%s}' "$removed"
}

# 模块内文本类文件列表
modfiles_json() {
    local id="$1" d f sz out=""
    [ -z "$id" ] && { fail "缺少模块 ID"; return 1; }
    d="$MODULES_DIR/$id"
    [ -d "$d" ] || { fail "模块不存在"; return 1; }
    for f in "$d"/module.prop "$d"/service.sh "$d"/post-fs-data.sh \
             "$d"/system.prop "$d"/uninstall.sh "$d"/action.sh \
             "$d"/boot-completed.sh; do
        [ -f "$f" ] || continue
        sz=$(wc -c < "$f" 2>/dev/null | tr -d ' ')
        case "$sz" in ''|*[!0-9]*) sz=0;; esac
        out="$out{\"name\":\"$(ar_json_esc "${f#$d/}")\",\"size\":$sz},"
    done
    local cf
    for cf in $(ls -1 "$d"/common/*.sh 2>/dev/null); do
        [ -f "$cf" ] || continue
        sz=$(wc -c < "$cf" 2>/dev/null | tr -d ' ')
        case "$sz" in ''|*[!0-9]*) sz=0;; esac
        out="$out{\"name\":\"$(ar_json_esc "common/${cf##*/}")\",\"size\":$sz},"
    done
    printf '{"id":"%s","files":[%s]}' "$(ar_json_esc "$id")" "${out%,}"
}

# 读取模块内脚本内容(只读)
modfile_json() {
    local id="$1" name="$2" f c
    [ -z "$id" ] && { fail "缺少模块 ID"; return 1; }
    [ -z "$name" ] && { fail "缺少文件名"; return 1; }
    case "$name" in *..*|/*) fail "非法文件名"; return 1;; esac
    f="$MODULES_DIR/$id/$name"
    [ -f "$f" ] || { fail "文件不存在"; return 1; }
    c=$(head -c 40000 "$f" 2>/dev/null)
    printf '{"id":"%s","name":"%s","content":"%s"}' \
        "$(ar_json_esc "$id")" "$(ar_json_esc "$name")" "$(ar_json_esc "$c")"
}

# ================================================================
#  v1.7 新增: 排除名单 / 模块备份
# ================================================================

ar_exclude_list_json() {
    local out="" id
    [ -f "$AR_EXCLUDE" ] || { printf '[]'; return 0; }
    while IFS= read -r id; do
        [ -n "$id" ] || continue
        out="$out\"$(ar_json_esc "$id")\","
    done < "$AR_EXCLUDE"
    printf '[%s]' "${out%,}"
}

# 备份某个模块目录
do_backup() {
    local id="$1" tag="${2:-manual}"
    [ -z "$id" ] && { fail "缺少模块 ID"; return 1; }
    [ -d "$MODULES_DIR/$id" ] || { fail "模块不存在"; return 1; }
    ar_mkdir "$AR_BACKUP"
    local ts; ts=$(date '+%Y%m%d_%H%M%S' 2>/dev/null)
    [ -z "$ts" ] && ts="$(ar_ts)"
    local name="${id}_${ts}"
    local dst="$AR_BACKUP/$name"
    cp -a "$MODULES_DIR/$id" "$dst" 2>/dev/null || { fail "备份失败"; return 1; }
    printf '{"name":"%s","id":"%s","tag":"%s","time":"%s","size":%s}' \
        "$(ar_json_esc "$name")" "$(ar_json_esc "$id")" "$(ar_json_esc "$tag")" \
        "$(ar_json_esc "$(ar_now)")" \
        "$(du -sk "$dst" 2>/dev/null | awk '{print $1}' | head -1)"
}

backup_list_json() {
    local out="" d nm sz id tm
    for d in $(ls -1td "$AR_BACKUP"/*/ 2>/dev/null); do
        d="${d%/}"
        nm=$(basename "$d")
        [ -n "$nm" ] || continue
        sz=$(du -sk "$d" 2>/dev/null | awk '{print $1}' | head -1)
        case "$sz" in ''|*[!0-9]*) sz=0;; esac
        id="${nm%%_*}"
        tm=$(stat -c %y "$d" 2>/dev/null | cut -d'.' -f1)
        [ -z "$tm" ] && tm="$nm"
        out="$out{\"name\":\"$(ar_json_esc "$nm")\",\"id\":\"$(ar_json_esc "$id")\",\"size\":$sz,\"time\":\"$(ar_json_esc "$tm")\"},"
    done
    printf '[%s]' "${out%,}"
}

# 还原备份: 先备份当前, 再覆盖回去
do_backup_restore() {
    local name="$1"
    [ -z "$name" ] && { fail "缺少备份名"; return 1; }
    case "$name" in *..*|/*) fail "非法名称"; return 1;; esac
    [ -d "$AR_BACKUP/$name" ] || { fail "备份不存在"; return 1; }
    local id="${name%%_*}"
    [ -d "$MODULES_DIR/$id" ] && rm -rf "$MODULES_DIR/$id" 2>/dev/null
    cp -a "$AR_BACKUP/$name" "$MODULES_DIR/$id" 2>/dev/null || { fail "还原失败"; return 1; }
    ar_log WARN "已从备份还原模块: $id ($name)"
    printf '{"done":true,"id":"%s"}' "$(ar_json_esc "$id")"
}

# ================================================================
#  v1.8 新增: 进阶救砖 / 系统健康检查
# ================================================================

# ---------- 按卡死阶段精准救援 ----------
# 卡在 post-fs-data 就只禁带 post-fs-data.sh 的模块;
# 卡在 service 就只禁带 service.sh 的。比"按安装时间盲禁"精准得多,
# 能大幅减少无辜模块被禁用。
ar_stage_rescue() {
    local stage="${1:-auto}" d id n=0 acted=0 detail=""

    if [ "$stage" = "auto" ]; then
        stage=$(ar_state_get last_stage)
        case "$stage" in
            *post-fs-data*) stage="post-fs-data";;
            *service*)      stage="service";;
            *boot*)         stage="boot-completed";;
            *)              stage="service";;
        esac
    fi

    local pat=""
    case "$stage" in
        post-fs-data) pat="post-fs-data.sh";;
        service)      pat="service.sh";;
        *)            pat="boot-completed.sh";;
    esac

    ar_log ERROR "!!!! 阶段精准救援 !!!! 阶段=$stage 匹配=$pat"

    for d in $(ar_module_dirs); do
        id=$(basename "$d")
        [ "$id" = "$AR_ID" ] && continue
        if ar_is_excluded "$id" 2>/dev/null; then
            ar_log INFO "已锁定, 跳过: $id"; continue
        fi
        # 只处理确实含有该阶段脚本的模块
        [ -f "$d/$pat" ] || continue
        [ "$(ar_module_enabled "$d")" = "1" ] || continue
        if ar_disable_module "$d"; then
            acted=1; n=$((n+1))
            detail="$detail$(ar_prop "$d" name "$id") "
        fi
    done

    ar_state_set boot_count 0
    ar_state_set last_stage "stage-rescue"
    printf '{"stage":"%s","matched":"%s","count":%s,"detail":"%s"}' \
        "$(ar_json_esc "$stage")" "$(ar_json_esc "$pat")" "$n" "$(ar_json_esc "$detail")"
}

# ---------- 修复模块文件权限 ----------
# 权限不对会导致脚本根本不执行, 或被系统拒绝加载, 表现很像"变砖"
ar_fix_perm() {
    local d id n=0
    for d in $(ar_module_dirs); do
        id=$(basename "$d")
        chmod 0755 "$d" 2>/dev/null
        local f
        for f in "$d"/*.sh "$d"/common/*.sh "$d"/system/bin/*; do
            [ -f "$f" ] || continue
            chmod 0755 "$f" 2>/dev/null && n=$((n+1))
        done
        [ -f "$d/module.prop" ] && chmod 0644 "$d/module.prop" 2>/dev/null
    done
    # 自身的脚本也一并修正
    local g
    for g in "$MODDIR"/*.sh "$MODDIR"/common/*.sh "$MODDIR"/tools/*.sh \
             "$MODDIR"/webroot/cgi-bin/api; do
        [ -f "$g" ] && { chmod 0755 "$g" 2>/dev/null && n=$((n+1)); }
    done
    ar_log INFO "已修复文件权限: $n 个文件"
    printf '{"fixed":%s}' "$n"
}

# ---------- 修复 SELinux context ----------
# 刷入/替换模块后文件 context 常常是 u:object_r:unlabeled:s0 或 sdcardfs,
# 会导致系统拒绝执行, 表现为开机卡死。restorecon 能把它们改回来。
ar_fix_context() {
    local n=0
    if command -v restorecon >/dev/null 2>&1; then
        restorecon -R "$MODULES_DIR" >/dev/null 2>&1 && n=$((n+1))
        restorecon -R "$MODDIR" >/dev/null 2>&1 && n=$((n+1))
        ar_log INFO "已执行 restorecon: $n 个目录"
        printf '{"ok":true,"dirs":%s}' "$n"
    else
        fail "当前环境没有 restorecon"
    fi
}

# ---------- 清理损坏的模块目录 ----------
# 空目录 / 没有 module.prop 的残留目录, 有些面具加载时会直接报错卡死
ar_clean_broken() {
    local d id removed="" n=0
    for d in $(ls -1d "$MODULES_DIR"/*/ 2>/dev/null); do
        d="${d%/}"
        id=$(basename "$d")
        [ -n "$id" ] || continue
        [ "$id" = "$AR_ID" ] && continue
        # 锁定 / 白名单模块不清理, 避免误删用户明确要保留的
        if ar_is_excluded "$id" 2>/dev/null || ar_is_whitelisted "$id" 2>/dev/null; then
            continue
        fi
        if [ ! -f "$d/module.prop" ]; then
            ar_log WARN "清理无 module.prop 的目录: $id"
            rm -rf "$d" 2>/dev/null && { removed="$removed$id "; n=$((n+1)); }
            continue
        fi
        # 目录里除了 module.prop 什么都没有 = 空壳
        local cnt
        cnt=$(ls -1A "$d" 2>/dev/null | wc -l | tr -d ' ')
        case "$cnt" in ''|*[!0-9]*) cnt=1;; esac
        if [ "$cnt" -le 1 ]; then
            ar_log WARN "清理空壳模块: $id"
            rm -rf "$d" 2>/dev/null && { removed="$removed$id "; n=$((n+1)); }
        fi
    done
    printf '{"count":%s,"removed":"%s"}' "$n" "$(ar_json_esc "$removed")"
}

# ---------- 系统健康检查 ----------
syscheck_json() {
    local out="" f
    # 1) 关键系统可执行文件是否还在(被模块覆盖/删掉会直接起不来)
    local miss=""
    for f in /system/bin/app_process /system/bin/app_process64 \
             /system/bin/servicemanager /system/bin/surfaceflinger \
             /system/bin/linker /system/bin/linker64 /system/bin/sh \
             /system/bin/toybox /system/bin/logcat; do
        [ -e "$f" ] || miss="$miss$f "
    done

    # 2) 存储空间(/data 或 /system 写满会导致无法启动)
    local davail savail davailkb savailkb
    davailkb=$(df -k /data 2>/dev/null | awk 'NR==2{print $4}')
    case "$davailkb" in ''|*[!0-9]*) davailkb=0;; esac
    davail=$((davailkb / 1024))
    savailkb=$(df -k /system 2>/dev/null | awk 'NR==2{print $4}')
    case "$savailkb" in ''|*[!0-9]*) savailkb=0;; esac
    savail=$((savailkb / 1024))

    # 3) 损坏/空壳模块
    local broken=0
    for d in $(ls -1d "$MODULES_DIR"/*/ 2>/dev/null); do
        d="${d%/}"
        [ -f "$d/module.prop" ] || broken=$((broken+1))
    done

    # 4) SELinux
    local se; se=$(getenforce 2>/dev/null)
    [ -z "$se" ] && se="unknown"

    # 5) 模块总数与总体积
    local total=0 sizekb=0
    # 复用模块体积缓存(ar_size_*), 避免每次进防护页都对所有模块 du 递归。
    # syscheck 是进入防护页时自动调用的, 这里若直接 du 会成为第二个
    # 性能炸弹(与防护基线同类问题)。
    ar_size_cache_valid || ar_size_refresh
    for d in $(ar_module_dirs); do
        total=$((total+1))
        local s; s=$(ar_size_get "$(basename "$d")")
        case "$s" in ''|*[!0-9]*) s=0;; esac
        sizekb=$((sizekb+s))
    done

    # 6) 覆盖 /system 的模块数(越多风险越高)
    local ovr=0
    for d in $(ar_module_dirs); do
        [ -d "$d/system" ] && ovr=$((ovr+1))
    done

    printf '{"missing":"%s","data_avail_mb":%s,"system_avail_mb":%s,"broken_modules":%s,"selinux":"%s","module_total":%s,"module_size_kb":%s,"overlay_modules":%s}' \
        "$(ar_json_esc "$miss")" "$davail" "$savail" "$broken" \
        "$(ar_json_esc "$se")" "$total" "$sizekb" "$ovr"
}

ok()      { printf '{"ok":true,"data":%s}' "$1"; }
fail()    { printf '{"ok":false,"error":"%s"}' "$(ar_json_esc "$1")"; }

gprop() { getprop "$1" 2>/dev/null; }

# ---------------------------------------------------------------- 设备信息
device_json() {
    # 设备信息要跑 getprop/wm/df/getenforce 等二十多个子进程,
    # 在 KernelSU 的 WebView 里每次刷新都重算会明显卡顿。这里做 20 秒缓存。
    local _cache="$AR_STATE/devcache.json"
    local _now _mt _age=999
    _now=$(ar_ts)
    if [ -s "$_cache" ]; then
        _mt=$(ar_state_get devcache_ts); case "$_mt" in ''|*[!0-9]*) _mt=0;; esac
        _age=$(( _now - _mt ))
    fi
    if [ "$_age" -lt 20 ] && [ "$1" != "force" ]; then
        cat "$_cache" 2>/dev/null && return 0
    fi

    ar_mkdir "$AR_STATE"
    {
    local mem_total mem_avail stor batt batt_st batt_tmp scr cpu
    mem_total=$(awk '/MemTotal/{printf "%.1f", $2/1048576}' /proc/meminfo 2>/dev/null)
    mem_avail=$(awk '/MemAvailable/{printf "%.1f", $2/1048576}' /proc/meminfo 2>/dev/null)
    stor=$(df -h /data 2>/dev/null | awk 'NR==2{printf "%s / %s (%s)", $3, $2, $5}')
    batt=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null)
    batt_st=$(cat /sys/class/power_supply/battery/status 2>/dev/null)
    batt_tmp=$(cat /sys/class/power_supply/battery/temp 2>/dev/null)
    [ -n "$batt_tmp" ] && batt_tmp=$(awk -v t="$batt_tmp" 'BEGIN{printf "%.1f", t/10}')
    scr=$(wm size 2>/dev/null | tail -n1 | sed 's/.*: *//')
    cpu=$(gprop ro.board.platform)
    [ -z "$cpu" ] && cpu=$(gprop ro.hardware)
    local modver; modver=$(grep -m1 '^version=' "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2 | tr -d '\r')
    [ -z "$modver" ] && modver="$AR_VER"
    local impl; impl=$(ar_root_impl)
    local rv; rv=$(ar_root_version)
    local up; up=$(awk '{printf "%d", $1}' /proc/uptime 2>/dev/null)
    local upd; upd=$(( up / 86400 )); local uph; uph=$(( (up % 86400) / 3600 )); local upm; upm=$(( (up % 3600) / 60 ))
    local cores; cores=$(nproc 2>/dev/null)
    local langs; langs=$(gprop persist.sys.locale); [ -z "$langs" ] && langs=$(gprop ro.product.locale)
    local therm=""; for t in /sys/class/thermal/thermal_zone*/temp; do
        [ -r "$t" ] && { therm=$(awk -v x="$(cat "$t")" 'BEGIN{printf "%.1f", x/1000}'); break; }
    done

    printf '{"model":"%s","marketname":"%s","brand":"%s","manufacturer":"%s","device":"%s",' \
        "$(ar_json_esc "$(gprop ro.product.model)")" \
        "$(ar_json_esc "$(gprop ro.product.marketname)")" \
        "$(ar_json_esc "$(gprop ro.product.brand)")" \
        "$(ar_json_esc "$(gprop ro.product.manufacturer)")" \
        "$(ar_json_esc "$(gprop ro.product.device)")"
    printf '"android":"%s","sdk":"%s","rom":"%s","buildid":"%s","security_patch":"%s",' \
        "$(ar_json_esc "$(gprop ro.build.version.release)")" \
        "$(ar_json_esc "$(gprop ro.build.version.sdk)")" \
        "$(ar_json_esc "$(gprop ro.build.display.id)")" \
        "$(ar_json_esc "$(gprop ro.build.id)")" \
        "$(ar_json_esc "$(gprop ro.build.version.security_patch)")"
    printf '"kernel":"%s","arch":"%s","cpu":"%s","cores":"%s","selinux":"%s",' \
        "$(ar_json_esc "$(uname -r)")" \
        "$(ar_json_esc "$(gprop ro.product.cpu.abi)")" \
        "$(ar_json_esc "$cpu")" \
        "$(ar_json_esc "$cores")" \
        "$(ar_json_esc "$(getenforce 2>/dev/null)")"
    printf '"root":"%s","rootver":"%s","slot":"%s","bootloader":"%s","baseband":"%s",' \
        "$(ar_json_esc "$impl")" \
        "$(ar_json_esc "$rv")" \
        "$(ar_json_esc "$(gprop ro.boot.slot_suffix)")" \
        "$(ar_json_esc "$(gprop ro.bootloader)")" \
        "$(ar_json_esc "$(gprop gsm.version.baseband)")"
    printf '"mem_total":"%s","mem_avail":"%s","storage":"%s","battery":"%s","battery_status":"%s","battery_temp":"%s","thermal":"%s",' \
        "$(ar_json_esc "$mem_total")" "$(ar_json_esc "$mem_avail")" "$(ar_json_esc "$stor")" \
        "$(ar_json_esc "$batt")" "$(ar_json_esc "$batt_st")" "$(ar_json_esc "$batt_tmp")" "$(ar_json_esc "$therm")"
    printf '"screen":"%s","locale":"%s","uptime":"%s","uptime_text":"%s","time":"%s","moddir":"%s","modver":"%s"}' \
        "$(ar_json_esc "$scr")" "$(ar_json_esc "$langs")" \
        "$(ar_json_esc "$up")" "$(ar_json_esc "${upd}天${uph}小时${upm}分")" \
        "$(ar_json_esc "$(ar_now)")" "$(ar_json_esc "$MODDIR")" \
        "$(ar_json_esc "$modver")"
    } > "$_cache" 2>/dev/null
    ar_state_set devcache_ts "$_now"
    cat "$_cache" 2>/dev/null
    return 0
}

# ---------------------------------------------------------------- 救援状态
status_json() {
    local cnt thr round maxr last_r last_rt last_rs succ ls
    cnt=$(ar_boot_count); thr=$(ar_conf_get boot_threshold 3)
    round=$(ar_state_get rescue_round); case "$round" in ''|*[!0-9]*) round=0;; esac
    maxr=$(ar_conf_get max_round 3); [ "$maxr" -gt 3 ] && maxr=3
    last_r=$(ar_state_get last_rescue_round)
    last_rt=$(ar_state_get last_rescue_time)
    last_rs=$(ar_state_get last_rescue_reason)
    succ=$(ar_state_get last_success)
    ls=$(ar_state_get last_stage)
    local total=0 en=0 dis=0 q=0 d id
    for d in $(ar_module_dirs); do
        total=$((total+1))
        if [ "$(ar_module_enabled "$d")" = "1" ]; then en=$((en+1)); else dis=$((dis+1)); fi
    done
    q=$(ls -1d "$MODULES_DIR"/*.ar_quarantine 2>/dev/null | wc -l | tr -d ' ')
    local snaps; snaps=$(ls -1 "$AR_SNAP"/*.meta 2>/dev/null | wc -l | tr -d ' ')
    local hist; hist=$(wc -l < "$AR_STATE/rescue_history" 2>/dev/null | tr -d ' ')
    [ -z "$hist" ] && hist=0
    local safe=0; [ -f "$AR_STATE/safe_mode" ] && safe=1
    local notice=""; [ -f "$AR_STATE/last_notice" ] && notice=$(head -n3 "$AR_STATE/last_notice" | tail -n1)

    local health=100
    [ "$cnt" -gt 0 ] && health=$(( health - cnt * 12 ))
    [ "$round" -gt 0 ] && health=$(( health - round * 8 ))
    [ "$safe" = "1" ] && health=$(( health - 25 ))
    [ "$health" -lt 5 ] && health=5
    [ "$health" -gt 100 ] && health=100

    printf '{"boot_count":%s,"threshold":%s,"round":%s,"max_round":%s,' "$cnt" "$thr" "$round" "$maxr"
    printf '"last_round":"%s","last_time":"%s","last_reason":"%s","last_success":"%s","last_stage":"%s",' \
        "$(ar_json_esc "$last_r")" "$(ar_json_esc "$last_rt")" "$(ar_json_esc "$last_rs")" \
        "$(ar_json_esc "$succ")" "$(ar_json_esc "$ls")"
    printf '"modules_total":%s,"modules_enabled":%s,"modules_disabled":%s,"quarantined":%s,' "$total" "$en" "$dis" "$q"
    printf '"snapshots":%s,"rescue_count":%s,"safe_mode":%s,"health":%s,"notice":"%s"}' \
        "$snaps" "$hist" "$safe" "$health" "$(ar_json_esc "$notice")"
}

# ---------------------------------------------------------------- 模块列表
# 模块体积缓存
# du -sk 要递归遍历整个模块目录, 模块一多单次刷新就要几百毫秒到数秒,
# 这是"界面刷新慢"的主因。体积很少变化, 这里缓存 120 秒。
AR_SIZE_CACHE="$AR_STATE/sizecache"
AR_SIZE_TS="$AR_STATE/sizecache_ts"

ar_size_get() {
    local id="$1" hit
    [ -s "$AR_SIZE_CACHE" ] || return 1
    hit=$(grep -m1 "^$id	" "$AR_SIZE_CACHE" 2>/dev/null | cut -f2)
    [ -n "$hit" ] || return 1
    printf '%s' "$hit"
    return 0
}

ar_size_put() {
    local id="$1" sz="$2"
    grep -v "^$id	" "$AR_SIZE_CACHE" 2>/dev/null > "$AR_TMP/sc.$$" 2>/dev/null
    printf '%s\t%s\n' "$id" "$sz" >> "$AR_TMP/sc.$$" 2>/dev/null
    mv "$AR_TMP/sc.$$" "$AR_SIZE_CACHE" 2>/dev/null
}

ar_size_cache_valid() {
    local ts now
    [ -s "$AR_SIZE_CACHE" ] || return 1
    ts=$(cat "$AR_SIZE_TS" 2>/dev/null)
    case "$ts" in ''|*[!0-9]*) return 1;; esac
    now=$(ar_ts)
    [ $(( now - ts )) -lt 120 ] && return 0
    return 1
}

# 一次性算完所有模块体积并写入缓存
ar_size_refresh() {
    local d id sz
    mkdir -p "$AR_TMP" 2>/dev/null
    : > "$AR_TMP/sc_all" 2>/dev/null
    for d in $(ar_module_dirs); do
        id=$(basename "$d")
        [ -n "$id" ] || continue
        sz=$(du -sk "$d" 2>/dev/null | awk '{print $1}')
        case "$sz" in ''|*[!0-9]*) sz=0;; esac
        printf '%s\t%s\n' "$id" "$sz" >> "$AR_TMP/sc_all" 2>/dev/null
    done
    mv "$AR_TMP/sc_all" "$AR_SIZE_CACHE" 2>/dev/null
    ar_state_set sizecache_ts "$(ar_ts)"
    return 0
}

modules_json() {
    local first=1 d id name ver auth en wl desc sz mtime
    # 过期就整体重算一次, 之后本次调用全部走缓存
    ar_size_cache_valid || ar_size_refresh
    printf '['
    for d in $(ar_module_dirs); do
        id=$(basename "$d")
        name=$(ar_prop "$d" name "$id")
        ver=$(ar_prop "$d" version "?")
        auth=$(ar_prop "$d" author "?")
        desc=$(ar_prop "$d" description "")
        en=$(ar_module_enabled "$d")
        if ar_is_whitelisted "$id"; then wl=1; else wl=0; fi
        if ar_is_excluded "$id" 2>/dev/null; then ex=1; else ex=0; fi
        mtime=$(stat -c %Y "$d" 2>/dev/null); [ -z "$mtime" ] && mtime=$(stat -t "$d" 2>/dev/null | cut -d' ' -f13)
        [ -z "$mtime" ] && mtime=0
        sz=$(ar_size_get "$id")
        if [ -z "$sz" ]; then
            sz=$(du -sk "$d" 2>/dev/null | awk '{print $1}')
            case "$sz" in ''|*[!0-9]*) sz=0;; esac
            ar_size_put "$id" "$sz"
        fi
        [ "$first" = "1" ] && first=0 || printf ','
        printf '{"id":"%s","name":"%s","version":"%s","author":"%s","desc":"%s","enabled":%s,"whitelist":%s,"excluded":%s,"self":%s,"mtime":%s,"size":%s}' \
            "$(ar_json_esc "$id")" "$(ar_json_esc "$name")" "$(ar_json_esc "$ver")" "$(ar_json_esc "$auth")" \
            "$(ar_json_esc "$desc")" "$en" "$wl" "$ex" "$([ "$id" = "$AR_ID" ] && echo 1 || echo 0)" "$mtime" "$sz"
    done
    printf ']'
}

# ---------------------------------------------------------------- 配置
config_json() {
    local out="" line k v first=1
    printf '{'
    while IFS='=' read -r k v; do
        [ -z "$k" ] && continue
        case "$k" in \#*) continue;; esac
        [ "$first" = "1" ] && first=0 || printf ','
        printf '"%s":"%s"' "$(ar_json_esc "$k")" "$(ar_json_esc "$v")"
    done < "$AR_CONF"
    printf ',"_version":"%s","_author":"%s","_root":"%s"}' "$AR_VER" "$AR_AUTHOR" "$(ar_root_impl)"
}

# ---------------------------------------------------------------- 快照
snapshots_json() {
    local first=1 f id t tag cnt
    printf '['
    for f in $(ls -1t "$AR_SNAP"/*.meta 2>/dev/null); do
        id=$(ar_prop "${f%.meta}" id ""); id=$(grep -m1 '^id=' "$f" | cut -d= -f2-)
        t=$(grep -m1 '^time=' "$f" | cut -d= -f2-)
        tag=$(grep -m1 '^tag=' "$f" | cut -d= -f2-)
        cnt=$(grep -m1 '^count=' "$f" | cut -d= -f2-)
        [ "$first" = "1" ] && first=0 || printf ','
        printf '{"id":"%s","time":"%s","tag":"%s","count":%s}' \
            "$(ar_json_esc "$id")" "$(ar_json_esc "$t")" "$(ar_json_esc "$tag")" "${cnt:-0}"
    done
    printf ']'
}

# ---------------------------------------------------------------- 历史
history_json() {
    local first=1 ts rd rs act
    printf '['
    mkdir -p "$AR_STATE" 2>/dev/null
    [ -f "$AR_STATE/rescue_history" ] || : > "$AR_STATE/rescue_history" 2>/dev/null
    while IFS='|' read -r ts rd rs act; do
        [ -z "$ts" ] && continue
        [ "$first" = "1" ] && first=0 || printf ','
        printf '{"ts":%s,"time":"%s","round":%s,"reason":"%s","action":"%s"}' \
            "$ts" "$(date -d "@$ts" '+%m-%d %H:%M' 2>/dev/null || echo "$ts")" "$rd" \
            "$(ar_json_esc "$rs")" "$(ar_json_esc "$act")"
    done < "$AR_STATE/rescue_history"
    printf ']'
}

# ---------------------------------------------------------------- 日志
logs_json() {
    local n="${1:-200}"
    case "$n" in ''|*[!0-9]*) n=200;; esac
    local first=1
    printf '['
    [ -f "$AR_LOG" ] && tail -n "$n" "$AR_LOG" | while IFS= read -r line; do
        [ "$first" = "1" ] && first=0 || printf ','
        printf '"%s"' "$(ar_json_esc "$line")"
    done
    printf ']'
}

# ---------------------------------------------------------------- 冲突检测
conflict_json() {
    local tmp="$AR_TMP/conflict_paths"
    : > "$tmp" 2>/dev/null
    mkdir -p "$AR_TMP" 2>/dev/null
    local d id
    for d in $(ar_module_dirs); do
        id=$(basename "$d")
        [ "$(ar_module_enabled "$d")" = "1" ] || continue
        [ -d "$d/system" ] || continue
        find "$d/system" -type f 2>/dev/null | sed "s|^$d||" | while IFS= read -r p; do
            printf '%s\t%s\n' "$p" "$id" >> "$tmp"
        done
    done
    local dup; dup=$(cut -f1 "$tmp" 2>/dev/null | sort | uniq -d)
    local first=1
    printf '['
    [ -n "$dup" ] && printf '%s\n' "$dup" | while IFS= read -r p; do
        [ -z "$p" ] && continue
        local mods; mods=$(awk -F'\t' -v P="$p" '$1==P{printf "%s ", $2}' "$tmp" 2>/dev/null)
        [ "$first" = "1" ] && first=0 || printf ','
        printf '{"path":"%s","modules":"%s"}' "$(ar_json_esc "$p")" "$(ar_json_esc "$mods")"
    done
    printf ']'
    rm -f "$tmp" 2>/dev/null
}

# ================================================================= 脚本扫描
# do_scan <文件> <标签> [是否先尝试解密]
do_scan() {
    local f="$1" tag="$2" try="${3:-1}"
    local res="$AR_SCANDIR/f.find"
    mkdir -p "$AR_SCANDIR" 2>/dev/null
    : > "$res" 2>/dev/null
    ar_scan_file "$f" "$tag" "$res"
    # v1.2: 原文先做一次 Shell 规范化再扫(还原变量拼接 / 引号切割 / $IFS 绕过)
    local nf="$AR_SCANDIR/f.norm"
    ar_shell_normalize "$f" "$nf" 2>/dev/null
    if [ -s "$nf" ] && ! cmp -s "$f" "$nf" 2>/dev/null; then
        ar_scan_file "$nf" "$tag(规范化)" "$res"
    fi
    local score enc chain dec prev=""

    enc=$(ar_detect_enc "$f" | tr ' ' ',' | sed 's/,$//')
    chain=""
    dec=0
    # 总是尝试解密: 很多自解密封装的外壳本身就是合法 shell, 看不出加密特征
    if [ "$try" = "1" ]; then
        chain=$(ar_decode "$f" 6)
        if [ -s "$AR_SCANDIR/dec.out" ]; then
            dec=1
            ar_scan_file "$AR_SCANDIR/dec.out" "解密后" "$res"
            prev=$(head -c 6000 "$AR_SCANDIR/dec.out" 2>/dev/null)
        fi
    fi

    score=$(ar_score_of "$res")
    local lvl; lvl=$(ar_level_of "$score")

    local first=1
    printf '{"score":%s,"level":"%s","enc":"%s","chain":"%s","decrypted":%s,"findings":[' \
        "$score" "$lvl" "$(ar_json_esc "$enc")" "$(ar_json_esc "$chain")" "$dec"
    [ -s "$res" ] && while IFS='|' read -r lvl2 name desc where code; do
        [ -z "$lvl2" ] && continue
        [ "$first" = "1" ] && first=0 || printf ','
        printf '{"risk":"%s","rule":"%s","desc":"%s","where":"%s","code":"%s"}' \
            "$(ar_json_esc "$lvl2")" "$(ar_json_esc "$name")" "$(ar_json_esc "$desc")" \
            "$(ar_json_esc "$where")" "$(ar_json_esc "$code")"
    done < "$res"
    printf '],"preview":"%s","size":%s,"lines":%s}' \
        "$(ar_json_esc "$prev")" "$(stat -c %s "$f" 2>/dev/null || echo 0)" "$(wc -l < "$f" 2>/dev/null | tr -d ' ')"
}

# 扫描一个模块里的所有脚本
scan_module() {
    local id="$1"
    local d="$MODULES_DIR/$id"
    [ -d "$d" ] || { fail "模块不存在: $id"; return; }
    local all="$AR_SCANDIR/m.find"
    : > "$all" 2>/dev/null
    local f rel found=0 scripts="" e chain
    for f in $(find "$d" -maxdepth 3 -name '*.sh' 2>/dev/null | sort | head -n 40); do
        [ -f "$f" ] || continue
        rel="${f#$d/}"
        case "$scripts" in *"$rel"*) continue;; esac
        scripts="$scripts$rel "
        found=$((found+1))
        ar_scan_file "$f" "$rel" "$all"
        e=$(ar_detect_enc "$f")
        chain=$(ar_decode "$f" 4)
        [ -s "$AR_SCANDIR/dec.out" ] && ar_scan_file "$AR_SCANDIR/dec.out" "$rel(解密:$chain)" "$all"
    done
    local score; score=$(ar_score_of "$all")
    local lvl; lvl=$(ar_level_of "$score")
    local first=1
    printf '{"id":"%s","name":"%s","score":%s,"level":"%s","scripts":"%s","findings":[' \
        "$(ar_json_esc "$id")" "$(ar_json_esc "$(ar_prop "$d" name "$id")")" \
        "$score" "$lvl" "$(ar_json_esc "$scripts")"
    [ -s "$all" ] && while IFS='|' read -r l2 name desc where code; do
        [ -z "$l2" ] && continue
        [ "$first" = "1" ] && first=0 || printf ','
        printf '{"risk":"%s","rule":"%s","desc":"%s","where":"%s","code":"%s"}' \
            "$(ar_json_esc "$l2")" "$(ar_json_esc "$name")" "$(ar_json_esc "$desc")" \
            "$(ar_json_esc "$where")" "$(ar_json_esc "$code")"
    done < "$all"
    printf ']}'
}

# 一键体检: 扫描全部已启用模块
scan_all() {
    local d id out="" first=1 s lvl
    printf '['
    for d in $(ar_module_dirs); do
        id=$(basename "$d")
        [ "$id" = "$AR_ID" ] && continue          # 不体检自己(规则库本身就是危险样本)
        [ "$(ar_module_enabled "$d")" = "1" ] || continue
        [ "$first" = "1" ] && first=0 || printf ','
        # 轻量评分: 只算分数与等级, 明细按需查看
        local all="$AR_SCANDIR/a.find"
        : > "$all" 2>/dev/null
        local f
        for f in $(find "$d" -maxdepth 3 -name '*.sh' 2>/dev/null | head -n 20); do
            ar_scan_file "$f" "$(basename "$f")" "$all"
        done
        s=$(ar_score_of "$all")
        lvl=$(ar_level_of "$s")
        printf '{"id":"%s","name":"%s","score":%s,"level":"%s","hits":%s}' \
            "$(ar_json_esc "$id")" "$(ar_json_esc "$(ar_prop "$d" name "$id")")" \
            "$s" "$lvl" "$(wc -l < "$all" | tr -d ' ')"
    done
    printf ']'
}

# ---------------------------------------------------------------- 全量状态
full_status() {
    printf '{"device":%s,"status":%s,"config":%s,"modules":%s,"snapshots":%s,"history":%s}' \
        "$(device_json)" "$(status_json)" "$(config_json)" "$(modules_json)" "$(snapshots_json)" "$(history_json)"
}

# ---------------------------------------------------------------- 诊断报告
diag_report() {
    local f="$AR_DATA/diag_report.txt"
    {
        printf '========== AutoRescue 诊断报告 ==========\n'
        printf '生成时间: %s\n' "$(ar_now)"
        printf '模块版本: %s  作者: %s\n' "$AR_VER" "$AR_AUTHOR"
        printf '\n----- 设备 -----\n'
        printf '机型: %s %s (%s)\n' "$(gprop ro.product.brand)" "$(gprop ro.product.model)" "$(gprop ro.product.device)"
        printf 'Android: %s (SDK %s)\n' "$(gprop ro.build.version.release)" "$(gprop ro.build.version.sdk)"
        printf 'ROM: %s\n' "$(gprop ro.build.display.id)"
        printf '内核: %s\n' "$(uname -a)"
        printf 'Root: %s %s\n' "$(ar_root_impl)" "$(ar_root_version)"
        printf 'SELinux: %s   架构: %s\n' "$(getenforce 2>/dev/null)" "$(gprop ro.product.cpu.abi)"
        printf '\n----- 模块状态 -----\n'
        local d id
        for d in $(ar_module_dirs); do
            id=$(basename "$d")
            printf '  [%s]%s %s  (%s)\n' \
                "$([ "$(ar_module_enabled "$d")" = "1" ] && echo ● || echo ○)" \
                "$(ar_is_whitelisted "$id" && echo "[白]" || echo "   ")" \
                "$(ar_prop "$d" name "$id")" "$id"
        done
        printf '\n----- 救援状态 -----\n'
        printf '启动计数: %s / 阈值 %s   救援等级: %s\n' "$(ar_boot_count)" "$(ar_conf_get boot_threshold 3)" "$(ar_state_get rescue_round)"
        printf '上次救援: %s  %s\n' "$(ar_state_get last_rescue_time)" "$(ar_state_get last_rescue_reason)"
        printf '上次成功: %s\n' "$(ar_state_get last_success)"
        printf '\n----- 救援历史 -----\n'
        cat "$AR_STATE/rescue_history" 2>/dev/null || echo "(无)"
        printf '\n----- 配置 -----\n'
        cat "$AR_CONF" 2>/dev/null
        printf '\n----- 最近日志 -----\n'
        tail -n 100 "$AR_LOG" 2>/dev/null
        printf '\n========== 报告结束 ==========\n'
    } > "$f" 2>/dev/null
    chmod 0644 "$f" 2>/dev/null
    printf '{"path":"%s","size":%s}' "$(ar_json_esc "$f")" "$(stat -c %s "$f" 2>/dev/null || echo 0)"
}

# ---------------------------------------------------------------- 队列(备用执行通道)
queue_add() {
    local cmd="$1"
    mkdir -p "$AR_QUEUE" 2>/dev/null
    printf '%s\n' "$cmd" >> "$AR_QUEUE/pending.sh" 2>/dev/null
    printf '{"queued":true}'
}

queue_result() { printf '{"result":"%s"}' "$(ar_json_esc "$(tail -n 40 "$AR_QUEUE/last_result" 2>/dev/null)")"; }

# ================================================================= 路由
# 支持两种调用方式:
#   1) sh api.sh <action> [参数...]                (命令行 / ksu.exec)
#   2) sh api.sh --file <文件>                     (CGI, 第一行=action, 其余=参数)
if [ "${1:-}" = "--file" ] && [ -f "${2:-}" ]; then
    _F="$2"
    ACTION=$(head -n1 "$_F" 2>/dev/null)
    tail -n +2 "$_F" > "$_F.args" 2>/dev/null
    set --
    # 注意: 最后一行可能没有换行符, read 会返回非 0 但仍需采纳该行
    while IFS= read -r _l || [ -n "$_l" ]; do set -- "$@" "$_l"; done < "$_F.args"
    rm -f "$_F.args" 2>/dev/null
else
    ACTION="${1:-status}"
    shift 2>/dev/null || true
fi
ar_init_dirs
ar_conf_defaults

case "$ACTION" in
    status)   ok "$(full_status)";;
    device)   ok "$(device_json)";;
    rstatus)  ok "$(status_json)";;
    config)   ok "$(config_json)";;
    modules)  ok "$(modules_json)";;
    snapshots) ok "$(snapshots_json)";;
    history)  ok "$(history_json)";;
    logs)     ok "$(logs_json "${1:-200}")";;
    clearlog) : > "$AR_LOG"; ar_log INFO "日志已被用户清空"; ok '{"cleared":true}';;
    conflict) ok "$(conflict_json)";;
    audit)    ok "\"$(ar_json_esc "$(ar_audit_modules)")\"";;
    diag)     ok "$(diag_report)";;

    setconf)
        [ -z "$1" ] && { fail "缺少参数"; exit 0; }
        for kv in "$@"; do
            k="${kv%%=*}"; v="${kv#*=}"
            case "$k" in
                boot_threshold|confirm_delay|boot_timeout|max_round)
                    case "$v" in ''|*[!0-9]*) continue;; esac
                    # 等级已精简为 3 级, 上限同步收紧
                    [ "$k" = "max_round" ] && { [ "$v" -gt 3 ] && v=3; [ "$v" -lt 1 ] && v=1; };;
            esac
            ar_conf_set "$k" "$v"
        done
        ar_log INFO "配置已更新: $*"
        ok '{"saved":true}';;

    toggle)
        id="$1"; want="${2:-1}"
        d="$MODULES_DIR/$id"
        [ -d "$d" ] || { fail "模块不存在: $id"; exit 0; }
        if [ "$want" = "1" ]; then
            # 清理残留的空标记文件(非空说明是隔离出来的目录, 交给下面 mv 还原)
            [ -s "$d.ar_quarantine" ] || rm -f "$d.ar_quarantine" 2>/dev/null
            if [ -d "$d.ar_quarantine" ] && [ ! -d "$d" ]; then mv "$d.ar_quarantine" "$d" 2>/dev/null; fi
            ar_enable_module "$d"
        else
            ar_disable_module "$d"
        fi
        ar_log INFO "WebUI 操作: $([ "$want" = "1" ] && echo 启用 || echo 禁用) $id"
        ok '{"done":true}'
        ;;

    whitelist)
        id="$1"; op="${2:-add}"
        mkdir -p "$AR_DATA" 2>/dev/null
        [ -f "$AR_DATA/whitelist" ] || : > "$AR_DATA/whitelist"
        if [ "$op" = "add" ]; then
            grep -qx "$id" "$AR_DATA/whitelist" 2>/dev/null || echo "$id" >> "$AR_DATA/whitelist"
        else
            grep -vx "$id" "$AR_DATA/whitelist" > "$AR_DATA/whitelist.tmp" 2>/dev/null \
                && mv "$AR_DATA/whitelist.tmp" "$AR_DATA/whitelist"
        fi
        ar_log INFO "白名单 $op: $id"
        ok '{"done":true}';;

    rescue)
        lv="${1:-}"; reason="${2:-WebUI 手动救援}"
        ar_rescue_now "$lv" "$reason"
        ok "{\"done\":true,\"level\":\"$(ar_state_get rescue_round)\"}";;

    confirm)
        ar_confirm_success
        ok '{"done":true}';;

    snapshot)
        op="${1:-list}"; sid="${2:-}"
        case "$op" in
            create) id=$(ar_snapshot_create "${sid:-manual}"); ok "{\"id\":\"$id\"}";;
            list)   ok "$(snapshots_json)";;
            rollback) ar_snapshot_rollback "$sid" && ok '{"done":true}' || fail "快照不存在";;
            delete) rm -f "$AR_SNAP/$sid.meta" "$AR_SNAP/$sid.list" 2>/dev/null; ok '{"done":true}';;
            clear)  rm -f "$AR_SNAP"/* 2>/dev/null; ok '{"done":true}';;
            restore_all) ar_restore_quarantine; ok '{"done":true}';;
            *) fail "未知操作";;
        esac;;

    enableall)
        for d in $(ar_module_dirs); do ar_enable_module "$d"; done
        ar_restore_quarantine
        ar_log INFO "WebUI: 已启用全部模块"
        ok '{"done":true}';;

    disableall)
        keep_wl="${1:-1}"
        for d in $(ar_module_dirs); do
            id=$(basename "$d")
            [ "$id" = "$AR_ID" ] && continue
            if [ "$keep_wl" = "1" ] && ar_is_whitelisted "$id"; then continue; fi
            ar_disable_module "$d"
        done
        ar_log INFO "WebUI: 已批量禁用模块 (保留白名单=$keep_wl)"
        ok '{"done":true}';;

    force_rescue_file)
        : > "$AR_DATA/force_rescue" 2>/dev/null
        ar_log WARN "已创建 force_rescue 标记, 下次启动将强制执行救援"
        ok '{"done":true}';;

    clear_state)
        : > "$AR_STATE/boot_count" 2>/dev/null
        echo 0 > "$AR_STATE/boot_count" 2>/dev/null
        echo 0 > "$AR_STATE/rescue_round" 2>/dev/null
        rm -f "$AR_STATE/safe_mode" "$AR_DATA/force_rescue" 2>/dev/null
        ar_log INFO "状态已重置"
        ok '{"done":true}';;

    exec)
        shift 0
        cmd="${1:-}"
        [ -z "$cmd" ] && { fail "空命令"; exit 0; }
        [ "$(ar_conf_get allow_terminal 1)" != "1" ] && { fail "终端功能已关闭 (设置中开启)"; exit 0; }
        out=$(sh -c "$cmd" 2>&1 | tail -c 8000)
        ar_log INFO "WebUI 终端执行: $cmd"
        ok "{\"stdout\":\"$(ar_json_esc "$out")\"}";;

    reboot)
        tgt="${1:-}"
        ar_log WARN "WebUI 请求重启: ${tgt:-normal}"
        ok '{"done":true}'
        case "$tgt" in
            recovery) setprop sys.powerctl reboot,recovery 2>/dev/null; /system/bin/reboot recovery 2>/dev/null;;
            bootloader|fastboot) setprop sys.powerctl reboot,bootloader 2>/dev/null; /system/bin/reboot bootloader 2>/dev/null;;
            edl) /system/bin/reboot edl 2>/dev/null;;
            softrestart) setprop sys.powerctl restart 2>/dev/null; /system/bin/reboot 2>/dev/null;;
            *) ar_reboot "webui";;
        esac;;

    guardstatus)
        ok "$(ar_guard_status_json)";;
    guardevents)
        ok "$(ar_guard_events_json)";;
    guardbase)
        ar_guard_baseline
        ar_log INFO "WebUI 重建守护基线"
        ok '{"done":true}';;
    guardcheck)
        n=$(ar_guard_check)
        ok "{\"events\":${n:-0}}";;
    guardpaths)
        op="${1:-list}"; p="${2:-}"
        case "$op" in
            list) ok "$(ar_guard_status_json)";;
            add)  ar_guard_add "$p" && ok '{"done":true}' || fail "添加失败";;
            del)  ar_guard_del "$p" && ok '{"done":true}' || fail "删除失败";;
            *) fail "未知操作";;
        esac;;
    guardbackup)
        op="${1:-list}"; bid="${2:-}"
        case "$op" in
            create) id=$(ar_guard_backup "${bid:-manual}"); ok "{\"id\":\"$id\"}";;
            list)   ok "$(ar_guard_backups_json)";;
            restore) ar_guard_restore "$bid" && ok '{"done":true}' || fail "备份不存在";;
            *) fail "未知操作";;
        esac;;
    guardharden)
        n=$(ar_guard_harden)
        ok "{\"hardened\":${n:-0}}";;
    guardclearev)
        : > "$AR_GUARD_EVENTS" 2>/dev/null
        ok '{"done":true}';;

    # ---------------- v1.1 新增: 脚本检测 ----------------
    scanmod)
        [ -z "$1" ] && { fail "缺少模块 ID"; exit 0; }
        ok "$(scan_module "$1")";;

    scanfile)
        [ -z "$1" ] && { fail "缺少路径"; exit 0; }
        [ -f "$1" ] || { fail "文件不存在或不可读: $1"; exit 0; }
        ok "$(do_scan "$1" "$(basename "$1")" 1)";;

    scanpaste)
        [ -z "$1" ] && { fail "缺少内容"; exit 0; }
        mkdir -p "$AR_SCANDIR" 2>/dev/null
        pf="$AR_SCANDIR/paste_$$.sh"
        if [ -n "$BB" ] && $BB base64 -d </dev/null >/dev/null 2>&1; then
            printf '%s' "$1" | $BB base64 -d > "$pf" 2>/dev/null
        else
            printf '%s' "$1" | base64 -d > "$pf" 2>/dev/null
        fi
        [ -s "$pf" ] || { rm -f "$pf"; fail "内容解码失败"; exit 0; }
        r=$(do_scan "$pf" "粘贴内容" 1)
        rm -f "$pf" 2>/dev/null
        ok "$r";;

    scanall)
        ok "$(scan_all)";;

    # ---------------- v1.1 新增: 系统防护 ----------------

    # ---------------- v1.1 新增: 增强救砖 ----------------
    safemode)
        # 一键安全模式: 禁用全部模块 + 隔离, 保留守护自身
        : > "$AR_STATE/safe_mode" 2>/dev/null
        for d in $(ar_module_dirs); do
            id=$(basename "$d")
            [ "$id" = "$AR_ID" ] && continue
            ar_quarantine_module "$d"
        done
        ar_log WARN "已进入安全模式: 全部模块已隔离"
        ar_state_set rescue_round 5
        ok '{"done":true}';;

    golden)
        op="${1:-list}"
        case "$op" in
            set)
                id=$(ar_snapshot_create "golden_$(ar_ts)")
                ar_state_set golden "$id"
                ar_log INFO "已设置黄金快照: $id"
                ok "{\"id\":\"$id\"}";;
            get)
                ok "\"$(ar_json_esc "$(ar_state_get golden)")\"";;
            restore)
                g=$(ar_state_get golden)
                [ -n "$g" ] && ar_snapshot_rollback "$g" && ok '{"done":true}' || fail "暂无黄金快照";;
            *) fail "未知操作";;
        esac;;

    queue)
        queue_add "${1:-}";;
    queueresult)
        queue_result;;

    webui_start)
        sh "$MODDIR/action.sh" --silent >/dev/null 2>&1
        ok "{\"port\":\"$(ar_state_get webui_port)\"}";;

    # ---------------- v1.6 新增 ----------------
    # 救援演练: 只计算"如果现在触发各等级救援, 会禁用哪些模块", 不做任何改动
    dryrun)
        ok "$(dryrun_json)";;

    # 导出诊断包: 设备信息 + 模块列表 + 救援历史 + 最近日志
    export)
        ok "$(export_bundle)";;

    # 清理: 日志 + 超出保留数的旧快照
    cleanup)
        ok "$(do_cleanup)";;

    # 查看模块内的文件列表
    modfiles)
        ok "$(modfiles_json "${1:-}")";;

    # 读取模块内某个脚本的内容(只读, 用于排查)
    modfile)
        ok "$(modfile_json "${1:-}" "${2:-}")";;

    # ---------------- v1.7 新增 ----------------
    # 排除名单(永不禁用, 强于白名单)
    exclude)
        case "${1:-}" in
            add) ar_exclude_add "${2:-}" && ok '{"done":true}' || fail "添加失败";;
            del) ar_exclude_del "${2:-}" && ok '{"done":true}' || fail "移除失败";;
            list) ok "$(ar_exclude_list_json)";;
            *) fail "用法: exclude add|del|list";;
        esac;;

    # 模块备份(复制目录到备份区)
    backup)
        case "${1:-}" in
            create) ok "$(do_backup "${2:-}" "${3:-}")";;
            list)   ok "$(backup_list_json)";;
            restore) ok "$(do_backup_restore "${2:-}")";;
            del)    rm -rf "$AR_BACKUP/${2:-}" 2>/dev/null; ok '{"done":true}';;
            *) fail "用法: backup create|list|restore|del";;
        esac;;

    # 清空救援历史
    clearhist)
        : > "$AR_DATA/history.log" 2>/dev/null
        ar_log INFO "救援历史已清空"
        ok '{"done":true}';;

    # ---------------- v1.8 新增 ----------------
    stagerescue)
        ok "$(ar_stage_rescue "${1:-auto}")";;
    fixperm)
        ok "$(ar_fix_perm)";;
    fixcontext)
        ok "$(ar_fix_context)";;
    cleanbroken)
        ok "$(ar_clean_broken)";;
    syscheck)
        ok "$(syscheck_json)";;

    version)
        ok "{\"version\":\"$AR_VER\",\"author\":\"$AR_AUTHOR\",\"id\":\"$AR_ID\"}";;

    *) fail "未知指令: $ACTION";;
esac
exit 0
