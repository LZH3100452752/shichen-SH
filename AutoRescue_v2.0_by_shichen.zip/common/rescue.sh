#!/system/bin/sh
# =====================================================================
#  AutoRescue · 分级救砖引擎
#  作者: 时尘  v2.0
# =====================================================================

. "${MODDIR:-/data/adb/modules/auto_rescue}/common/functions.sh" 2>/dev/null || exit 0

# ---------------------------------------------------------------
#  救援等级说明
#  L1 精准点杀 : 禁用最近安装的 1 个非白名单模块
#  L2 扩大范围 : 禁用最近安装的 3 个非白名单模块
#  L3 常规清场 : 禁用全部非白名单模块(保留白名单 + 自身)
#  L2 深度清场 : 禁用全部模块(含白名单), 仅保留守护自身
#  L3 终极隔离 : 重命名全部模块目录, 彻底移除挂载
# ---------------------------------------------------------------

# 等级精简为 3 级(旧的 L3/L4/L5 依次成为新的 L1/L2/L3)
ar_rescue_title() {
    case "$1" in
        1) echo "L1 常规清场 (禁用全部非白名单模块)";;
        2) echo "L2 深度清场 (禁用全部模块, 只留守护自身)";;
        *) echo "L3 终极隔离 (移除全部模块挂载)";;
    esac
}

# 记录救援历史
ar_rescue_history() {
    local round="$1" reason="$2" act="$3"
    mkdir -p "$AR_STATE" 2>/dev/null
    printf '%s|%s|%s|%s\n' "$(ar_ts)" "$round" "$(ar_json_esc "$reason")" "$(ar_json_esc "$act")" \
        >> "$AR_STATE/rescue_history" 2>/dev/null
    tail -n 200 "$AR_STATE/rescue_history" > "$AR_STATE/rescue_history.tmp" 2>/dev/null \
        && mv "$AR_STATE/rescue_history.tmp" "$AR_STATE/rescue_history"
}

# 按"最近安装"顺序取待处理模块(排除白名单/自身)
ar_recent_modules() {
    local limit="$1" n=0 d id
    for d in $(ar_module_dirs); do
        id=$(basename "$d")
        ar_is_whitelisted "$id" && continue
        [ "$(ar_module_enabled "$d")" = "1" ] || continue
        printf '%s\n' "$d"
        n=$((n+1))
        [ "$n" -ge "$limit" ] && break
    done
}

# ---------------------------------------------------------------
#  主救援函数
#  ar_do_rescue <round> <reason>
# ---------------------------------------------------------------
ar_do_rescue() {
    local round="$1" reason="${2:-bootloop}"
    local maxr
    maxr=$(ar_conf_get max_round 3)
    case "$maxr" in ''|*[!0-9]*) maxr=3;; esac
    [ "$maxr" -gt 3 ] && maxr=3
    [ "$maxr" -lt 1 ] && maxr=1
    case "$round" in ''|*[!0-9]*) round=1;; esac
    [ "$round" -gt "$maxr" ] && round="$maxr"
    [ "$round" -lt 1 ] && round=1

    ar_init_dirs
    # 把钳制后的等级写回状态: 否则传入 9 时状态里就会留着 9,
    # 下次自增变成 10, UI 会显示 "L10 / L3" 这种对不上的进度
    ar_state_set rescue_round "$round"
    ar_log ERROR "!!!! 触发自动救砖 !!!! 等级=L$round 原因=$reason"

    if [ "$(ar_conf_get auto_snapshot 1)" = "1" ]; then
        ar_snapshot_create "auto_before_L$round" >/dev/null 2>&1
    fi

    local acted=0 detail="" n=0 d id name

    case "$round" in
        1)
            # 原 L3: 禁用全部非白名单/非锁定的启用模块
            for d in $(ar_module_dirs); do
                id=$(basename "$d")
                if ar_is_whitelisted "$id"; then
                    ar_log INFO "白名单保护, 跳过: $id"; continue
                fi
                if ar_is_excluded "$id" 2>/dev/null; then
                    ar_log INFO "已锁定, 跳过: $id"; continue
                fi
                [ "$(ar_module_enabled "$d")" = "1" ] || continue
                name=$(ar_prop "$d" name "$id")
                ar_disable_module "$d" && { acted=1; n=$((n+1)); detail="$detail$name "; }
            done
            ;;
        2)
            # 原 L4: 含白名单一起禁用, 只留守护自身
            for d in $(ar_module_dirs); do
                id=$(basename "$d")
                if [ "$id" = "$AR_ID" ] && [ "$(ar_conf_get protect_self 1)" = "1" ]; then
                    continue
                fi
                if ar_is_excluded "$id" 2>/dev/null; then
                    ar_log INFO "已锁定, 跳过: $id"; continue
                fi
                name=$(ar_prop "$d" name "$id")
                ar_disable_module "$d" && { acted=1; n=$((n+1)); detail="$detail$name "; }
            done
            ;;
        *)
            # 原 L5: 彻底移除挂载(重命名模块目录)
            for d in $(ar_module_dirs); do
                id=$(basename "$d")
                if [ "$id" = "$AR_ID" ] && [ "$(ar_conf_get protect_self 1)" = "1" ]; then
                    continue
                fi
                if ar_is_excluded "$id" 2>/dev/null; then
                    ar_log INFO "已锁定, 跳过: $id"; continue
                fi
                ar_quarantine_module "$d" && { acted=1; n=$((n+1)); detail="$detail$id "; }
            done
            ar_state_set safe_mode 1
            ;;
    esac

    local title msg
    title=$(ar_rescue_title "$round")
    msg="$title -> 处理 ${n} 个模块 [${detail:-无}] ; 原因: $reason"
    ar_log WARN "救援完成: $msg"
    ar_rescue_history "$round" "$reason" "$title 处理${n}个模块: ${detail:-无}"
    ar_state_set last_rescue_round "$round"
    ar_state_set last_rescue_time "$(ar_now)"
    ar_state_set last_rescue_reason "$reason"
    ar_write_notice "$msg"

    [ "$acted" = "1" ] && return 0
    ar_log WARN "没有可处理的模块(可能已全部禁用), 未做改动"
    return 1
}

# ---------------------------------------------------------------
#  手动/紧急救援入口
# ---------------------------------------------------------------
ar_rescue_now() {
    local lv="$1" reason="${2:-手动触发}" r
    if [ -z "$lv" ]; then
        r=$(ar_state_get rescue_round); case "$r" in ''|*[!0-9]*) r=0;; esac
        lv=$((r+1))
    fi
    ar_state_set rescue_round "$lv"
    ar_do_rescue "$lv" "$reason"
}

# ---------------------------------------------------------------
#  成功确认: 清零计数 / 保存"可用配置"快照
# ---------------------------------------------------------------
ar_confirm_success() {
    ar_init_dirs
    ar_state_set boot_count 0
    ar_state_set rescue_round 0
    ar_state_set last_success "$(ar_now)"
    ar_state_set last_success_ts "$(ar_ts)"
    ar_state_set circuit ""
    rm -f "$AR_STATE/safe_mode" 2>/dev/null
    if [ "$(ar_conf_get auto_snapshot 1)" = "1" ]; then
        gid=$(ar_snapshot_create "ok_$(ar_ts)")
        ar_state_set golden "$gid"
    fi
    ar_log INFO "启动稳定确认成功, 计数已清零, 已更新黄金快照"
    return 0
}

# ---------------------------------------------------------------
#  熔断保护: 防止"救援 -> 重启 -> 再失败"演变成无限重启
#  返回 0 = 允许重启 ; 1 = 熔断生效, 停止重启
# ---------------------------------------------------------------
ar_circuit_breaker() {
    local maxr circ r
    maxr=$(ar_conf_get max_round 3); case "$maxr" in ''|*[!0-9]*) maxr=3;; esac
    [ "$maxr" -gt 3 ] && maxr=3
    r=$(ar_state_get rescue_round); case "$r" in ''|*[!0-9]*) r=0;; esac
    circ=$(ar_state_get circuit)
    if [ "$r" -gt "$maxr" ]; then
        if [ "$circ" = "1" ]; then
            ar_log ERROR "熔断生效: 已达最大救援等级且重启后仍失败, 停止自动重启以避免无限开机循环"
            ar_write_notice "已触发熔断保护: 多次救援仍无法正常启动, 已停止自动重启以免无限循环。请进入 Recovery 手动处理, 或执行: sh /data/adb/modules/auto_rescue/tools/rescue.sh"
            return 1
        fi
        ar_state_set circuit 1
        ar_log WARN "已达最大救援等级, 允许最后一次重启 (熔断待生效)"
    fi
    return 0
}

# ---------------------------------------------------------------
#  危险自检: 发现高风险模块特征时给出提示(不会自动处理)
# ---------------------------------------------------------------
ar_audit_modules() {
    local out="" d id
    for d in $(ar_module_dirs); do
        id=$(basename "$d")
        [ "$(ar_module_enabled "$d")" = "1" ] || continue
        if [ -f "$d/service.sh" ] && grep -qE 'while[[:space:]]+(true|:)' "$d/service.sh" 2>/dev/null; then
            out="${out}${id}:存在前台死循环风险;"
        fi
        if [ -e "$d/system/bin/app_process" ] || [ -e "$d/system/bin/app_process64" ]; then
            out="${out}${id}:劫持zygote;"
        fi
        if [ -e "$d/system/framework/framework.jar" ] || [ -e "$d/system/framework/services.jar" ]; then
            out="${out}${id}:替换系统框架;"
        fi
        if [ -f "$d/uninstall.sh" ] && grep -q 'rm -rf /data/adb/modules' "$d/uninstall.sh" 2>/dev/null; then
            out="${out}${id}:危险卸载脚本;"
        fi
    done
    printf '%s' "$out"
}
