#!/system/bin/sh
# =====================================================================
#  AutoRescue · 脚本安全检测 / 基础解密引擎
#  功能: 危险代码识别(格机/删系统/写分区/炸机/死循环...) +
#        加密脚本识别 + 基础解码(base64/gzip/xz/bzip2/hex/rot13/倒序)
#  注意: 规则用 ~ 分隔 —— 正则里含 | , 不能用 | 当分隔符
#  作者: 时尘  v2.0
# =====================================================================

. "${MODDIR:-/data/adb/modules/auto_rescue}/common/functions.sh" 2>/dev/null || exit 0

AR_SCANDIR="$AR_TMP/scan"
mkdir -p "$AR_SCANDIR" 2>/dev/null

# ---------------------------------------------------------------- 危险规则库
# 格式: 等级~规则名~正则~说明
AR_RULES='
critical~整机格式化删除~rm[[:space:]]+(-[a-zA-Z]*[[:space:]]+)*(/|/\*|\.)[[:space:]]*(;|&|$|[[:space:]])~删除根目录或通配删除, 会清空整机
critical~递归删除 system~rm[[:space:]]+[^#]*[[:space:]]/system~递归删除 /system, 系统直接报废
critical~递归删除 data~rm[[:space:]]+[^#]*[[:space:]]/data~递归删除 /data, 数据全丢
critical~递归删除其它分区~rm[[:space:]]+[^#]*[[:space:]]/(vendor|product|odm|system_ext|cache|metadata)~递归删除关键分区
critical~清空模块目录~rm[[:space:]]+[^#]*[[:space:]]/data/adb/modules~一次性删除全部模块
critical~删除 root 数据~rm[[:space:]]+[^#]*[[:space:]]/data/adb~删除 root 数据目录
critical~通配递归删除~rm[[:space:]]+[^#]*[[:space:]](\*|\.\*|/\*|\./\*)~通配符递归删除, 极易误伤
critical~写入块设备~dd[[:space:]]+[^#]*of=/dev/block~写分区/引导, 会破坏分区表
critical~写入磁盘设备~dd[[:space:]]+[^#]*of=/dev/(sd|mmcblk)~写物理磁盘, 数据不可恢复
critical~格式化/擦除分区~mkfs\.|make_f2fs|fastboot[[:space:]]+(erase|format)|flash_erase~格式化或擦除分区
critical~清零分区~(/dev/zero|/dev/urandom)[^#]*>[[:space:]]*/dev/(block|sd|mmcblk)~向分区写零/随机数
high~Fork 炸弹~:\(\)[[:space:]]*\{[^}]*:[[:space:]]*\|[^}]*&~经典 fork 炸弹, 瞬间拖死系统
high~循环重启~while[[:space:]]+(true|1|:)[^#]*(reboot|sys\.powerctl)~循环重启, 会形成无限重启
high~开机阶段重启~(post-fs-data|service\.sh)[^#]*(reboot|sys\.powerctl)~在早期阶段重启, 极易卡开机
high~杀死核心进程~kill(-9|all)?[[:space:]]+[^#]*(zygote|system_server|surfaceflinger)~杀核心进程会导致桌面崩溃循环
high~删除系统关键文件~rm[[:space:]]+[^#]*(/system/bin|/system/lib|/system/framework)~删除系统关键文件会导致无法开机
high~篡改系统权限~chmod[[:space:]]+(000|a-rw)[[:space:]]+[^#]*(/system|/data|/vendor)~去掉权限会导致系统不可用
high~移动系统目录~mv[[:space:]]+[^#]*[[:space:]]/system~移动系统目录, 风险极高
high~删除本守护模块~rm[[:space:]]+[^#]*auto_rescue~试图删除本守护模块
medium~前台死循环~while[[:space:]]+(true|:)[[:space:]]*;~未脱离前台的死循环, 会卡死开机
medium~劫持 zygote~app_process~替换 zygote, 一旦出错必然不开机
medium~替换系统框架~framework/(framework|services)\.jar~替换系统框架, 风险较高
medium~直接操作块设备~/dev/block/~直接操作块设备
medium~关闭 SELinux~setenforce[[:space:]]+0~关闭 SELinux, 降低安全性
medium~清理系统缓存~rm[[:space:]]+[^#]*(/cache|/data/log)~清理系统缓存目录
low~eval 动态执行~eval[[:space:]]~动态执行代码, 行为不可预测
low~下载即执行~(curl|wget)[^#]*\|[[:space:]]*(sh|bash)~下载即执行, 有被投毒风险
low~写入设备文件~>[[:space:]]*/dev/~写入设备文件
low~无延时循环~for[[:space:]]+[^#]*;[[:space:]]*do[[:space:]]*$~缺少 sleep 的循环可能耗尽 CPU
'

# ---------------------------------------------------------------- 加密特征库
# 格式: 类型~正则
AR_ENC_RULES='
base64~base64[[:space:]]+-d
base64~base64[[:space:]]+-D
gzip~gzip[[:space:]]+-dc
gzip~gunzip
xz~xz[[:space:]]+-dc
bzip2~bzip2[[:space:]]+-dc
openssl~openssl[[:space:]]+enc
rot13~N-ZA-Mn-za-m
reverse~[[:space:]]rev[[:space:]]
hex~printf[^#]*\\x
hex~xxd[[:space:]]+-r
uuencode~uudecode
selfdecrypt~_SC_|时尘加密|算法链|运行时引擎|自解密|self[-_ ]?decrypt
'

# ---------------------------------------------------------------- 扫描单个文件
# ar_scan_file <文件> <标签> <结果收集文件>
ar_scan_file() {
    local f="$1" tag="$2" out="$3"
    [ -f "$f" ] && [ -r "$f" ] || return 0
    local lvl name re desc line code
    printf '%s\n' "$AR_RULES" | while IFS='~' read -r lvl name re desc; do
        [ -n "$lvl" ] || continue
        [ -n "$re" ] || continue
        case "$lvl" in ''|'#'*) continue;; esac
        grep -nE "$re" "$f" 2>/dev/null | head -n 4 | while IFS=: read -r line code; do
            [ -n "$line" ] || continue
            printf '%s|%s|%s|%s:%s|%s\n' "$lvl" "$name" "$desc" "$tag" "$line" \
                "$(printf '%s' "$code" | cut -c1-140)" >> "$out"
        done
    done
    return 0
}

# ---------------------------------------------------------------- 加密识别
ar_detect_enc() {
    local f="$1"
    [ -f "$f" ] || return 0
    local kind re
    printf '%s\n' "$AR_ENC_RULES" | while IFS='~' read -r kind re; do
        [ -n "$kind" ] || continue
        [ -n "$re" ] || continue
        grep -qE "$re" "$f" 2>/dev/null && printf '%s ' "$kind"
    done
    # 大段 base64 特征
    grep -qE '^[A-Za-z0-9+/]{80,}={0,2}$' "$f" 2>/dev/null && printf 'blob-base64 '
    # 二进制魔数
    local magic
    magic=$(head -c 4 "$f" 2>/dev/null | od -An -tx1 2>/dev/null | tr -d ' \n')
    case "$magic" in
        1f8b*)   printf 'gzip-magic ';;
        fd377a585a*) printf 'xz-magic ';;
        425a68*) printf 'bzip2-magic ';;
        789c*|7801*|78da*) printf 'zlib-magic ';;
    esac
    return 0
}

# ---------------------------------------------------------------- 判据函数
# 是否"像脚本"
ar_looks_script() {
    head -c 4000 "$1" 2>/dev/null | grep -qE '#!|echo|mount|MODDIR|then|for |while |function|/system|/data|bin/sh'
}

# 脚本特征打分: 命中常见 shell 关键词的次数(用于判断混淆方向)
# 注意: #!/ 这类符号不参与 rot13, 不能只靠它判断, 需对比解码前后的分数变化
ar_script_score() {
    local n
    n=$(head -c 4000 "$1" 2>/dev/null \
        | grep -oE '#!|echo|mount|MODDIR|then|fi|done|function|/system|/data|bin/sh|#!/|rm |dd |chmod' 2>/dev/null \
        | wc -l | tr -d ' ')
    printf '%s' "${n:-0}"
}

# 是否为压缩流魔数
ar_has_magic() {
    local m
    m=$(head -c 4 "$1" 2>/dev/null | od -An -tx1 2>/dev/null | tr -d ' \n')
    case "$m" in
        1f8b*|fd377a585a*|425a68*|789c*|7801*|78da*) return 0;;
        *) return 1;;
    esac
}

# ---------------------------------------------------------------- 载荷提取
# 从文件里抽出"疑似编码数据块":
#   A) 连续多行纯 base64(自解密脚本里最常见的 payload 形态)
#   B) 行内被引号/非编码字符包裹的长串
#   C) v1.2 增强: 同时产出 url-safe 变体与补齐 padding 的变体
# 注意: mawk / busybox awk 不支持 {n,m} 区间表达式, 一律用 length() 判断。
# 输出: 在 $od 下生成 cand.NN 文件
ar_extract_payloads() {
    local f="$1" od="$2" pfx="${3:-}"
    mkdir -p "$od" 2>/dev/null
    [ -f "$f" ] || return 0
    awk '
    BEGIN{ blk=""; n=0 }
    {
        line=$0
        gsub(/^[ \t]+/,"",line); gsub(/[ \t]+$/,"",line)
        # A) 整行都是 base64(标准或 url-safe) -> 累积成块
        if (length(line) >= 16 && line ~ /^[A-Za-z0-9+\/_-]+=*$/) {
            blk = blk line; next
        }
        if (length(blk) >= 100 && n < 10) { n++; printf "%d %s\n", n, blk }
        blk=""
        # B) 行内长串: 用非编码字符切分, 再按长度筛
        tmp=line
        gsub(/[^A-Za-z0-9+\/_-]/, " ", tmp)
        cnt=split(tmp, arr, " ")
        for (i=1; i<=cnt && n<10; i++) {
            if (length(arr[i]) >= 100) { n++; printf "%d %s\n", n, arr[i] }
        }
    }
    END{ if (length(blk) >= 100 && n < 10) { n++; printf "%d %s\n", n, blk } }
    ' "$f" 2>/dev/null | while read -r idx data; do
        [ -n "$idx" ] && [ -n "$data" ] && printf '%s\n' "$data" > "$od/cand.$pfx$idx" 2>/dev/null
    done

    # C) 为每个候选生成 url-safe 变体(_- 换 +/ 并补齐 padding)
    local cf base len mod pad
    for cf in $(ls -1 "$od"/cand."$pfx"[0-9]* 2>/dev/null | sort); do
        base="${cf##*/cand.$pfx}"
        case "$base" in *[!0-9]*) continue;; esac
        len=$(wc -c < "$cf" 2>/dev/null | tr -d ' ')
        case "$len" in ''|*[!0-9]*) len=0;; esac
        [ "$len" -lt 40 ] && continue
        mod=$(( len % 4 )); pad=""
        [ "$mod" = 2 ] && pad="=="
        [ "$mod" = 3 ] && pad="="
        printf '%s%s\n' "$(tr '_-' '/+' < "$cf" 2>/dev/null | tr -d ' \n')" "$pad" > "$od/cand.${pfx}u$base" 2>/dev/null
    done
    return 0
}

# ---------------------------------------------------------------- Shell 规范化
# 目的: 还原"命令被拆散"的绕过手法, 让规则能命中:
#   a=rm; b="-rf"; c=/system; $a $b $c      -> rm -rf /system
#   r''m -rf /system     / r\m -rf /system -> rm -rf /system
#   ${IFS} / $IFS        -> 空格
#   ${VAR}               -> $VAR
# 只展开"纯字面量"赋值(值里不含 $ ` ; & |), 避免改变语义造成误判。
ar_shell_normalize() {
    local in="$1" out="$2"
    local td="$AR_SCANDIR/norm"
    local mapf="$td/map" sedf="$td/sed"
    mkdir -p "$td" 2>/dev/null
    : > "$mapf" 2>/dev/null; : > "$sedf" 2>/dev/null
    [ -f "$in" ] || return 0

    # 1) 收集简单字面量赋值
    grep -oE '(^|[;[:space:]])[A-Za-z_][A-Za-z0-9_]*=[^;|&`]*' "$in" 2>/dev/null | \
    while IFS='=' read -r lhs rhs; do
        k=$(printf '%s' "$lhs" | tr -d ' ' | grep -oE '[A-Za-z_][A-Za-z0-9_]*$')
        v=$(printf '%s' "$rhs" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')
        [ -z "$k" ] && continue
        [ -z "$v" ] && continue
        case "$v" in *'$'*|*'`'*|*';'*|*'&'*|*'|'*) continue;; esac
        v=$(printf '%s' "$v" | sed -e "s/^[\"']//" -e "s/[\"']\$//")
        [ -z "$v" ] && continue
        printf '%s\t%s\n' "$k" "$v" >> "$mapf" 2>/dev/null
    done

    # 2) 基础规则
    printf '%s\n' 's/\${\([A-Za-z_][A-Za-z0-9_]*\)}/$\1/g' >> "$sedf" 2>/dev/null
    printf '%s\n' 's/\$IFS/ /g'  >> "$sedf" 2>/dev/null
    printf '%s\n' 's/\${IFS}/ /g' >> "$sedf" 2>/dev/null

    # 3) 变量展开(长变量名优先, 避免 $a 抢先匹配 $ab)
    if [ -s "$mapf" ]; then
        sort -u "$mapf" 2>/dev/null | awk -F'\t' '{print length($1)"\t"$1"\t"$2}' | sort -rn | \
        while IFS="$(printf '\t')" read -r len k v; do
            [ -n "$k" ] || continue
            [ -n "$v" ] || continue
            ev=$(printf '%s' "$v" | sed -e 's/[\\&\/]/\\&/g')
            printf 's/\\$%s/%s/g\n' "$k" "$ev" >> "$sedf" 2>/dev/null
        done
    fi

    # 4) 去掉引号与反斜杠(还原 r''m / r\m 这类切割)
    printf '%s\n' "s/['\"]//g"   >> "$sedf" 2>/dev/null
    printf '%s\n' 's/\\//g'      >> "$sedf" 2>/dev/null

    sed -f "$sedf" "$in" > "$out" 2>/dev/null
    [ -s "$out" ] || cp "$in" "$out" 2>/dev/null
    rm -f "$mapf" "$sedf" 2>/dev/null
    return 0
}

# ---------------------------------------------------------------- Caesar 全位移
# 原来只试 ROT13(位移 13), 改成 1-25 全试, 取"像脚本程度"最高的
ar_caesar_best() {
    local in="$1" out="$2"
    local td="$AR_SCANDIR/caes" bs best=0 sc s f t win=""
    mkdir -p "$td" 2>/dev/null
    bs=$(ar_script_score "$in")
    : > "$out" 2>/dev/null
    awk 'BEGIN{
      for(s=1;s<=25;s++){
        f="";t=""
        for(i=0;i<26;i++) f=f sprintf("%c",65+i)
        for(i=0;i<26;i++) t=t sprintf("%c",65+((i+s)%26))
        for(i=0;i<26;i++) f=f sprintf("%c",97+i)
        for(i=0;i<26;i++) t=t sprintf("%c",97+((i+s)%26))
        print s"\t"f"\t"t
      }}' > "$td/sets" 2>/dev/null
    while IFS="$(printf '\t')" read -r s f t; do
        [ -n "$s" ] || continue
        tr "$f" "$t" < "$in" > "$td/o.$s" 2>/dev/null
        sc=$(ar_script_score "$td/o.$s")
        [ -z "$sc" ] && sc=0
        if [ "$sc" -gt "$bs" ] && [ "$sc" -gt "$best" ]; then
            best=$sc; win="$s"
            cp "$td/o.$s" "$out" 2>/dev/null
        fi
    done < "$td/sets"
    rm -f "$td"/o.* 2>/dev/null
    [ -n "$win" ] || return 1
    [ "$win" = "13" ] && printf 'rot13' || printf 'caesar+%s' "$win"
    return 0
}

# ---------------------------------------------------------------- 十六进制还原
# 支持 \x41\x42 形式与连续 hex 串
ar_hex_try() {
    local in="$1" out="$2"
    command -v xxd >/dev/null 2>&1 || return 1
    local tmp="$AR_SCANDIR/_hex.tmp"
    if grep -qiE '(\\x[0-9a-fA-F][0-9a-fA-F]){4,}' "$in" 2>/dev/null; then
        sed -e 's/\\x\([0-9A-Fa-f][0-9A-Fa-f]\)/\1/g' "$in" 2>/dev/null \
            | tr -cd '0-9A-Fa-f' > "$tmp" 2>/dev/null
        xxd -r -p "$tmp" > "$out" 2>/dev/null
        if [ -s "$out" ] && { ar_looks_script "$out" || ar_has_magic "$out"; }; then
            rm -f "$tmp" 2>/dev/null; printf 'hex-escape'; return 0
        fi
        rm -f "$out" 2>/dev/null
    fi
    local h
    h=$(grep -oE '[0-9a-fA-F]{40,}' "$in" 2>/dev/null | head -n 1)
    if [ -n "$h" ]; then
        printf '%s' "$h" > "$tmp" 2>/dev/null
        xxd -r -p "$tmp" > "$out" 2>/dev/null
        if [ -s "$out" ] && { ar_looks_script "$out" || ar_has_magic "$out"; }; then
            rm -f "$tmp" 2>/dev/null; printf 'hex'; return 0
        fi
    fi
    rm -f "$tmp" "$out" 2>/dev/null
    return 1
}

# ---------------------------------------------------------------- base64 解码
# 依次尝试: 标准 -> url-safe(补 padding)
ar_b64_try() {
    local cur="$1" nxt="$2" c2 len mod pad
    (base64 -d "$cur" 2>/dev/null || $BB base64 -d "$cur" 2>/dev/null) > "$nxt" 2>/dev/null
    if [ -s "$nxt" ] && { ar_looks_script "$nxt" || ar_has_magic "$nxt"; }; then
        printf 'base64'; return 0
    fi
    c2="$AR_SCANDIR/_b64.tmp"
    tr -d ' \n' < "$cur" 2>/dev/null | tr '_-' '/+' > "$c2" 2>/dev/null
    len=$(wc -c < "$c2" 2>/dev/null | tr -d ' ')
    case "$len" in ''|*[!0-9]*) len=0;; esac
    mod=$(( len % 4 )); pad=""
    [ "$mod" = 2 ] && pad="=="
    [ "$mod" = 3 ] && pad="="
    [ -n "$pad" ] && printf '%s' "$pad" >> "$c2" 2>/dev/null
    (base64 -d "$c2" 2>/dev/null || $BB base64 -d "$c2" 2>/dev/null) > "$nxt" 2>/dev/null
    if [ -s "$nxt" ] && { ar_looks_script "$nxt" || ar_has_magic "$nxt"; }; then
        rm -f "$c2" 2>/dev/null; printf 'base64(urlsafe)'; return 0
    fi
    rm -f "$nxt" "$c2" 2>/dev/null
    return 1
}

# ---------------------------------------------------------------- 置换表检测
AR_STD_TAB='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/='

ar_find_tables() {
    local f="$1"
    [ -f "$f" ] || return 0
    grep -oE "['\"][A-Za-z0-9+/=]+['\"]" "$f" 2>/dev/null | tr -d "'\"" | \
        awk 'length($0)>=60 && length($0)<=70' | sort -u | head -n 4
    return 0
}

# ---------------------------------------------------------------- 递归解码链
# ar_chain <输入> <输出> [轮次上限] [是否启用 caesar] -> 打印链
ar_chain() {
    local cur="$1" out="$2" max="${3:-6}" caesar="${4:-1}"
    local i=0 chain="" nxt did bs cused=0
    local td="$AR_SCANDIR/chain"
    mkdir -p "$td" 2>/dev/null
    rm -f "$out" 2>/dev/null
    while [ "$i" -lt "$max" ]; do
        nxt="$td/c.$i"
        rm -f "$nxt" 2>/dev/null
        did=""
        # 1) 压缩流(魔数可靠, 解压成功即采纳)
        [ -z "$did" ] && { gzip -dc "$cur" > "$nxt" 2>/dev/null; [ -s "$nxt" ] && did="gzip"; }
        [ -z "$did" ] && { xz -dc "$cur" > "$nxt" 2>/dev/null; [ -s "$nxt" ] && did="xz"; }
        [ -z "$did" ] && { bzip2 -dc "$cur" > "$nxt" 2>/dev/null; [ -s "$nxt" ] && did="bzip2"; }
        [ -z "$did" ] && { command -v lzma >/dev/null 2>&1 && { lzma -dc "$cur" > "$nxt" 2>/dev/null; [ -s "$nxt" ] && did="lzma"; }; }
        # 2) base64(标准 + url-safe)
        [ -z "$did" ] && did=$(ar_b64_try "$cur" "$nxt")
        # 3) 十六进制
        [ -z "$did" ] && did=$(ar_hex_try "$cur" "$nxt")
        # 4) 字符级混淆: Caesar 与倒序互相竞争, 取"更像脚本"的那个
        if [ -z "$did" ] && [ "$caesar" = "1" ] && [ "$cused" -lt 2 ] && [ "$(ar_script_score "$cur")" -le 4 ]; then
            local cf1="$td/ca.$i" cf2="$td/rv.$i" s1=0 s2=0 ok1=0 ok2=0 cn=""
            bs=$(ar_script_score "$cur")
            rm -f "$cf1" "$cf2" 2>/dev/null
            cn=$(ar_caesar_best "$cur" "$cf1" 2>/dev/null)
            if [ -n "$cn" ] && [ -s "$cf1" ]; then
                s1=$(ar_script_score "$cf1")
                ar_looks_script "$cf1" && ok1=1
            fi
            (rev "$cur" 2>/dev/null || $BB rev "$cur" 2>/dev/null) > "$cf2" 2>/dev/null
            if [ -s "$cf2" ]; then
                s2=$(ar_script_score "$cf2")
                ar_looks_script "$cf2" && ok2=1
            fi
            # 判据: 必须"像脚本"且分数高于混淆前; 两者都满足时取分数更高者
            if [ "$ok1" = "1" ] && [ "$s1" -gt "$bs" ]; then
                if [ "$ok2" = "1" ] && [ "$s2" -gt "$s1" ]; then
                    cp "$cf2" "$nxt" 2>/dev/null; did="倒序"
                else
                    cp "$cf1" "$nxt" 2>/dev/null
                    did="$cn"
                    cused=$((cused+1))
                fi
            elif [ "$ok2" = "1" ] && [ "$s2" -gt "$bs" ]; then
                cp "$cf2" "$nxt" 2>/dev/null; did="倒序"
            fi
            rm -f "$cf1" "$cf2" 2>/dev/null
        fi
        [ -z "$did" ] && break
        chain="$chain$did>"
        cur="$nxt"
        i=$((i+1))
    done
    [ "$cur" != "$1" ] && cp "$cur" "$out" 2>/dev/null
    printf '%s' "${chain%>}"
}

# ---------------------------------------------------------------- 主解码入口
# v1.2 增强点:
#   1) 候选含 url-safe 变体与分片重组合并
#   2) 增加"Shell 规范化"候选(还原变量拼接 / 引号切割 / $IFS)
#   3) 解码后再规范化, 然后才跑规则(双重保险)
#   4) Caesar 全位移 + hex + lzma
#   5) 以"命中危险规则数"为主指标挑最优结果
ar_decode() {
    local in="$1" max="${2:-6}"
    local cdir="$AR_SCANDIR/cand"
    rm -rf "$cdir" 2>/dev/null
    mkdir -p "$cdir" "$AR_SCANDIR" 2>/dev/null
    rm -f "$AR_SCANDIR/dec.out" 2>/dev/null
    cp "$in" "$cdir/cand.0" 2>/dev/null
    ar_extract_payloads "$in" "$cdir"

    # --- 合并候选(分片重组) ---
    local merged="$cdir/cand.merge" f
    : > "$merged" 2>/dev/null
    for f in $(ls -1 "$cdir"/cand.[0-9]* 2>/dev/null | sort); do
        [ "$f" = "$cdir/cand.0" ] && continue
        printf '%s' "$(tr -d ' \n' < "$f" 2>/dev/null)" >> "$merged" 2>/dev/null
    done
    [ -s "$merged" ] || rm -f "$merged" 2>/dev/null

    # --- Shell 规范化候选 ---
    ar_shell_normalize "$in" "$cdir/cand.norm" 2>/dev/null
    if [ -s "$cdir/cand.norm" ]; then
        # 变量展开后可能拼出完整的编码串, 需要再从规范化结果里提取一次
        ar_extract_payloads "$cdir/cand.norm" "$cdir" "n"
    else
        rm -f "$cdir/cand.norm" 2>/dev/null
    fi

    # --- 置换变体 ---
    local tabs t cnt=0
    tabs=$(ar_find_tables "$in")
    if [ -n "$tabs" ]; then
        for f in $(ls -1 "$cdir"/cand.* 2>/dev/null | sort); do
            [ "$f" = "$cdir/cand.0" ] && continue
            printf '%s\n' "$tabs" | while read -r t; do
                [ -n "$t" ] || continue
                [ "$(printf '%s' "$t" | wc -c)" -eq "$(printf '%s' "$AR_STD_TAB" | wc -c)" ] || continue
                cnt=$((cnt+1))
                tr "$t" "$AR_STD_TAB" < "$f" > "$f.s$cnt" 2>/dev/null
                cnt=$((cnt+1))
                tr "$AR_STD_TAB" "$t" < "$f" > "$f.s$cnt" 2>/dev/null
            done
        done
    fi

    # --- 原文若已像脚本, 说明没做字符级混淆, 不必跑 Caesar(省时) ---
    # caesar 是否启用由 ar_chain 按"当前内容是否像脚本"自行判断, 这里常开
    local caesar=1

    # --- 逐个试解码, 取最优 ---
    local best=-1 bestc="" c hits sc
    local origsc; origsc=$(ar_script_score "$in")
    local to="$AR_SCANDIR/_try.out" tf="$AR_SCANDIR/_try.find" bo="$AR_SCANDIR/_best.out"
    local no="$AR_SCANDIR/_try.norm"
    local n=0
    rm -f "$bo" 2>/dev/null
    for f in $(ls -1 "$cdir"/cand.* 2>/dev/null | sort); do
        n=$((n+1)); [ "$n" -gt 32 ] && break
        rm -f "$to" "$no" 2>/dev/null
        c=$(ar_chain "$f" "$to" "$max" "$caesar")
        # 解码结果再做一次规范化, 覆盖"解密出来还是变量拼接"的情况
        if [ -s "$to" ]; then
            ar_shell_normalize "$to" "$no" 2>/dev/null
            [ -s "$no" ] && cp "$no" "$to" 2>/dev/null && [ -n "$c" ] && c="$c>规范化"
        else
            continue
        fi
        : > "$tf" 2>/dev/null
        ar_scan_file "$to" "解码结果" "$tf"
        hits=$(wc -l < "$tf" 2>/dev/null | tr -d ' ')
        case "$hits" in ''|*[!0-9]*) hits=0;; esac
        sc=$(( hits * 1000 + $(ar_script_score "$to") ))
        if [ "$sc" -gt "$best" ]; then
            best=$sc; bestc="$c"
            cp "$to" "$bo" 2>/dev/null
        fi
    done
    # 闸门: 没命中任何危险规则, 且"像脚本程度"也没比原文高 -> 判定为没解出
    if [ "$best" -le "$origsc" ]; then
        rm -f "$bo" 2>/dev/null
        printf ''
        return 0
    fi
    if [ -s "$bo" ]; then
        cp "$bo" "$AR_SCANDIR/dec.out" 2>/dev/null
        rm -f "$bo" 2>/dev/null
        printf '%s' "$bestc"
        return 0
    fi
    printf ''
}

# ---------------------------------------------------------------- 评分
ar_score_of() {
    local f="$1" s=0 lvl
    [ -f "$f" ] || { printf '0'; return 0; }
    while IFS='|' read -r lvl rest; do
        [ -n "$lvl" ] || continue
        case "$lvl" in
            critical) s=$((s+40));;
            high)     s=$((s+25));;
            medium)   s=$((s+10));;
            low)      s=$((s+4));;
        esac
    done < "$f"
    [ "$s" -gt 100 ] && s=100
    printf '%s' "$s"
}

ar_level_of() {
    local s="$1"
    if [ "$s" -ge 60 ]; then echo "高危"
    elif [ "$s" -ge 30 ]; then echo "可疑"
    elif [ "$s" -gt 0 ]; then echo "关注"
    else echo "安全"; fi
}
