#!/system/bin/sh
# =====================================================================
#  AutoRescue · Action 入口
#  启动本地 WebUI 服务并打开浏览器(没有 WebUI 的面具也能用)
#  作者: 时尘  v2.0
# =====================================================================

MODDIR=${0%/*}
export MODDIR
. "$MODDIR/common/functions.sh"
. "$MODDIR/common/rescue.sh"

SILENT=0
[ "$1" = "--silent" ] && SILENT=1

ar_init_dirs
ar_conf_defaults

BBX=$(ar_busybox)
WEBROOT="$MODDIR/webroot"
BASE_PORT=$(ar_conf_get webui_port 8080)
case "$BASE_PORT" in ''|*[!0-9]*) BASE_PORT=8080;; esac

say() {
    [ "$SILENT" = "1" ] && return 0
    printf '%s\n' "$*"
}

gen_token() {
    if [ "$(ar_conf_get webui_token 1)" != "1" ]; then
        printf '' > "$WEBROOT/data/token.js" 2>/dev/null
        return 0
    fi
    local tk
    tk=$(cat /proc/sys/kernel/random/uuid 2>/dev/null | tr -d '-' | cut -c1-12)
    [ -z "$tk" ] && tk="$(ar_ts)$(awk '{print $1}' /proc/uptime 2>/dev/null | tr -d '.')"
    ar_state_set webui_token "$tk"
    mkdir -p "$WEBROOT/data" 2>/dev/null
    printf 'window.__AR_TOKEN__="%s";\n' "$tk" > "$WEBROOT/data/token.js" 2>/dev/null
    chmod 0644 "$WEBROOT/data/token.js" 2>/dev/null
}

server_alive() {
    $BBX wget -q -O /dev/null "http://127.0.0.1:$1/index.html" 2>/dev/null && return 0
    return 1
}

# 自检 CGI 是否真的可用:
# 部分精简版 busybox 编译时未开启 CGI 支持, 此时请求 cgi-bin 会返回脚本源码或 404,
# 页面就会报"找不到 api.sh"。这里提前探测, 好给出明确提示而不是让用户一头雾水。
cgi_ok() {
    local p="$1" out
    out=$($BBX wget -q -O - "http://127.0.0.1:$p/cgi-bin/api?p=$(printf 'dmVyc2lvbg==' 2>/dev/null)" 2>/dev/null)
    out=$(printf '%s' "$out" | tr -d '\r\n')
    case "$out" in
        *'"ok"'*) return 0;;
    esac
    return 1
}

# 生成静态数据快照, 供 CGI 不可用时的只读降级模式使用
dump_static() {
    mkdir -p "$WEBROOT/data" 2>/dev/null
    sh "$MODDIR/common/api.sh" status > "$WEBROOT/data/status.json" 2>/dev/null
    chmod 0644 "$WEBROOT/data/status.json" 2>/dev/null
}

start_server() {
    [ -z "$BBX" ] && return 1
    local p i
    p="$BASE_PORT"
    i=0
    while [ "$i" -lt 12 ]; do
        if server_alive "$p"; then
            ar_state_set webui_port "$p"
            CGI_STATE=$(cgi_ok "$p" && echo 1 || echo 0)
            return 0
        fi
        $BBX httpd -p "127.0.0.1:$p" -h "$WEBROOT" >/dev/null 2>&1
        sleep 1
        if server_alive "$p"; then
            ar_state_set webui_port "$p"
            CGI_STATE=$(cgi_ok "$p" && echo 1 || echo 0)
            ar_log INFO "WebUI 服务已启动: http://127.0.0.1:$p (CGI=$CGI_STATE)"
            return 0
        fi
        p=$((p+1))
        i=$((i+1))
    done
    return 1
}

open_browser() {
    local url="$1"
    # 优先用 am 打开
    am start --user 0 -a android.intent.action.VIEW -d "$url" >/dev/null 2>&1 && return 0
    am start -a android.intent.action.VIEW -d "$url" >/dev/null 2>&1 && return 0
    cmd activity start-uri --user 0 "$url" >/dev/null 2>&1 && return 0
    cmd activity start -a android.intent.action.VIEW -d "$url" >/dev/null 2>&1 && return 0
    return 1
}

# 版本号统一从 functions.sh 的 AR_VER 读取, 避免各处硬编码不一致
V="$AR_VER"
[ -z "$V" ] && V=$(grep -m1 '^version=' "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2)
[ -z "$V" ] && V="unknown"

say ""
say "  ╔══════════════════════════════════════════╗"
say "  ║    AutoRescue · 自动救砖守护  $V       ║"
say "  ║              作者: 时尘                  ║"
say "  ╚══════════════════════════════════════════╝"
say ""

gen_token

if [ -z "$BBX" ]; then
    say "  [!] 未找到 busybox, 无法启动本地 WebUI 服务"
    say "      若你的面具 App 支持 WebUI, 请直接在 App 中打开本模块的 WebUI 入口"
    say "      否则可用命令行管理: sh $MODDIR/common/api.sh status"
    exit 1
fi
if [ ! -f "$MODDIR/common/api.sh" ]; then
    say "  [!] 模块文件不完整, 缺少 common/api.sh"
    say "      请重新安装模块 (模块目录应为 /data/adb/modules/auto_rescue)"
    exit 1
fi

if start_server; then
    port=$(ar_state_get webui_port)
    url="http://127.0.0.1:$port/index.html"
    say "  [√] WebUI 服务已就绪: $url"
    dump_static
    if [ "$CGI_STATE" = "1" ]; then
        say "  [√] 交互通道正常 (CGI 可用)"
    else
        say "  [!] 当前 busybox 不支持 CGI, 页面将进入只读模式"
        say "      可查看状态, 但无法执行操作。建议:"
        say "        1) 用支持 WebUI 的面具 App(KernelSU/APatch/MMRL)打开模块"
        say "        2) 或安装完整版 busybox 模块后重试"
        say "        3) 或用命令行: sh $MODDIR/tools/rescue.sh"
    fi
    say ""
    if [ "$SILENT" = "0" ]; then
        if open_browser "$url"; then
            say "  [√] 已尝试唤起浏览器, 若未自动打开请手动访问上述地址"
        else
            say "  [!] 无法自动唤起浏览器, 请手动在浏览器打开:"
            say "      $url"
        fi
    fi
    say ""
    say "  提示: 手机与电脑同网时, 也可在电脑上用 adb 端口转发访问:"
    say "        adb forward tcp:8080 tcp:$port"
    say ""
    ar_log INFO "WebUI 已通过 action 启动: $url"
else
    say "  [!] WebUI 服务启动失败"
    say "      可能是端口被占用或 busybox 的 httpd 不可用"
    say "      可通过 adb 使用命令行管理:"
    say "        sh $MODDIR/common/api.sh status"
    exit 1
fi

exit 0
