/* ===========================================================
   AutoRescue WebUI  ·  主程序  v2.0
   作者: 时尘
   性能策略: 分页面按需渲染 / 增量更新 / 输入防抖 / rAF 批量写入
   =========================================================== */
(function (w, d) {
  'use strict';

  var AR_EMAIL = '3100452752@qq.com';   // 问题反馈邮箱

  var AR_VER = '';   // 模块真实版本, 由 status 接口返回, 页面不再硬编码

  function lsGet(k) { try { return w.localStorage && localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { w.localStorage && localStorage.setItem(k, v); } catch (e) {} }

  // 把界面类设置实时反映到 body class 上
  function applyTheme() {
    var c = cfg(), b = document.body;
    if (!b) return;
    b.classList.toggle('no-anim', c.anim_enable === '0');
    b.classList.toggle('compact', c.compact_mode === '1');
    b.classList.toggle('flat', c.metal_theme === '0');
  }

  var S = {
    data: null, page: 'dash', busy: false,
    filter: 'all', kw: '',
    scan: null, scanTab: 'mod', scanBusy: false, confBusy: false,
    tab: { rescue: 'act', modules: 'list', tools: 'quick' }, dry: null, logOnlyWarn: false, backup: null, syscheck: null,
    guard: null, alerts: null, guardBusy: false,
    conf: null, logs: null, logTimer: null,
    html: {}, raf: 0
  };

  /* ---------------- 基础 ---------------- */
  function $(s, r) { return (r || d).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || d).querySelectorAll(s)); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function toast(msg, type) {
    var t = d.createElement('div');
    t.className = 'tt ' + (type || '');
    t.textContent = msg;
    $('#toast').appendChild(t);
    setTimeout(function () { t.style.opacity = '0'; t.style.transition = '.3s'; }, 2200);
    setTimeout(function () { t.remove(); }, 2600);
  }
  function sheet(title, sub, body, foot) {
    $('#sheet').innerHTML =
      '<h3>' + esc(title) + '</h3><div class="sub">' + (sub || '') + '</div>' + body +
      (foot || '<div class="row" style="margin-top:14px"><button class="btn gh" onclick="ARUI.closeSheet()">关闭</button></div>');
    $('#mask').classList.add('on');
  }
  function closeSheet() { $('#mask').classList.remove('on'); }
  function confirmSheet(title, sub, onYes, yesText) {
    w.__AR_YES__ = onYes;
    sheet(title, esc(sub), '<div class="tip dg">此操作会立即修改设备状态, 建议先创建快照。</div>',
      '<div class="row" style="margin-top:14px">' +
      '<button class="btn gh" onclick="ARUI.closeSheet()">取消</button>' +
      '<button class="btn dg" onclick="ARUI.doYes()">' + esc(yesText || '确认执行') + '</button></div>');
  }
  function doYes() { var f = w.__AR_YES__; closeSheet(); if (f) f(); }

  function debounce(fn, ms) {
    var t = 0;
    return function () {
      var a = arguments, self = this;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(self, a); }, ms);
    };
  }

  /* ---------------- 顶部细进度条 ---------------- */
  var TOPN = 0;
  function topOn() { TOPN++; var t = $('#topbar'); if (t) t.classList.add('on'); }
  function topOff() {
    TOPN--; if (TOPN < 0) TOPN = 0;
    if (TOPN === 0) { var t = $('#topbar'); if (t) t.classList.remove('on'); }
  }

  /* 让浏览器先完成一帧绘制, 再执行可能阻塞主线程的操作。
     KernelSU / MMRL / APatch 的 exec 有可能是同步的: 如果不先让步,
     遮罩还没上屏就被执行完再隐藏, 用户看到的画面就是"完全没有加载动画"。 */
  function nextPaint() {
    return new Promise(function (res) {
      var fired = false;
      function go() { if (fired) return; fired = true; res(); }
      try {
        w.requestAnimationFrame(function () {
          w.requestAnimationFrame(function () { setTimeout(go, 24); });
        });
      } catch (e) { setTimeout(go, 24); }
      // 兜底: 页面在后台时 rAF 不触发, 也要保证流程继续
      setTimeout(go, 260);
    });
  }

  /* ---------------- 忙碌遮罩 ----------------
     进度动画全部由 CSS 驱动, 且只使用 transform / opacity 这类
     能被合成线程独立处理的属性。KernelSU / MMRL / APatch 的 exec
     可能同步阻塞主线程, 此时任何 JS 定时器都会停摆。
     (曾经用 @property + --p 插值显示百分比, 但自定义属性动画走主线程,
      表现就是"长时间 0% 然后突然跳到 90%", 已改为 translateY 数字滚轮。)
     三条时间轴(进度条 / 百分比 / 步骤)共用同一 duration 与缓动, 严格同步。 */
  var BZ = {
    on: false, steps: [], t0: 0, minMs: 620,
    show: function (title, sub, steps) {
      var el = $('#busy'); if (!el) return;
      this.steps = (steps && steps.length) ? steps : ['处理中'];
      var n = this.steps.length;
      this.on = true; this.t0 = Date.now();

      // 总时长随步骤数伸缩; 下限调高一点, 避免"一下就跑完"的假快感
      var dur = n * 0.62;
      if (dur < 1.8) dur = 1.8;
      if (dur > 4.2) dur = 4.2;
      el.style.setProperty('--bzdur', dur.toFixed(2) + 's');

      var t = $('#busyTitle'), sb = $('#busySub'), bs = $('#busySteps');
      if (t) t.textContent = title || '处理中';
      if (sb) sb.textContent = sub || '';
      // 每步: --d 起始时刻, --bsd 单步点亮时长 => 与进度条同一条时间轴
      if (bs) bs.innerHTML = this.steps.map(function (x, k) {
        var d = (dur * k / n).toFixed(3);
        var sd = (dur / n).toFixed(3);
        return '<div class="bstep" style="--d:' + d + 's;--bsd:' + sd + 's">' +
               '<span class="ic"></span>' + esc(x) + '</div>';
      }).join('');

      // 数字滚轮: 0~100 一列, translateY 推进(合成线程, 主线程卡住照样走)
      var roll = $('#busyRoll');
      if (roll) {
        roll.classList.remove('fin');
        roll.innerHTML = (function () {
          var a = [], k;
          for (k = 0; k <= 100; k++) a.push('<span>' + k + '</span>');
          return a.join('');
        })();
        roll.style.animation = 'none';
        void roll.offsetWidth;
        roll.style.animation = '';
      }

      var bar = $('#busyBar');
      if (bar) {
        bar.classList.remove('done');
        bar.style.animation = 'none';
        void bar.offsetWidth;
        bar.style.animation = '';
      }
      var sp = $('#busyStep');
      if (sp) sp.textContent = '共 ' + n + ' 步 · 处理中';
      el.classList.add('on');
    },
    done: function (sub) {
      if (!this.on) return;
      var self = this;
      var bar = $('#busyBar'), roll = $('#busyRoll');
      if (bar) bar.classList.add('done');
      if (roll) roll.classList.add('fin');
      if (sub) { var sb = $('#busySub'); if (sb) sb.textContent = sub; }
      var sp2 = $('#busyStep');
      if (sp2) sp2.textContent = '已完成';
      var wait = (this.minMs || 0) - (Date.now() - this.t0);
      if (wait < 0) wait = 0;
      setTimeout(function () { self.hide(); }, wait + 260);
    },
    hide: function () {
      this.on = false;
      var el = $('#busy'); if (el) el.classList.remove('on');
    }
  };

  function guard(fn, opt) {
    return function () {
      // 必须转发参数: 否则 toggle(id,v) / snapDel(id) 等带参按钮
      // 拿到的全是 undefined, 后端收到空 ID, 操作会静默失效
      var a = arguments;
      if (S.busy) return;
      S.busy = true;
      var quiet = opt && opt.quiet;
      var b = $('#refresh'); if (b && !quiet) b.classList.add('spin');
      if (!quiet) topOn();
      // 没显式给步骤的操作也要显示遮罩(否则用户以为没反应), 用通用两步兜底
      BZ.show((opt && opt.title) || '处理中', (opt && opt.sub) || '',
        (opt && opt.steps) || ['提交指令', '等待模块响应']);
      // 用 Promise.resolve().then(fn) 包一层, 让同步抛错也走 catch 分支
      // 注意必须 return, 否则调用方拿不到 Promise(load().catch 会炸)
      return nextPaint()
        .then(function () { return fn.apply(null, a); })
        .catch(function (e) {
        toast('错误: ' + (e && e.message ? e.message : e), 'bad');
      }).then(function () {
        S.busy = false;
        var b2 = $('#refresh'); if (b2 && !quiet) b2.classList.remove('spin');
        BZ.done((opt && opt.okText) || '完成');
        if (!quiet) topOff();
      });
    };
  }

  /* 按钮内联加载态 */
  function btnLoad(el, on) {
    if (!el) return;
    if (on) { el.dataset.old = el.textContent; el.classList.add('loading'); }
    else {
      el.classList.remove('loading');
      if (el.dataset.old) { el.textContent = el.dataset.old; delete el.dataset.old; }
    }
  }

  function hideSplash() {
    var sp = $('#splash');
    if (sp && !sp.classList.contains('gone')) sp.classList.add('gone');
  }

  function loadCore() {
    return AR.call('status').then(function (data) {
      if (data && data.device && data.device.modver) AR_VER = data.device.modver;
      S.data = data; S.html = {};
      render();
      applyTheme();
      // 记住启动页开关, 下次打开直接跳过等待
      if (data && data.config) lsSet('ar_splash', data.config.splash_enable === '0' ? '0' : '1');
      hideSplash();
      return data;
    });
  }
  var load = guard(loadCore);
  var loadFirst = guard(loadCore, {
    title: '正在连接模块',
    sub: 'AutoRescue · 自动救砖守护',
    steps: ['建立本地通道', '读取设备信息', '汇总守护状态']
  });

  function st() { return (S.data && S.data.status) || {}; }
  function dev() { return (S.data && S.data.device) || {}; }
  function cfg() { return (S.data && S.data.config) || {}; }
  function mods() { return (S.data && S.data.modules) || []; }

  /* ---------------- 图标 & 页面 ---------------- */
  var IC = {
    dash: '<path d="M3 13h8V3H3zM13 21h8v-10h-8zM3 21h8v-4H3zM13 11h8V3h-8z"/>',
    rescue: '<path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6z"/><path d="M9 12l2 2 4-4"/>',
    mod: '<path d="M4 6h16v12H4zM4 10h16M8 6v12"/>',
    snap: '<path d="M3 7h18v12H3zM7 7V4h10v3"/><circle cx="12" cy="13" r="3"/>',
    scan: '<path d="M3 8V5a2 2 0 012-2h3M16 3h3a2 2 0 012 2v3M21 16v3a2 2 0 01-2 2h-3M8 21H5a2 2 0 01-2-2v-3"/><path d="M7 12h2l2-3 2 6 2-3h2"/>',
    guard: '<path d="M12 2l8 3v6c0 5-3.4 9.4-8 11-4.6-1.6-8-6-8-11V5z"/><path d="M12 8v4M12 15h.01"/>',
    conf: '<path d="M12 2v6M12 16v6M2 12h6M16 12h6"/><circle cx="12" cy="12" r="3"/>',
    log: '<path d="M4 4h16v16H4zM7 9h10M7 13h10M7 17h6"/>',
    set: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.6 1.6 0 00-2.7 1.1V21a2 2 0 11-4 0v-.1A1.6 1.6 0 007 19.4l-.1.1a2 2 0 11-2.8-2.8l.1-.1A1.6 1.6 0 003 15a2 2 0 010-4h.1A1.6 1.6 0 004.6 8l-.1-.1a2 2 0 112.8-2.8l.1.1A1.6 1.6 0 009 4.6V4a2 2 0 014 0v.1A1.6 1.6 0 0015 4.6l.1-.1a2 2 0 112.8 2.8l-.1.1A1.6 1.6 0 0021 11h.1a2 2 0 010 4H21a1.6 1.6 0 00-1.6 1z"/>',
    tool: '<path d="M14.7 6.3a4 4 0 105.7 5.7l-1.4-1.4a2 2 0 11-2.8-2.8z"/><path d="M12 2L4 10l3 1-4 9 9-4 1 3 8-8z"/>'
  };

  /* v1.6: 相似页面合并(10 -> 7), 用二级 tab 切换而不是堆在底栏
     快照 -> 救援 / 冲突 -> 模块 / 日志 -> 工具 */
  var PAGES = [
    ['dash', '总览', IC.dash], ['rescue', '救援', IC.rescue], ['modules', '模块', IC.mod],
    ['scan', '检测', IC.scan], ['guard', '防护', IC.guard],
    ['set', '设置', IC.set], ['tools', '工具', IC.tool]
  ];

  var SUBTABS = {
    rescue:  [['act', '救援'], ['snap', '快照']],
    modules: [['list', '模块'], ['conf', '冲突']],
    tools:   [['quick', '快捷'], ['term', '终端'], ['log', '日志'], ['diag', '诊断']]
  };
  function subCur(p) {
    var t = SUBTABS[p];
    if (!t) return '';
    var c = S.tab[p];
    if (!c) { c = t[0][0]; S.tab[p] = c; }
    return c;
  }
  function subTabHtml(p) {
    var t = SUBTABS[p]; if (!t) return '';
    var cur = subCur(p);
    return '<div class="seg segtab">' + t.map(function (x) {
      return '<button class="' + (cur === x[0] ? 'on' : '') + '" ' +
        'onclick="ARUI.subTab(\'' + p + '\',\'' + x[0] + '\')">' + x[1] + '</button>';
    }).join('') + '</div>';
  }

  var RENDER = {
    dash: renderDash, scan: renderScan, guard: renderGuard, set: renderSet,
    rescue: function () {
      return subTabHtml('rescue') +
        (subCur('rescue') === 'snap' ? renderSnaps() : renderRescue());
    },
    modules: function () {
      return subTabHtml('modules') +
        (subCur('modules') === 'conf' ? renderConf() : renderModules());
    },
    tools: function () {
      var c = subCur('tools');
      var body = c === 'term' ? renderTerm()
        : (c === 'log' ? renderLogs()
        : (c === 'diag' ? renderDiag() : renderTools()));
      return subTabHtml('tools') + body;
    }
  };

  /* ---------------- 渲染调度(只渲染当前页) ---------------- */
  function buildSections() {
    $('#app').innerHTML = PAGES.map(function (p) {
      return '<section class="page" id="p-' + p[0] + '"></section>';
    }).join('');
  }
  // 同步二级 tab 的高亮(和模块筛选条同一个坑)
  function syncSubSeg(p, t) {
    var segs = document.querySelectorAll('#p-' + p + ' .segtab button');
    if (!segs.length) return;
    var keys = (SUBTABS[p] || []).map(function (x) { return x[0]; });
    for (var i = 0; i < segs.length; i++) {
      segs[i].className = (keys[i] === t) ? 'on' : '';
    }
  }

  function render() {
    var el = $('#p-' + S.page);
    if (!el || !RENDER[S.page]) return;
    var html;
    try { html = RENDER[S.page](); } catch (e) { html = '<div class="card">渲染出错: ' + esc(e.message) + '</div>'; }
    if (S.html[S.page] === html) return;      // 内容未变则不写 DOM
    S.html[S.page] = html;
    cancelAnimationFrame(S.raf);
    S.raf = requestAnimationFrame(function () { el.innerHTML = html; });
  }
  function go(p) {
    S.page = p;
    $$('#app .page').forEach(function (e) { e.classList.toggle('on', e.id === 'p-' + p); });
    render();
    autoLoad();
    w.scrollTo(0, 0);
  }
  // 进入页面 / 切换子 tab 时按需触发一次加载
  function autoLoad() {
    var p = S.page;
    if (p === 'modules' && subCur('modules') === 'conf' && !S.conf) w.ARUI.loadConf();
    if (p === 'tools' && subCur('tools') === 'log') w.ARUI.loadLogs();
    if (p === 'tools' && subCur('tools') === 'quick' && !S.backup) w.ARUI.loadBackup();
    if (p === 'guard' && !S.guard) w.ARUI.loadGuard();
    if (p === 'guard' && !S.syscheck) w.ARUI.sysCheck();
  }

  function updateTop() {
    var s = st(), dv = dev(), chip = $('#stateChip');
    if (chip && S.data) {
      var c = 'ok', txt = '守护正常';
      if (s.safe_mode == 1) { c = 'bad'; txt = '安全模式'; }
      else if (s.round > 0) { c = 'warn'; txt = '已救援 L' + s.round; }
      else if (s.boot_count > 0) { c = 'cy'; txt = '启动计数 ' + s.boot_count; }
      chip.className = 'chip ' + c; chip.textContent = txt;
    }
    var sub = $('#devSub');
    if (sub && dv.model) sub.textContent = (dv.brand ? dv.brand + ' ' : '') + dv.model + ' · Android ' + dv.android + ' · ' + (dv.root || 'Root');
  }

  /* ---------------- 总览 ---------------- */
  function renderDash() {
    var s = st(), dv = dev(), m = mods();
    var h = s.health || 100, cir = 2 * Math.PI * 46, off = cir * (1 - h / 100);
    var col = h >= 80 ? '#34d399' : (h >= 50 ? '#fbbf24' : '#f87171');
    var desc = '系统启动稳定, 守护正在运行中。';
    if (s.safe_mode == 1) desc = '当前处于安全模式: 所有模块挂载已被移除。处理完成后请手动恢复。';
    else if (s.round > 0) desc = '已执行 L' + s.round + ' 级救援。若已能正常进入桌面, 请到救援页点「确认已稳定」。';
    else if (s.boot_count > 0) desc = '已记录 ' + s.boot_count + ' 次启动, 达到 ' + s.threshold + ' 次将自动触发救援。';

    var kv = [
      ['机型', (dv.brand || '') + ' ' + (dv.model || '?')], ['设备代号', dv.device],
      ['Android', (dv.android || '?') + ' (SDK ' + (dv.sdk || '?') + ')'], ['ROM', dv.rom],
      ['内核', dv.kernel], ['架构 / CPU', (dv.arch || '?') + ' · ' + (dv.cpu || '?') + ' · ' + (dv.cores || '?') + '核'],
      ['SELinux', dv.selinux], ['Root 方案', (dv.root || '?') + ' ' + (dv.rootver || '')],
      ['当前槽位', dv.slot || '-'], ['分辨率', dv.screen || '-'],
      ['运行内存', (dv.mem_avail || '?') + ' / ' + (dv.mem_total || '?') + ' GB 可用'], ['存储空间', dv.storage || '-'],
      ['电量 / 温度', (dv.battery ? dv.battery + '%' : '-') + ' · ' + (dv.battery_temp ? dv.battery_temp + '°C' : '-')],
      ['已运行', dv.uptime_text || '-'], ['系统时间', dv.time || '-']
    ];
    updateTop();

    return '<div class="hero"><div class="hero-in">' +
      '<div class="ring"><svg width="108" height="108" viewBox="0 0 108 108">' +
      '<circle cx="54" cy="54" r="46" fill="none" stroke="rgba(255,255,255,.10)" stroke-width="9"/>' +
      '<circle cx="54" cy="54" r="46" fill="none" stroke="' + col + '" stroke-width="9" stroke-linecap="round" ' +
      'stroke-dasharray="' + cir.toFixed(1) + '" stroke-dashoffset="' + off.toFixed(1) + '"/></svg>' +
      '<div class="val"><b style="color:' + col + '">' + h + '</b><span>健康度</span></div></div>' +
      '<div class="hero-txt"><div class="st">' + (s.safe_mode == 1 ? '安全模式已激活' : (s.round > 0 ? '救援已介入' : '守护运行中')) + '</div>' +
      '<div class="ds">' + esc(desc) + '</div><div class="chips" style="margin-top:8px">' +
      '<span class="chip cy">计数 ' + s.boot_count + '/' + s.threshold + '</span>' +
      '<span class="chip">模块 ' + s.modules_enabled + '/' + s.modules_total + '</span>' +
      (s.quarantined > 0 ? '<span class="chip bad">隔离 ' + s.quarantined + '</span>' : '') +
      '</div></div></div></div>' +

      '<div class="grid g3">' +
      '<div class="stat"><b>' + s.modules_total + '</b><span>模块总数</span><i></i></div>' +
      '<div class="stat"><b>' + s.snapshots + '</b><span>可用快照</span><i></i></div>' +
      '<div class="stat"><b>' + s.rescue_count + '</b><span>累计救援</span><i></i></div></div>' +

      '<div class="card"><div class="ch"><span class="dot"></span><h2>救援状态</h2><small>' + esc(s.last_stage || '-') + '</small></div>' +
      '<div class="kv"><span class="k">启动计数</span><span class="v">' + s.boot_count + ' / ' + s.threshold + '</span></div>' +
      '<div class="bar"><i class="' + (s.boot_count >= s.threshold ? 'bad' : (s.boot_count > 0 ? 'warn' : '')) + '" style="width:' + Math.min(100, s.boot_count / s.threshold * 100) + '%"></i></div>' +
      '<div class="kv"><span class="k">救援等级进度</span><span class="v">L' + s.round + ' / L' + s.max_round + '</span></div>' +
      '<div class="bar"><i class="' + (s.round >= s.max_round ? 'bad' : (s.round > 0 ? 'warn' : '')) + '" style="width:' + Math.min(100, s.round / s.max_round * 100) + '%"></i></div>' +
      '<div class="kv"><span class="k">上次救援</span><span class="v">' + esc(s.last_time || '无') + '</span></div>' +
      '<div class="kv"><span class="k">救援原因</span><span class="v">' + esc(s.last_reason || '无') + '</span></div>' +
      '<div class="kv"><span class="k">上次稳定</span><span class="v">' + esc(s.last_success || '无') + '</span></div>' +
      '<div class="row" style="margin-top:12px">' +
      '<button class="btn sm" onclick="ARUI.act(\'confirm\')">确认已稳定</button>' +
      '<button class="btn sm gh" onclick="ARUI.go(\'rescue\')">救援中心</button></div></div>' +

      '<div class="card"><div class="ch"><span class="dot"></span><h2>设备信息</h2><small>' + esc(dv.root || '') + '</small></div>' +
      kv.map(function (x) { return '<div class="kv"><span class="k">' + esc(x[0]) + '</span><span class="v">' + esc(x[1]) + '</span></div>'; }).join('') + '</div>' +

      '<div class="card"><div class="ch"><span class="dot"></span><h2>模块概览</h2><small>最近 ' + Math.min(5, m.length) + ' 个</small></div>' +
      (m.length ? m.slice(0, 5).map(function (x) {
        return '<div class="kv"><span class="k">' + (x.enabled ? '● ' : '○ ') + esc(x.name) + '</span><span class="v">' +
          (x.whitelist ? '★ 白名单' : (x.enabled ? '启用' : '已禁用')) + '</span></div>';
      }).join('') : '<div class="empty">暂无模块</div>') +
      '<div class="row" style="margin-top:12px"><button class="btn sm gh" onclick="ARUI.go(\'modules\')">管理全部模块</button>' +
      '<button class="btn sm" onclick="ARUI.act(\'snapshot\',[\'create\',\'手动快照\'])">创建快照</button></div></div>' +

      '<div class="card"><div class="ch"><span class="dot"></span><h2>通道信息</h2></div>' +
      '<div class="kv"><span class="k">连接方式</span><span class="v">' + (AR.isWeb ? '本地 Web 服务 (CGI)' : (AR.mode + ' WebUI 桥接')) + '</span></div>' +
      '<div class="kv"><span class="k">模块路径</span><span class="v mono">' + esc(AR.MODDIR) + '</span></div>' +
      '<div class="kv"><span class="k">数据目录</span><span class="v mono">/data/adb/auto_rescue</span></div>' +
      '<div class="kv"><span class="k">版本 / 作者</span><span class="v">' + esc(AR_VER || '-') + ' · 时尘</span></div></div>';
  }

  /* ---------------- 救援 ---------------- */
  var LEVELS = [
    [1, '常规清场', '禁用全部非白名单模块(白名单与锁定项保留)'],
    [2, '深度清场', '禁用全部模块(含白名单), 只留守护自身'],
    [3, '终极隔离', '重命名全部模块目录, 彻底移除挂载']
  ];

  function renderRescue() {
    var s = st(), hi = (S.data && S.data.history) || [], c = cfg();
    return '<div class="card glow"><div class="ch"><span class="dot"></span><h2>启动健康</h2><small>阈值 ' + s.threshold + ' 次</small></div>' +
      '<div class="grid g3" style="margin:0">' +
      '<div class="stat"><b style="color:' + (s.boot_count >= s.threshold ? '#f87171' : '#e8eefc') + '">' + s.boot_count + '</b><span>当前计数</span></div>' +
      '<div class="stat"><b>' + s.round + '</b><span>救援等级</span></div>' +
      '<div class="stat"><b>' + s.rescue_count + '</b><span>累计次数</span></div></div>' +
      '<div class="tip" style="margin-top:12px">判定逻辑: 每次开机计数 +1, 成功进入桌面并稳定 ' + (c.confirm_delay || 90) +
      ' 秒后自动清零。若连续 ' + s.threshold + ' 次都没能稳定进入桌面, 或开机 ' + (c.boot_timeout || 180) + ' 秒仍未完成, 即触发救援。</div></div>' +

      '<div class="card"><div class="ch"><span class="dot"></span><h2>救援等级</h2><small>渐进式, 逐级加重</small></div>' +
      LEVELS.map(function (l) {
        var on = s.round >= l[0];
        return '<div class="lv"><div class="n l' + l[0] + '" style="' + (on ? '' : 'opacity:.4') + '">L' + l[0] + '</div>' +
          '<div class="x"><b>' + l[1] + (on ? ' <span class="chip warn">已执行过</span>' : '') + '</b><span>' + l[2] + '</span></div>' +
          '<button class="mini ' + (l[0] >= 3 ? 'dg' : '') + '" onclick="ARUI.rescue(' + l[0] + ')">执行</button></div>';
      }).join('') + '</div>' +

      '<div class="card glow"><div class="ch"><span class="dot"></span><h2>进阶救援</h2><small>针对特定卡死场景</small></div>' +
      '<div class="tip warn">下面这些是「精准打击」型救援, 比按安装时间盲禁更准, 能少伤及无辜模块。</div>' +

      '<div class="lv" style="margin-top:11px"><div class="n">阶</div><div class="x">' +
      '<b>按卡死阶段救援</b><span>卡在 post-fs-data 就只禁带 post-fs-data.sh 的模块; ' +
      '卡在 service 就只禁带 service.sh 的, 其它模块完全不动</span></div></div>' +
      '<div class="row" style="margin-top:8px">' +
      '<button class="btn sm" onclick="ARUI.stageRescue(\'auto\')">自动判定</button>' +
      '<button class="btn sm gh" onclick="ARUI.stageRescue(\'post-fs-data\')">仅 post-fs-data</button>' +
      '<button class="btn sm gh" onclick="ARUI.stageRescue(\'service\')">仅 service</button></div>' +

      '<div class="lv" style="margin-top:11px"><div class="n">权</div><div class="x">' +
      '<b>修复模块文件权限</b><span>权限不对会导致脚本根本不执行, 症状很像变砖。' +
      '把所有模块脚本统一修正为可执行</span></div>' +
      '<button class="mini" onclick="ARUI.act(\'fixperm\',[],\'修复所有模块与自身脚本的文件权限?\')">修复权限</button></div>' +

      '<div class="lv" style="margin-top:9px"><div class="n">SE</div><div class="x">' +
      '<b>修复 SELinux 标签</b><span>换模块后文件标签常变成 unlabeled, 系统会拒绝执行导致开机卡死。' +
      '对所有模块目录执行 restorecon</span></div>' +
      '<button class="mini" onclick="ARUI.act(\'fixcontext\',[],\'对所有模块目录执行 restorecon 修复标签?\')">修复标签</button></div>' +

      '<div class="lv" style="margin-top:9px"><div class="n l5">清</div><div class="x">' +
      '<b>清理损坏模块目录</b><span>删掉没有 module.prop 的残留目录和空壳模块。' +
      '已锁定/白名单的模块不会被清理</span></div>' +
      '<button class="mini dg" onclick="ARUI.act(\'cleanbroken\',[],\'清理无 module.prop 的残留目录与空壳模块? 建议先做一次模块备份。\')">清理</button></div>' +
      '</div>' +

      '<div class="card"><div class="ch"><span class="dot"></span><h2>救援演练</h2><small>只推演, 不改任何东西</small></div>' +
      '<div class="tip">不确定救援会禁用哪些模块? 点推演一下。它会按真实救援逻辑算出每个等级的影响范围, ' +
      '让你提前知道白名单该怎么设, 全程不会禁用或删除任何东西。</div>' +
      '<div class="row" style="margin-top:11px">' +
      '<button class="btn sm" onclick="ARUI.dryrun()">开始推演</button>' +
      (S.dry ? '<button class="btn sm gh" onclick="ARUI.dryrun()">重新推演</button>' : '') +
      '</div>' + (S.dry ? dryResultHtml(S.dry) : '') + '</div>' +

      '<div class="card"><div class="ch"><span class="dot"></span><h2>手动干预</h2></div>' +
      '<div class="row"><button class="btn sm" onclick="ARUI.act(\'confirm\')">确认已稳定</button>' +
      '<button class="btn sm gh" onclick="ARUI.act(\'clear_state\')">重置计数</button></div>' +
      '<div class="row" style="margin-top:9px">' +
      '<button class="btn sm pk" onclick="ARUI.act(\'force_rescue_file\',[],\'下次开机强制执行一次救援。确定?\')">标记开机强制救援</button>' +
      '<button class="btn sm gh" onclick="ARUI.act(\'snapshot\',[\'create\',\'救援前备份\'])">先备份快照</button></div>' +
      '<div class="row" style="margin-top:9px">' +
      '<button class="btn sm dg" onclick="ARUI.act(\'safemode\',[],\'进入安全模式: 将移除全部模块挂载(含白名单), 仅保留守护自身。确定?\')">一键安全模式</button>' +
      '<button class="btn sm gh" onclick="ARUI.golden(\'restore\')">回滚黄金配置</button></div>' +
      '<div class="tip warn" style="margin-top:11px">「强制救援」会在 /data 下放置标记文件, 下次开机时无条件执行一次救援并自动重启 —— 适用于已经卡在开机动画、连模块管理都进不去的情况(需配合强制重启)。</div></div>' +

      '<div class="card"><div class="ch"><span class="dot"></span><h2>救援历史</h2><small>' + hi.length + ' 条</small></div>' +
      (hi.length ? '<div class="tl">' + hi.slice().reverse().slice(0, 30).map(function (x) {
        return '<div class="it"><b>L' + esc(x.round) + ' · ' + esc(x.action || '') + '</b><span>' + esc(x.time) +
          '</span><p>原因: ' + esc(x.reason) + '</p></div>';
      }).join('') + '</div>' : '<div class="empty"><svg viewBox="0 0 24 24"><path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6z"/></svg><div>还没有救援记录, 这是好事</div></div>') + '</div>' +

      '<div class="card"><div class="ch"><span class="dot"></span><h2>隔离恢复</h2></div>' +
      '<div class="tip">L3 级救援会把模块目录改名为 <span class="mono">*.ar_quarantine</span>, 使其彻底不被挂载。确认系统正常后可一键还原。</div>' +
      '<div class="row" style="margin-top:11px"><button class="btn sm gh" onclick="ARUI.act(\'snapshot\',[\'restore_all\'],\'将解除所有模块的隔离状态。确定?\')">解除全部隔离</button></div></div>';
  }

  /* ---------------- 模块 ---------------- */
  function modListHtml() {
    var list = mods().filter(function (x) {
      if (S.filter === 'on') return x.enabled == 1;
      if (S.filter === 'off') return x.enabled != 1;
      if (S.filter === 'wl') return x.whitelist == 1;
      return true;
    }).filter(function (x) {
      if (!S.kw) return true;
      var k = S.kw.toLowerCase();
      return (x.name + ' ' + x.id + ' ' + x.author).toLowerCase().indexOf(k) >= 0;
    });
    if (!list.length) return '<div class="empty">没有匹配的模块</div>';
    return list.map(function (x) {
      var dt = x.mtime ? new Date(x.mtime * 1000) : null;
      var dtx = dt ? (dt.getMonth() + 1) + '-' + dt.getDate() + ' ' + ('0' + dt.getHours()).slice(-2) + ':' + ('0' + dt.getMinutes()).slice(-2) : '';
      return '<div class="mod' + (x.enabled == 1 ? '' : ' off') + '"><div class="m1"><div class="nm">' +
        '<b>' + esc(x.name) + (x.self ? '<span class="badge">守护自身</span>' : '') +
        (x.whitelist ? '<span class="badge" style="background:linear-gradient(135deg,#fbbf24,#f59e0b)">白名单</span>' : '') + '</b>' +
        '<span>' + esc(x.id) + ' · v' + esc(x.version) + ' · ' + esc(x.author) + ' · ' + dtx + (x.size ? ' · ' + Math.round(x.size / 1024) + 'MB' : '') + '</span>' +
        (x.desc ? '<p>' + esc(x.desc) + '</p>' : '') + '</div></div><div class="ac">' +
        '<button class="mini ' + (x.enabled == 1 ? 'on' : '') + '" onclick="ARUI.toggle(\'' + esc(x.id) + '\',' + (x.enabled == 1 ? 0 : 1) + ')">' + (x.enabled == 1 ? '已启用' : '已禁用') + '</button>' +
        '<button class="mini ' + (x.whitelist == 1 ? 'wl' : '') + '" onclick="ARUI.wl(\'' + esc(x.id) + '\',' + (x.whitelist == 1 ? 0 : 1) + ')">' + (x.whitelist == 1 ? '★ 白名单' : '加入白名单') + '</button>' +
        '<button class="mini" onclick="ARUI.scanMod(\'' + esc(x.id) + '\')">体检</button>' +
        '<button class="mini ' + (x.excluded == 1 ? 'on' : '') + '" onclick="ARUI.exc(\'' + esc(x.id) + '\',' + (x.excluded == 1 ? 0 : 1) + ')">' + (x.excluded == 1 ? '已锁定' : '锁定') + '</button>' +
        '<button class="mini" onclick="ARUI.backupMod(\'' + esc(x.id) + '\')">备份</button>' +
        '<button class="mini" onclick="ARUI.modInfo(\'' + esc(x.id) + '\')">详情</button>' +
        '</div></div>';
    }).join('');
  }

  function renderModules() {
    return '<div class="card"><div class="search">' +
      '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>' +
      '<input class="inp" id="modSearch" placeholder="搜索模块名 / ID / 作者" value="' + esc(S.kw) + '" oninput="ARUI.kw(this.value)"></div>' +
      '<div class="seg segfilter" id="modFilterSeg">' +
      ['all|全部', 'on|已启用', 'off|已禁用', 'wl|白名单'].map(function (x) {
        var p = x.split('|');
        return '<button class="' + (S.filter === p[0] ? 'on' : '') + '" onclick="ARUI.filter(\'' + p[0] + '\')">' + p[1] + '</button>';
      }).join('') + '</div>' +
      '<div class="row"><button class="btn sm" onclick="ARUI.act(\'snapshot\',[\'create\',\'模块调整前\'])">保存快照</button>' +
      '<button class="btn sm gh" onclick="ARUI.act(\'enableall\',[],\'将启用全部模块。确定?\')">全部启用</button>' +
      '<button class="btn sm dg" onclick="ARUI.act(\'disableall\',[\'1\'],\'将禁用除白名单与守护自身以外的全部模块。确定?\')">全部禁用</button></div></div>' +
      '<div id="modList">' + modListHtml() + '</div>';
  }

  /* ---------------- 救援演练结果 ---------------- */
  function dryResultHtml(d) {
    if (!d || !d.levels) return '';
    var tot = d.total_enabled || 0;
    return '<div class="tip" style="margin-top:11px">当前启用模块: <b>' + tot +
      '</b> 个(本守护模块自身受保护, 任何等级都不会被禁用)</div>' +
      d.levels.map(function (L) {
        var col = L.count === 0 ? 'ok' : (L.level >= 4 ? 'bad' : 'warn');
        return '<div class="lv" style="margin-top:9px">' +
          '<div class="n l' + L.level + '">L' + L.level + '</div>' +
          '<div class="x"><b>' + esc(L.title) + ' <span class="chip ' + col + '">' +
          L.count + ' 个</span></b><span>' + esc(L.desc) + '</span>' +
          (L.count ? '<div class="codebox" style="margin-top:6px;padding:6px 8px">' +
            esc(L.items.map(function (i) {
              return '#' + i.order + '  ' + i.id + '  (' + i.name + ')';
            }).join('\n')) + '</div>' : '') +
          '</div></div>';
      }).join('') +
      '<div class="tip warn" style="margin-top:11px">演练结果与实际救援一致: 序号越小表示安装时间越新, ' +
      '救援总是从最新的模块开始禁。若某个模块是你必须保留的, 去「模块」页把它加入白名单。</div>';
  }

  /* ---------------- 快照 ---------------- */
  function renderSnaps() {
    var sn = (S.data && S.data.snapshots) || [];
    return '<div class="card"><div class="ch"><span class="dot"></span><h2>配置快照</h2><small>' + sn.length + ' 个</small></div>' +
      '<div class="tip">快照记录「每个模块的启用/禁用状态」。回滚可一键把模块开关恢复到某个历史时刻。<br>「黄金配置」= 最近一次成功稳定开机时的状态。</div>' +
      '<div class="row" style="margin-top:11px">' +
      '<button class="btn sm" onclick="ARUI.snapCreate()">创建快照</button>' +
      '<button class="btn sm pk" onclick="ARUI.golden(\'set\')">设为黄金配置</button>' +
      '<button class="btn sm gh" onclick="ARUI.load()">刷新</button></div></div>' +
      (sn.length ? sn.map(function (x) {
        return '<div class="card" style="padding:12px">' +
          '<div class="kv"><span class="k">' + esc(x.time) + '</span><span class="v">' + esc(x.tag) + ' · ' + x.count + ' 个模块</span></div>' +
          '<div class="row" style="margin-top:9px">' +
          '<button class="mini" onclick="ARUI.snapRoll(\'' + esc(x.id) + '\')">回滚到此</button>' +
          '<button class="mini dg" onclick="ARUI.snapDel(\'' + esc(x.id) + '\')">删除</button></div></div>';
      }).join('') : '<div class="empty">还没有快照</div>');
  }

  /* ---------------- 脚本检测 ---------------- */
  function renderScan() {
    var r = S.scan;
    return '<div class="card"><div class="ch"><span class="dot"></span><h2>脚本安全检测</h2><small>危险代码 / 加密识别 / 基础解密</small></div>' +
      '<div class="tabs2">' +
      [['mod', '按模块'], ['path', '按路径'], ['paste', '粘贴代码'], ['all', '全部体检']].map(function (t) {
        return '<button class="' + (S.scanTab === t[0] ? 'on' : '') + '" onclick="ARUI.scanTab(\'' + t[0] + '\')">' + t[1] + '</button>';
      }).join('') + '</div>' + scanInputHtml() +
      (S.scanBusy
        ? '<div class="scanline"><div class="beam"></div>' +
          '<div class="txt">正在解析代码结构…</div></div>'
        : '') +
      '<div class="tip"><b>危险代码</b>: 格机、删系统/分区、写块设备、格式化、Fork 炸弹、循环重启等。<br>' +
      '<b>加密/混淆</b>: base64(含 url-safe 与分片重组)、gzip、xz、bzip2、lzma、hex、Caesar 全 25 种位移、字符倒序、置换表 —— 支持多层组合拆解(如 base64→gzip→倒序)。<br>' +
      '<b>代码还原</b>: 变量拼接、引号切割、${IFS} 绕过, 会先规范化再分析。</div></div>' +
      (r ? scanResultHtml(r) : '');
  }

  function scanInputHtml() {
    if (S.scanTab === 'mod') {
      return '<div class="field"><label>选择模块</label><select class="sel" id="scanMod" style="width:100%">' +
        mods().filter(function (m) { return !m.self; }).map(function (m) {
          return '<option value="' + esc(m.id) + '">' + esc(m.name) + ' (' + esc(m.id) + ')</option>';
        }).join('') + '</select></div>' +
        '<div class="row"><button class="btn" onclick="ARUI.scanRun()">扫描该模块脚本</button></div>';
    }
    if (S.scanTab === 'path') {
      return '<div class="field"><label>脚本绝对路径</label><input class="inp" id="scanPath" placeholder="/data/adb/modules/xxx/service.sh"></div>' +
        '<div class="row"><button class="btn" onclick="ARUI.scanRun()">扫描该文件</button></div>';
    }
    if (S.scanTab === 'paste') {
      return '<div class="field"><label>粘贴脚本内容</label><textarea class="inp" id="scanText" rows="7" style="resize:vertical;line-height:1.5" placeholder="#!/system/bin/sh&#10;rm -rf /system"></textarea></div>' +
        '<div class="row"><button class="btn" onclick="ARUI.scanRun()">分析这段代码</button></div>';
    }
    return '<div class="row"><button class="btn" onclick="ARUI.scanRun()">对全部已启用模块体检</button>' +
      '<button class="btn gh" onclick="ARUI.act(\'audit\')">快速风险特征</button></div>';
  }

  function scanResultHtml(r) {
    var col = r.score >= 60 ? '#f87171' : (r.score >= 30 ? '#fbbf24' : (r.score > 0 ? '#22d3ee' : '#34d399'));
    var cir = 2 * Math.PI * 34, off = cir * (1 - r.score / 100);
    var head = '<div class="hero popin"><div class="hero-in"><div class="ring2">' +
      '<svg width="78" height="78" viewBox="0 0 78 78">' +
      '<circle cx="39" cy="39" r="34" fill="none" stroke="rgba(255,255,255,.10)" stroke-width="7"/>' +
      '<circle cx="39" cy="39" r="34" fill="none" stroke="' + col + '" stroke-width="7" stroke-linecap="round" ' +
      'stroke-dasharray="' + cir.toFixed(1) + '" stroke-dashoffset="' + off.toFixed(1) + '"/></svg>' +
      '<div class="v"><b style="color:' + col + '">' + r.score + '</b><span>' + esc(r.level || '') + '</span></div></div>' +
      '<div class="hero-txt"><div class="st">' + esc(r.title || '检测结果') + '</div>' +
      '<div class="ds">' + (r.enc ? '检测到加密/混淆: <b>' + esc(r.enc) + '</b>' + (r.chain ? '，已按 <b>' + esc(r.chain) + '</b> 拆解' : '') : '未发现加密特征') + '</div>' +
      '<div class="chips" style="margin-top:7px"><span class="chip">命中 ' + ((r.findings && r.findings.length) || 0) + ' 条</span>' +
      (r.decrypted ? '<span class="chip ok">已解密并复检</span>' : '') + '</div></div></div></div>';

    if (r.list) {                                   // 全部体检
      return head + '<div class="card"><div class="ch"><span class="dot"></span><h2>各模块体检结果</h2></div>' +
        r.list.map(function (x) {
          return '<div class="gitem"><span class="tag ' + (x.score >= 60 ? 'missing' : (x.score >= 30 ? 'shrink' : (x.score > 0 ? 'nobase' : 'ok'))) + '">' + x.score + '</span>' +
            '<div class="p">' + esc(x.name) + '<span class="c">' + esc(x.id) + ' · ' + esc(x.level) + '</span></div>' +
            '<button class="mini" onclick="ARUI.scanMod(\'' + esc(x.id) + '\')">明细</button></div>';
        }).join('') + '</div>';
    }

    var finds = (r.findings || []).slice().sort(function (a, b) {
      var o = { critical: 0, high: 1, medium: 2, low: 3 };
      return (o[a.risk] || 9) - (o[b.risk] || 9);
    });
    var body = '<div class="card popin d1"><div class="ch"><span class="dot"></span><h2>命中项</h2><small>' + finds.length + ' 条</small></div>' +
      (finds.length ? finds.map(function (f) {
        return '<div class="find ' + f.risk + '"><div class="fh">' +
          '<span class="sev ' + f.risk + '">' + f.risk.toUpperCase() + '</span>' + esc(f.rule) +
          '<span style="color:var(--tx3);font-weight:400;font-size:10.5px">' + esc(f.where) + '</span></div>' +
          '<div class="fd">' + esc(f.desc) + '</div><div class="fc">' + esc(f.code) + '</div></div>';
      }).join('') : '<div class="tip">未命中任何危险规则。注意: 未命中不代表绝对安全, 仅供参考。</div>') + '</div>';

    if (r.preview) {
      body += '<div class="card popin d2"><div class="ch"><span class="dot"></span><h2>解密后代码</h2><small>前 6KB</small></div>' +
        '<div class="codebox">' + esc(r.preview) + '</div></div>';
    }
    if (r.id) {
      body += '<div class="card popin d3"><div class="ch"><span class="dot"></span><h2>处置</h2></div>' +
        '<div class="row"><button class="btn sm dg" onclick="ARUI.toggle(\'' + esc(r.id) + '\',0)">禁用该模块</button>' +
        '<button class="btn sm gh" onclick="ARUI.wl(\'' + esc(r.id) + '\',1)">加入白名单</button>' +
        '<button class="btn sm gh" onclick="ARUI.act(\'safemode\',[],\'将移除全部模块挂载。确定?\')">一键安全模式</button></div></div>';
    }
    return head + body;
  }

  /* ---------------- 系统防护 ---------------- */
  function sysCheckHtml() {
    var k = S.syscheck;
    if (!k) return '<div class="card"><div class="ch"><span class="dot"></span><h2>系统健康检查</h2></div>' +
      '<div class="tip">检查关键系统文件是否缺失、存储空间是否告急、有没有损坏的模块目录。' +
      '这些都会在下一次重启时变成"开不了机"。</div>' +
      '<div class="row" style="margin-top:11px"><button class="btn sm" onclick="ARUI.sysCheck()">开始检查</button></div></div>';
    var miss = (k.missing || '').trim();
    var lowD = (k.data_avail_mb || 0) < 500;
    var bad = miss || lowD || (k.broken_modules || 0) > 0;
    return '<div class="card glow"><div class="ch"><span class="dot"></span><h2>系统健康检查</h2>' +
      '<small><span class="chip ' + (bad ? 'bad' : 'ok') + '">' + (bad ? '发现问题' : '正常') + '</span></small></div>' +
      '<div class="kv"><span class="k">关键系统文件</span><span class="v">' +
        (miss ? '<span style="color:#f87171">缺失 ' + miss.split(' ').filter(Boolean).length + ' 个</span>'
              : '<span style="color:#34d399">全部存在</span>') + '</span></div>' +
      (miss ? '<div class="codebox" style="margin:6px 0 8px">' + esc(miss) + '</div>' : '') +
      '<div class="kv"><span class="k">/data 可用</span><span class="v">' + (k.data_avail_mb || 0) +
        ' MB' + (lowD ? ' <span style="color:#f87171">告急</span>' : '') + '</span></div>' +
      '<div class="kv"><span class="k">/system 可用</span><span class="v">' + (k.system_avail_mb || 0) + ' MB</span></div>' +
      '<div class="kv"><span class="k">损坏模块目录</span><span class="v">' + (k.broken_modules || 0) + ' 个</span></div>' +
      '<div class="kv"><span class="k">SELinux</span><span class="v">' + esc(k.selinux || '-') + '</span></div>' +
      '<div class="kv"><span class="k">模块总数 / 体积</span><span class="v">' +
        (k.module_total || 0) + ' 个 · ' + (k.module_size_kb || 0) + ' KB</span></div>' +
      '<div class="kv"><span class="k">覆盖 /system 的模块</span><span class="v">' + (k.overlay_modules || 0) + ' 个</span></div>' +
      '<div class="tip warn" style="margin-top:11px">模块越多、覆盖系统文件越多, 冲突导致开不了机的概率越高。</div>' +
      '<div class="row" style="margin-top:11px">' +
      '<button class="btn sm" onclick="ARUI.sysCheck()">重新检查</button>' +
      ((k.broken_modules || 0) > 0 ? '<button class="btn sm dg" onclick="ARUI.act(\'cleanbroken\',[],\'清理损坏模块目录? 建议先备份。\')">清理损坏</button>' : '') +
      '</div></div>';
  }

  function renderGuard() {
    var g = S.guard || [], ev = S.alerts || [], c = cfg();
    if (S.guard === null && !S.syscheck) {
      return '<div class="skcard"><div class="skrow"><div class="skav"></div>' +
        '<div style="flex:1"><div class="sk" style="width:70%"></div>' +
        '<div class="sk" style="width:40%;margin:0"></div></div></div></div>' +
        '<div class="skcard"><div class="sk" style="width:52%"></div>' +
        '<div class="sk" style="width:86%"></div>' +
        '<div class="sk" style="width:74%;margin:0"></div></div>';
    }
    var bad = g.filter(function (x) { return x.state === 'missing' || x.state === 'shrink'; }).length;
    return sysCheckHtml() +
      '<div class="card glow"><div class="ch"><span class="dot"></span><h2>重要目录 / 文件防护</h2><small>' + g.length + ' 项受保护</small></div>' +
      '<div class="grid g3" style="margin:0">' +
      '<div class="stat"><b style="color:' + (bad ? '#f87171' : '#34d399') + '">' + bad + '</b><span>异常项</span></div>' +
      '<div class="stat"><b>' + g.length + '</b><span>守护清单</span></div>' +
      '<div class="stat"><b>' + ev.length + '</b><span>告警记录</span></div></div>' +
      '<div class="tip" style="margin-top:12px">机制: 建立基线 → 每 ' + (c.guard_interval || 30) + ' 秒巡检 → 发现目录消失或文件数骤降立即记录告警并可自动恢复。用户态无法拦截内核级删除调用, 这是"第一时间发现 + 留证 + 尽力恢复"的方案。</div>' +
      '<div class="row" style="margin-top:11px">' +
      '<button class="btn sm" onclick="ARUI.guardRun(\'guardcheck\')">立即巡检</button>' +
      '<button class="btn sm gh" onclick="ARUI.guardRun(\'guardbase\')">重建基线</button>' +
      '<button class="btn sm gh" onclick="ARUI.guardRun(\'guardbackup\',[\'create\',\'手动备份\'])">创建备份</button></div></div>' +

      '<div class="card"><div class="ch"><span class="dot"></span><h2>守护清单</h2><small>点击右侧可移除</small></div>' +
      (g.length ? g.map(function (x) {
        var t = x.state === 'missing' ? '已丢失' : (x.state === 'shrink' ? '条目骤减' : (x.state === 'nobase' ? '无基线' : '正常'));
        return '<div class="gitem"><span class="tag ' + x.state + '">' + t + '</span>' +
          '<div class="p">' + esc(x.path) + '<span class="c">基线 ' + esc(x.base_type || '-') + ' · ' + (x.base_count || 0) + ' → 现在 ' + (x.now_count || 0) + ' 项</span></div>' +
          '<button class="mini dg" onclick="ARUI.guardDel(\'' + esc(x.path) + '\')">移除</button></div>';
      }).join('') : '<div class="empty">还没有建立基线</div>') +
      '<div class="row" style="margin-top:11px">' +
      '<input class="inp" id="guardPath" placeholder="添加路径, 如 /system/build.prop" style="flex:1">' +
      '<button class="btn sm" onclick="ARUI.guardAdd()">添加</button></div></div>' +

      '<div class="card"><div class="ch"><span class="dot"></span><h2>告警 / 事件记录</h2><small>' + ev.length + ' 条</small></div>' +
      (ev.length ? '<div>' + ev.slice().reverse().slice(0, 40).map(function (e) {
        return '<div class="ev"><span class="k">' + esc(e.kind) + '</span>' +
          '<span class="m">' + esc(e.path) + ' — ' + esc(e.desc) + '</span>' +
          '<span class="t">' + esc(e.time) + '</span></div>';
      }).join('') + '</div>' : '<div class="empty">暂无告警, 说明一切正常</div>') +
      '<div class="row" style="margin-top:11px"><button class="btn sm gh" onclick="ARUI.guardRun(\'guardclearev\')">清空记录</button>' +
      '<button class="btn sm gh" onclick="ARUI.loadGuard()">刷新</button></div></div>' +

      '<div class="card"><div class="ch"><span class="dot"></span><h2>防护设置</h2></div>' +
      '<div class="opt"><div class="t"><b>启用防护巡检</b><span>关闭后不再检查受保护路径</span></div>' +
      '<div class="sw ' + (c.guard_enable === '1' ? 'on' : '') + '" data-gk="guard_enable" onclick="ARUI.sw(this)"></div></div>' +
      '<div class="opt"><div class="t"><b>检测正在删除关键路径的进程</b><span>扫描 /proc, 记录执行危险删除命令的进程</span></div>' +
      '<div class="sw ' + (c.guard_proc_scan === '1' ? 'on' : '') + '" data-gk="guard_proc_scan" onclick="ARUI.sw(this)"></div></div>' +
      '<div class="opt"><div class="t"><b>新装模块自动体检</b><span>检测到模块列表变化时自动扫描其脚本</span></div>' +
      '<div class="sw ' + (c.auto_scan_new === '1' ? 'on' : '') + '" data-gk="auto_scan_new" onclick="ARUI.sw(this)"></div></div>' +
      '<div class="opt"><div class="t"><b>高危模块自动禁用</b><span>体检得分超过阈值时自动禁用该模块</span></div>' +
      '<div class="sw ' + (c.auto_quarantine_danger === '1' ? 'on' : '') + '" data-gk="auto_quarantine_danger" onclick="ARUI.sw(this)"></div></div>' +
      '<div class="opt"><div class="t"><b>巡检间隔(秒)</b><span>数值越小发现越快, 耗电略增</span></div>' +
      '<input class="inp" style="width:88px;text-align:center" type="number" data-gk="guard_interval" value="' + esc(c.guard_interval || 30) + '"></div>' +
      '<div class="opt"><div class="t"><b>高危判定阈值(分)</b><span>0-100, 建议 60</span></div>' +
      '<input class="inp" style="width:88px;text-align:center" type="number" data-gk="danger_score" value="' + esc(c.danger_score || 60) + '"></div>' +
      '<div class="row" style="margin-top:12px"><button class="btn" onclick="ARUI.saveGuardSet()">保存设置</button></div></div>' +

      '<div class="card"><div class="ch"><span class="dot"></span><h2>只读加固 & 备份</h2></div>' +
      '<div class="tip">只读加固依赖 chattr +i, 多数设备的 /system 不支持, 失败属正常现象。</div>' +
      '<div class="row" style="margin-top:11px">' +
      '<button class="btn sm gh" onclick="ARUI.guardRun(\'guardharden\')">尝试加固</button>' +
      '<button class="btn sm gh" onclick="ARUI.guardBackups()">备份列表</button></div></div>';
  }

  /* ---------------- 冲突 ---------------- */
  function renderConf() {
    var c = S.conf;
    if (S.confBusy) {
      return '<div class="skcard"><div class="sk" style="width:56%"></div>' +
        '<div class="sk" style="width:84%"></div>' +
        '<div class="sk" style="width:68%;margin:0"></div></div>';
    }
    if (!c) return '<div class="card"><div class="empty">扫描有哪些模块在覆盖同一系统文件</div>' +
      '<div class="row"><button class="btn" onclick="ARUI.loadConf()">开始扫描</button></div></div>';
    if (!c.length) return '<div class="card"><div class="ch"><span class="dot"></span><h2>冲突检测</h2></div>' +
      '<div class="tip">未发现模块间覆盖同一系统文件的情况。</div>' +
      '<div class="row" style="margin-top:11px"><button class="btn sm gh" onclick="ARUI.loadConf()">重新扫描</button></div></div>';
    return '<div class="card"><div class="ch"><span class="dot"></span><h2>冲突检测</h2><small>' + c.length + ' 处</small></div>' +
      '<div class="tip warn">以下系统文件被多个模块同时修改, 是引发冲突/不开机的高危点。</div>' +
      c.slice(0, 60).map(function (x) {
        return '<div class="kv"><span class="k mono" style="flex:1">' + esc(x.path) + '</span><span class="v">' + esc(x.modules) + '</span></div>';
      }).join('') +
      '<div class="row" style="margin-top:11px"><button class="btn sm gh" onclick="ARUI.loadConf()">重新扫描</button></div></div>';
  }

  /* ---------------- 日志 ---------------- */
  function renderLogs() {
    return '<div class="card"><div class="ch"><span class="dot"></span><h2>运行日志</h2><small>rescue.log</small></div>' +
      '<div class="row"><button class="btn sm" onclick="ARUI.loadLogs()">刷新</button>' +
      '<button class="btn sm gh" onclick="ARUI.autoLog()">自动刷新</button>' +
      '<button class="btn sm gh" onclick="ARUI.logFilter()">' + (S.logOnlyWarn ? '看全部' : '只看告警') + '</button>' +
      '<button class="btn sm dg" onclick="ARUI.act(\'clearlog\',[],\'清空全部日志?\')">清空</button></div>' +
      '<div class="term" id="logbox" style="margin-top:11px">' +
      '<div class="sk" style="width:88%"></div><div class="sk" style="width:72%"></div>' +
      '<div class="sk" style="width:80%"></div><div class="sk" style="width:60%;margin:0"></div>' +
      '</div></div>';
  }

  function renderTerm() {
    return '<div class="card"><div class="ch"><span class="dot"></span><h2>命令终端</h2><small>以 root 执行</small></div>' +
      '<div class="tip dg">终端会直接以 root 权限执行你输入的命令, 请确认你知道自己在做什么。</div>' +
      '<div class="row" style="margin-top:11px">' +
      '<input class="inp" id="cmdIn" placeholder="例如: getprop ro.build.version.release" style="flex:1">' +
      '<button class="btn sm" onclick="ARUI.runCmd()">执行</button></div>' +
      '<div class="term" id="cmdOut" style="margin-top:11px;max-height:320px">就绪</div>' +
      '<div class="tip" style="margin-top:11px">常用: <span class="mono">ls /data/adb/modules</span> · ' +
      '<span class="mono">getprop ro.build.version.release</span> · ' +
      '<span class="mono">logcat -d | tail -50</span></div></div>';
  }

  function renderDiag() {
    var d = S.data || {};
    return '<div class="card"><div class="ch"><span class="dot"></span><h2>诊断与维护</h2></div>' +
      '<div class="row"><button class="btn sm" onclick="ARUI.diag()">生成诊断报告</button>' +
      '<button class="btn sm gh" onclick="ARUI.audit()">模块风险体检</button></div>' +
      '<div class="row" style="margin-top:9px">' +
      '<button class="btn sm gh" onclick="ARUI.doExport()">导出诊断包</button>' +
      '<button class="btn sm gh" onclick="ARUI.act(\'cleanup\',[],\'清理日志与旧快照?\')">清理</button></div>' +
      '<div class="row" style="margin-top:9px">' +
      '<button class="btn sm gh" onclick="ARUI.act(\'snapshot\',[\'restore_all\'],\'解除全部模块隔离?\')">解除隔离</button>' +
      '<button class="btn sm gh" onclick="ARUI.act(\'clear_state\',[],\'重置启动计数与救援等级?\')">重置状态</button></div>' +
      '<div class="row" style="margin-top:9px">' +
      '<button class="btn sm pk" onclick="ARUI.golden(\'set\')">保存黄金配置</button>' +
      '<button class="btn sm gh" onclick="ARUI.golden(\'restore\')">恢复黄金配置</button></div></div>' +
      '<div class="card"><div class="ch"><span class="dot"></span><h2>模块 ID 速查</h2><small>便于在 Recovery 里手动操作</small></div>' +
      '<div class="tip">长按或复制下方 ID, 可用于 Recovery 命令行精确禁用某个模块。</div>' +
      '<div class="codebox" style="margin-top:9px">' + esc((d.modules || []).map(function (m) {
        return m.id;
      }).join('\n') || '暂无') + '</div></div>';
  }

  /* ---------------- 设置 ---------------- */
  var SETS = [
    ['g', '核心策略'],
    ['s', 'auto_rescue', '自动救砖总开关', '关闭后检测到异常也不会自动处理, 只记录日志'],
    ['n', 'boot_threshold', '启动失败阈值(次)', '连续多少次没能进入桌面即触发救援, 建议 3'],
    ['n', 'confirm_delay', '稳定确认延时(秒)', '进入桌面后持续多少秒无异常才算真正稳定'],
    ['n', 'boot_timeout', '开机超时(秒)', '开机超过这个时间仍未完成启动即判定失败'],
    ['n', 'max_round', '最大救援等级(1-3)', '升级到该等级后不再加重'],
    ['s', 'protect_self', '始终保护守护自身', '任何情况下都不禁用本模块, 保证还能被管理'],
    ['g', '监控'],
    ['s', 'watchdog', '看门狗守护进程', '负责超时救援、崩溃监控、命令队列'],
    ['s', 'monitor_systemserver', 'system_server 崩溃监控', '检测到反复重启自动救援'],
    ['s', 'monitor_zygote', 'Zygote 崩溃监控', '检测到反复重启自动救援'],
    ['g', '快照与备份'],
    ['s', 'auto_snapshot', '救援前自动快照', '每次救援前先保存当前模块状态'],
    ['s', 'module_auto_backup', '模块变动自动快照', '检测到模块列表变化时自动保存'],
    ['n', 'snapshot_keep', '快照保留数量', '超出后自动删除最旧的'],
    ['g', '防护与检测'],
    ['s', 'guard_enable', '系统目录防护巡检', '定期检查受保护路径是否丢失/骤减'],
    ['n', 'guard_interval', '防护巡检间隔(秒)', '默认 30'],
    ['s', 'guard_proc_scan', '危险删除进程检测', '记录正在执行危险删除的进程'],
    ['s', 'auto_scan_new', '新装模块自动体检', '模块列表变化时扫描新模块脚本'],
    ['s', 'auto_quarantine_danger', '高危模块自动禁用', '体检超阈值自动禁用'],
    ['n', 'danger_score', '高危判定阈值(0-100)', '建议 60'],
    ['g', 'WebUI'],
    ['n', 'webui_port', 'WebUI 端口', '被占用会自动顺延'],
    ['s', 'webui_autostart', '开机自启 WebUI 服务', '开机后自动拉起本地服务'],
    ['s', 'webui_token', 'WebUI 访问口令校验', '防止其它应用直接调用本地接口'],
    ['s', 'allow_terminal', '启用命令终端', '关闭后 WebUI 终端不可用'],
    ['g', '其它'],
    ['s', 'notify', '救援后通知提醒', '救援过的情况下开机完成后发送通知'],
    ['s', 'rescue_notify_file', '写入救援说明文件', '在 /data/local/tmp 生成可读的救援说明'],
    ['s', 'conflict_scan_onboot', '开机自动冲突扫描', '略微增加开机耗时'],
    ['g', 'v1.7 新增'],
    ['s', 'rescue_after_snapshot', '救援后立即补一份快照', '便于对比救援前后的模块状态'],
    ['s', 'confirm_before_rescue', '手动救援前二次确认', '避免误触导致模块被禁用'],
    ['s', 'auto_disable_danger', '高危脚本模块自动隔离', '检测到格机/擦除类代码时立即隔离'],
    ['n', 'log_keep_days', '日志保留天数', '超出天数在清理时一并删除'],
    ['g', '界面'],
    ['s', 'splash_enable', '打开时显示 LOGO 启动页', '关闭后直接进入界面'],
    ['s', 'anim_enable', '界面动效', '低端机可关闭以提升流畅度'],
    ['s', 'metal_theme', '金属蓝银配色', '关闭后回到纯色主题'],
    ['s', 'compact_mode', '紧凑模式', '缩小卡片间距, 一屏显示更多']
  ];

  function renderSet() {
    var c = cfg();
    return '<div class="card"><div class="ch"><span class="dot"></span><h2>功能设置</h2><small>改完记得保存</small></div>' +
      SETS.map(function (x) {
        if (x[0] === 'g') return '<div style="margin:14px 0 6px;font-size:11px;color:var(--cy);letter-spacing:1px;font-weight:700">' + x[1] + '</div>';
        var k = x[1], v = c[k];
        if (x[0] === 's') {
          return '<div class="opt"><div class="t"><b>' + x[2] + '</b><span>' + x[3] + '</span></div>' +
            '<div class="sw ' + (v === '1' ? 'on' : '') + '" data-key="' + k + '" onclick="ARUI.sw(this)"></div></div>';
        }
        return '<div class="opt"><div class="t"><b>' + x[2] + '</b><span>' + x[3] + '</span></div>' +
          '<input class="inp" style="width:88px;text-align:center" type="number" data-key="' + k + '" value="' + esc(v == null ? '' : v) + '"></div>';
      }).join('') +
      '<div class="row" style="margin-top:14px"><button class="btn" onclick="ARUI.saveSet()">保存设置</button>' +
      '<button class="btn gh" onclick="ARUI.load()">放弃修改</button></div></div>' +
      '<div class="card"><div class="ch"><span class="dot"></span><h2>说明</h2></div>' +
      '<div class="tip">设置保存在 <span class="mono">/data/adb/auto_rescue/config.conf</span>, 卸载模块后仍会保留, 重装自动延续。</div></div>';
  }

  /* ---------------- 工具 ---------------- */
  function renderTools() {
    var bk = S.backup || [];
    var bkHtml = '<div class="card"><div class="ch"><span class="dot"></span><h2>模块备份</h2><small>整目录复制, 可一键还原</small></div>' +
      '<div class="row"><button class="btn sm" onclick="ARUI.loadBackup()">刷新备份列表</button>' +
      '<button class="btn sm gh" onclick="ARUI.act(\'clearhist\',[],\'清空救援历史?\')">清空救援历史</button></div>' +
      (bk.length ? '<div style="margin-top:11px">' + bk.map(function (b) {
        return '<div class="gitem"><div class="p">' + esc(b.name) +
          '<span class="c">' + esc(b.time || '') + ' · ' + (b.size || 0) + ' KB</span></div>' +
          '<button class="mini" onclick="ARUI.backupDo(\'restore\',\'' + esc(b.name) + '\')">还原</button> ' +
          '<button class="mini dg" onclick="ARUI.backupDo(\'del\',\'' + esc(b.name) + '\')">删除</button></div>';
      }).join('') + '</div>' : '<div class="tip" style="margin-top:11px">暂无备份。可在「模块」页对单个模块点「备份」创建。</div>') +
      '</div>';

    return bkHtml + '<div class="card"><div class="ch"><span class="dot"></span><h2>重启控制</h2></div>' +
      '<div class="row"><button class="btn sm" onclick="ARUI.reboot(\'\',\'重启设备?\')">重启</button>' +
      '<button class="btn sm gh" onclick="ARUI.reboot(\'softrestart\',\'软重启(仅重启安卓)?\')">软重启</button></div>' +
      '<div class="row" style="margin-top:9px">' +
      '<button class="btn sm gh" onclick="ARUI.reboot(\'recovery\',\'重启到 Recovery?\')">Recovery</button>' +
      '<button class="btn sm gh" onclick="ARUI.reboot(\'bootloader\',\'重启到 Fastboot / Bootloader?\')">Fastboot</button></div></div>' +
      '<div class="card"><div class="ch"><span class="dot"></span><h2>诊断与维护</h2></div>' +
      '<div class="row"><button class="btn sm" onclick="ARUI.diag()">生成诊断报告</button>' +
      '<button class="btn sm gh" onclick="ARUI.audit()">模块风险体检</button></div>' +
      '<div class="row" style="margin-top:9px">' +
      '<button class="btn sm gh" onclick="ARUI.act(\'snapshot\',[\'restore_all\'],\'解除全部模块隔离?\')">解除隔离</button>' +
      '<button class="btn sm gh" onclick="ARUI.act(\'clear_state\',[],\'重置启动计数与救援等级?\')">重置状态</button></div>' +
      '<div class="row" style="margin-top:9px">' +
      '<button class="btn sm pk" onclick="ARUI.golden(\'set\')">保存黄金配置</button>' +
      '<button class="btn sm gh" onclick="ARUI.golden(\'restore\')">恢复黄金配置</button></div></div>' +
      '<div class="card glow"><div class="ch"><span class="dot"></span><h2>问题反馈</h2><small>Bug 与建议</small></div>' +
      '<div class="tip">遇到 Bug、界面异常、救援没生效, 或者有任何功能建议, 都欢迎反馈。' +
      '发邮件时如果能附上诊断包会更容易定位问题。</div>' +
      '<div class="kv"><span class="k">反馈邮箱</span><span class="v mono">' + esc(AR_EMAIL) + '</span></div>' +
      '<div class="row" style="margin-top:11px">' +
      '<button class="btn sm" onclick="ARUI.copyMail()">复制邮箱</button>' +
      '<button class="btn sm gh" onclick="ARUI.doExport()">先导出诊断包</button></div>' +
      '<div class="tip" style="margin-top:11px">反馈时建议说明: 机型 / 系统版本 / Root 方案(KernelSU·Magisk·APatch) / ' +
      '复现步骤, 以及导出的诊断包文件。</div></div>' +

      '<div class="card"><div class="ch"><span class="dot"></span><h2>关于</h2></div>' +
      '<div class="kv"><span class="k">模块</span><span class="v">时尘 · 自动救砖守护</span></div>' +
      '<div class="kv"><span class="k">版本</span><span class="v">' + esc((S.data && S.data.device && S.data.device.modver) || AR_VER || '-') + '</span></div>' +
      '<div class="kv"><span class="k">作者</span><span class="v">时尘</span></div>' +
      '<div class="kv"><span class="k">问题反馈</span><span class="v mono">' + esc(AR_EMAIL) + '</span></div>' +
      '<div class="kv"><span class="k">连接通道</span><span class="v">' + (AR.isWeb ? 'HTTP CGI' : AR.mode) + '</span></div>' +
      '<div class="kv"><span class="k">模块目录</span><span class="v mono">' + esc(AR.MODDIR) + '</span></div>' +
      '<div class="kv"><span class="k">数据目录</span><span class="v mono">/data/adb/auto_rescue</span></div>' +
      '<div class="kv"><span class="k">日志</span><span class="v mono">/data/adb/auto_rescue/log/rescue.log</span></div>' +
      '<div class="tip" style="margin-top:11px">手动救援命令(可在 Recovery 的 adb shell 中执行):<br>sh ' + esc(AR.MODDIR) + '/tools/rescue.sh</div></div>';
  }

  /* ---------------- 行为 ---------------- */
  function act(action, args, confirmMsg) {
    var run = guard(function () {
      return AR.call.apply(AR, [action].concat(args || [])).then(function () {
        toast('操作完成', 'ok'); return loadCore();
      });
    }, { title: '执行操作', steps: ['提交指令', '等待模块响应', '刷新状态'] });
    if (confirmMsg) confirmSheet('确认操作', confirmMsg, run, '确认执行');
    else run();
  }

  var onKw = debounce(function (v) {
    S.kw = v;
    var box = $('#modList');
    if (box) box.innerHTML = modListHtml();
    S.html.modules = null;      // 让下次整页渲染重建
  }, 180);

  w.ARUI = {
    go: go, load: load, closeSheet: closeSheet, doYes: doYes, act: act,
    subTab: function (p, t) {
      S.tab[p] = t;
      S.html[p] = null;   // 子 tab 内容变了, 必须清掉缓存否则不重绘
      render();
      syncSubSeg(p, t);
      autoLoad();
    },
    exc: guard(function (id, v) {
      return AR.call('exclude', v ? 'add' : 'del', id).then(function () {
        toast(v ? '已锁定, 任何等级都不会禁用它' : '已解除锁定', 'ok');
        return loadCore();
      });
    }, { title: '更新锁定状态', steps: ['写入排除名单', '刷新模块列表'] }),
    backupMod: guard(function (id) {
      return AR.call('backup', 'create', id, 'manual').then(function (r) {
        toast('已备份: ' + ((r && r.name) || id), 'ok');
        return loadCore();
      });
    }, { title: '备份模块', steps: ['校验模块目录', '复制文件', '记录备份信息'] }),
    loadBackup: guard(function () {
      return AR.call('backup', 'list').then(function (r) {
        S.backup = r; S.html.tools = null; render();
      });
    }, { title: '读取备份列表', steps: ['扫描备份目录'] }),
    backupDo: function (act, name) {
      if (act === 'restore') {
        confirmSheet('还原备份', '将用该备份覆盖当前模块目录:\n' + name + '\n\n当前模块内容会被替换。',
          guard(function () {
            return AR.call('backup', 'restore', name).then(function () {
              toast('已还原', 'ok'); return loadCore();
            });
          }, { title: '还原备份', steps: ['校验备份', '替换模块目录', '刷新列表'] }), '还原');
        return;
      }
      var self = this;
      guard(function () {
        return AR.call('backup', 'del', name).then(function () {
          toast('已删除备份', 'ok'); return self.loadBackup();
        });
      }, { title: '删除备份', steps: ['移除备份目录'] })();
    },
    copyMail: function () {
      var ok = false;
      try {
        var ta = document.createElement('textarea');
        ta.value = AR_EMAIL;
        ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        ok = document.execCommand && document.execCommand('copy');
        document.body.removeChild(ta);
      } catch (e) { ok = false; }
      if (!ok && w.navigator && w.navigator.clipboard) {
        w.navigator.clipboard.writeText(AR_EMAIL).then(function () {
          toast('邮箱已复制: ' + AR_EMAIL, 'ok');
        }).catch(function () { toast('请手动复制: ' + AR_EMAIL); });
        return;
      }
      toast(ok ? ('邮箱已复制: ' + AR_EMAIL) : ('请手动复制: ' + AR_EMAIL), ok ? 'ok' : '');
    },
    sysCheck: guard(function () {
      return AR.call('syscheck').then(function (r) {
        S.syscheck = r; S.html.guard = null; render();
        var bad = r && (r.missing || r.broken_modules > 0 || r.data_avail_mb < 500);
        toast(bad ? '发现问题, 请查看详情' : '未发现异常', bad ? 'bad' : 'ok');
      });
    }, { title: '系统健康检查', steps: ['检查关键系统文件', '读取存储空间', '扫描模块目录', '汇总结果'] }),
    stageRescue: guard(function (stage) {
      return AR.call('stagerescue', stage || 'auto').then(function (r) {
        toast('已处理 ' + ((r && r.count) || 0) + ' 个模块', 'ok');
        return loadCore();
      });
    }, { title: '阶段精准救援', steps: ['读取上次卡死阶段', '匹配对应阶段脚本', '精准禁用', '刷新状态'] }),
    logFilter: function () {
      S.logOnlyWarn = !S.logOnlyWarn;
      S.html.tools = null;
      render();
      w.ARUI.loadLogs();
    },
    doExport: guard(function () {
      return AR.call('export').then(function (r) {
        var path = (r && r.path) || '';
        toast(path ? '已导出' : '导出完成', 'ok');
        if (path) {
          confirmSheet('诊断包已生成', '路径:\n' + path +
            '\n\n可把这个文件发给帮你排查问题的人(内含设备信息、模块列表、救援历史与日志, 不含任何隐私凭据。',
            function () {}, '知道了');
        }
      });
    }, { title: '导出诊断包', steps: ['采集设备信息', '导出模块列表', '附加救援历史', '打包写入'] }),
    dryrun: guard(function () {
      return AR.call('dryrun').then(function (r) {
        S.dry = r; S.html.rescue = null; render();
        toast('演练完成(未做任何改动)', 'ok');
      });
    }, { title: '救援演练', steps: ['读取模块状态', '计算各等级影响范围', '生成演练报告'] }),

    filter: function (f) {
      S.filter = f;
      var b = $('#modList');
      if (b) b.innerHTML = modListHtml();
      // 只更新"筛选条"自己的高亮。
      // 注意: 页面上其实有两个 .seg —— 上面是子 tab(模块/冲突),
      // 下面才是筛选(全部/已启用/已禁用/白名单)。
      // 之前用 '#p-modules .seg button' 会把两组按钮混成一个数组,
      // 按索引赋值时错位到子 tab 上, 表现为子 tab 跟着乱跳甚至全灭。
      // 现在给筛选条单独加 id, 精确命中, 绝不碰子 tab。
      var box = document.getElementById('modFilterSeg');
      var segs = box ? box.querySelectorAll('button')
                     : document.querySelectorAll('#p-modules .segfilter button');
      var keys = ['all', 'on', 'off', 'wl'];
      if (segs && segs.length) {
        for (var i = 0; i < segs.length && i < keys.length; i++) {
          segs[i].className = (keys[i] === f) ? 'on' : '';
        }
      } else {
        // 极端情况(WebView 差异)拿不到节点, 整页重绘兜底
        S.html.modules = null; render();
      }
    },
    kw: onKw,
    sw: function (el) { el.classList.toggle('on'); },

    saveSet: guard(function () {
      var kvs = [];
      $$('[data-key]').forEach(function (e) {
        var k = e.getAttribute('data-key');
        var v = e.classList.contains('sw') ? (e.classList.contains('on') ? '1' : '0') : e.value;
        kvs.push(k + '=' + v);
      });
      return AR.call.apply(AR, ['setconf'].concat(kvs)).then(function () { toast('设置已保存', 'ok'); return loadCore(); });
    }),

    saveGuardSet: guard(function () {
      var kvs = [];
      $$('[data-gk]').forEach(function (e) {
        var k = e.getAttribute('data-gk');
        var v = e.classList.contains('sw') ? (e.classList.contains('on') ? '1' : '0') : e.value;
        kvs.push(k + '=' + v);
      });
      return AR.call.apply(AR, ['setconf'].concat(kvs)).then(function () { toast('防护设置已保存', 'ok'); return loadCore(); });
    }),

    toggle: guard(function (id, v) {
      return AR.call('toggle', id, String(v)).then(function () { toast(v ? '已启用' : '已禁用', 'ok'); return loadCore(); });
    }),

    wl: guard(function (id, v) {
      return AR.call('whitelist', id, v ? 'add' : 'del').then(function () { toast(v ? '已加入白名单' : '已移出白名单', 'ok'); return loadCore(); });
    }),

    rescue: function (lv) {
      confirmSheet('执行 L' + lv + ' 救援', LEVELS[lv - 1][1] + ': ' + LEVELS[lv - 1][2], guard(function () {
        return AR.call('rescue', String(lv), 'WebUI 手动 L' + lv).then(function () { toast('L' + lv + ' 救援已执行', 'ok'); return loadCore(); });
      }, { title: 'L' + lv + ' 救援', steps: ['锁定受影响模块', '写入禁用标记', '记录救援日志', '刷新状态'] }), '执行');
    },

    modInfo: function (id) {
      var m = mods().filter(function (x) { return x.id === id; })[0];
      if (!m) return;
      sheet(m.name, '模块详细信息',
        '<div class="kv"><span class="k">ID</span><span class="v mono">' + esc(m.id) + '</span></div>' +
        '<div class="kv"><span class="k">版本</span><span class="v">' + esc(m.version) + '</span></div>' +
        '<div class="kv"><span class="k">作者</span><span class="v">' + esc(m.author) + '</span></div>' +
        '<div class="kv"><span class="k">状态</span><span class="v">' + (m.enabled == 1 ? '启用' : '禁用') + (m.whitelist ? ' · 白名单' : '') + '</span></div>' +
        '<div class="kv"><span class="k">体积</span><span class="v">' + (m.size ? Math.round(m.size / 1024 * 10) / 10 + ' MB' : '-') + '</span></div>' +
        '<div class="kv"><span class="k">安装时间</span><span class="v">' + (m.mtime ? new Date(m.mtime * 1000).toLocaleString() : '-') + '</span></div>' +
        (m.desc ? '<div class="tip" style="margin-top:10px">' + esc(m.desc) + '</div>' : ''));
    },

    snapCreate: function () {
      sheet('创建快照', '记录当前所有模块的启用状态',
        '<div class="field"><label>备注标签</label><input class="inp" id="snapTag" placeholder="例如: 安装 X 模块前"></div>',
        '<div class="row" style="margin-top:14px"><button class="btn gh" onclick="ARUI.closeSheet()">取消</button>' +
        '<button class="btn" onclick="ARUI.snapDo()">创建</button></div>');
    },
    snapDo: guard(function () {
      var t = $('#snapTag') ? $('#snapTag').value : 'manual';
      closeSheet();
      return AR.call('snapshot', 'create', t || 'manual').then(function () { toast('快照已创建', 'ok'); return loadCore(); });
    }),
    snapRoll: function (id) {
      confirmSheet('回滚快照', '将把所有模块的启用状态恢复到该快照。', guard(function () {
        return AR.call('snapshot', 'rollback', id).then(function () { toast('已回滚', 'ok'); return loadCore(); });
      }), '回滚');
    },
    snapDel: guard(function (id) {
      return AR.call('snapshot', 'delete', id).then(function () { toast('已删除'); return loadCore(); });
    }),

    golden: function (op) {
      if (op === 'restore') {
        confirmSheet('恢复黄金配置', '将把模块开关恢复到最近一次成功稳定开机的状态。', guard(function () {
          return AR.call('golden', 'restore').then(function () { toast('已恢复黄金配置', 'ok'); return loadCore(); });
        }), '恢复');
      } else {
        guard(function () {
          return AR.call('golden', 'set').then(function () { toast('已保存为黄金配置', 'ok'); return loadCore(); });
        })();
      }
    },

    /* ---- 脚本检测 ---- */
    scanTab: function (t) { S.scanTab = t; S.scan = null; var el = $('#p-scan'); if (el) { S.html.scan = null; render(); } },

    scanRun: guard(function () {
      var tab = S.scanTab, p;
      S.scanBusy = true; S.html.scan = null; render();
      if (tab === 'mod') {
        var sel = $('#scanMod');
        var id = sel && sel.value;
        if (!id) { toast('没有可扫描的模块', 'bad'); return Promise.resolve(); }
        p = AR.call('scanmod', id).then(function (r) {
          r.title = '模块: ' + r.name; r.id = id; S.scan = r;
        });
      } else if (tab === 'path') {
        var path = $('#scanPath') ? $('#scanPath').value.trim() : '';
        if (!path) { toast('请填写路径', 'bad'); return Promise.resolve(); }
        p = AR.call('scanfile', path).then(function (r) { r.title = path; S.scan = r; });
      } else if (tab === 'paste') {
        var txt = $('#scanText') ? $('#scanText').value : '';
        if (!txt.trim()) { toast('请粘贴代码', 'bad'); return Promise.resolve(); }
        p = AR.call('scanpaste', btoa(unescape(encodeURIComponent(txt)))).then(function (r) {
          r.title = '粘贴的代码'; S.scan = r;
        });
      } else {
        p = AR.call('scanall').then(function (list) {
          S.scan = { score: 0, level: '体检完成', title: '全部模块体检', list: list, findings: [] };
        });
      }
      return p.then(function () {
        S.scanBusy = false; S.html.scan = null; render();
        var r = S.scan;
        if (r && r.score >= 60) toast('发现高危代码, 请谨慎使用', 'bad');
        else if (r && r.score > 0) toast('发现可疑点', 'bad');
        else toast('未发现危险代码', 'ok');
      });
    }, {
      title: '脚本安全检测',
      steps: ['读取文件内容', '提取编码载荷', '尝试多层解码', '危险规则匹配', '生成检测报告']
    }),

    scanMod: guard(function (id) {
      S.scanTab = 'mod';
      return AR.call('scanmod', id).then(function (r) {
        r.title = '模块: ' + r.name; r.id = id;
        S.scan = r; S.html.scan = null;
        go('scan');
      });
    }, {
      title: '模块脚本体检',
      steps: ['枚举模块内脚本', '提取编码载荷', '尝试多层解码', '危险规则匹配']
    }),

    /* ---- 系统防护 ---- */
    loadGuard: guard(function () {
      return Promise.all([AR.call('guardstatus'), AR.call('guardevents')]).then(function (r) {
        S.guard = r[0]; S.alerts = r[1];
        S.html.guard = null; render();
      });
    }),

    guardRun: guard(function (action, args) {
      return AR.call.apply(AR, [action].concat(args || [])).then(function (r) {
        toast('完成', 'ok');
        if (r && typeof r === 'object' && r.events != null && r.events > 0) {
          toast('发现 ' + r.events + ' 项异常', 'bad');
        }
        return AR.call('guardstatus').then(function (g) {
          S.guard = g;
          return AR.call('guardevents').then(function (e) { S.alerts = e; S.html.guard = null; render(); });
        });
      });
    }, { title: '防护操作', steps: ['提交指令', '执行巡检', '刷新状态'] }),

    guardAdd: guard(function () {
      var v = $('#guardPath') ? $('#guardPath').value.trim() : '';
      if (!v) return Promise.resolve();
      return AR.call('guardpaths', 'add', v).then(function () {
        toast('已添加', 'ok');
        return AR.call('guardbase').then(function () { return w.ARUI.loadGuard(); });
      });
    }),

    guardDel: guard(function (p) {
      return AR.call('guardpaths', 'del', p).then(function () { toast('已移除'); return w.ARUI.loadGuard(); });
    }),

    guardBackups: guard(function () {
      return AR.call('guardbackup', 'list').then(function (list) {
        sheet('防护备份', list.length + ' 个备份(记录模块开关与守护基线)',
          list.length ? list.map(function (b) {
            return '<div class="gitem"><div class="p">' + esc(b.time) + '<span class="c">' + esc(b.tag) + '</span></div>' +
              '<button class="mini" onclick="ARUI.guardRestore(\'' + esc(b.id) + '\')">恢复</button></div>';
          }).join('') : '<div class="tip">还没有备份</div>');
      });
    }),

    guardRestore: guard(function (id) {
      closeSheet();
      return AR.call('guardbackup', 'restore', id).then(function () { toast('已恢复', 'ok'); return loadCore(); });
    }),

    /* ---- 其它 ---- */
    loadConf: guard(function () {
      S.confBusy = true; S.html.conf = null; render();
      return AR.call('conflict').then(function (c) {
        S.confBusy = false;
        S.conf = c; S.html.conf = null; render();
        toast(c.length ? '发现 ' + c.length + ' 处潜在冲突' : '未发现冲突', c.length ? 'bad' : 'ok');
      });
    }, { title: '冲突检测', steps: ['枚举模块目录', '比对系统文件覆盖', '汇总冲突项'] }),

    loadLogs: guard(function () {
      return AR.call('logs', '300').then(function (lines) {
        // 只看告警: 排障时 INFO 噪声太多, 这里做一次简单过滤
        if (S.logOnlyWarn) {
          lines = (lines || []).filter(function (l) {
            return /ERROR|WARN/.test(l);
          });
        }
        var box = $('#logbox');
        if (!box) return;
        box.innerHTML = lines.map(function (l) {
          var c = 'd';
          if (/\[ERROR\]/.test(l)) c = 'e';
          else if (/\[WARN\]/.test(l)) c = 'w';
          else if (/\[INFO\]/.test(l)) c = 'i';
          return '<span class="' + c + '">' + esc(l) + '</span>';
        }).join('\n') || '(暂无日志)';
        box.scrollTop = box.scrollHeight;
      });
    }),

    autoLog: function () {
      if (S.logTimer) { clearInterval(S.logTimer); S.logTimer = null; toast('已停止自动刷新'); return; }
      S.logTimer = setInterval(function () {
        if (S.page === 'logs' && !S.busy) {
          AR.call('logs', '300').then(function (lines) {
            var box = $('#logbox'); if (!box) return;
            box.innerHTML = lines.map(function (l) {
              var c = 'd';
              if (/\[ERROR\]/.test(l)) c = 'e';
              else if (/\[WARN\]/.test(l)) c = 'w';
              else if (/\[INFO\]/.test(l)) c = 'i';
              return '<span class="' + c + '">' + esc(l) + '</span>';
            }).join('\n') || '(暂无日志)';
            box.scrollTop = box.scrollHeight;
          }).catch(function () {});
        }
      }, 6000);
      toast('每 3 秒自动刷新', 'ok');
    },

    runCmd: guard(function () {
      var v = $('#cmdIn') ? $('#cmdIn').value : '';
      if (!v) return Promise.resolve();
      var btn = document.querySelector('#p-logs .btn.sm:not(.gh)');
      btnLoad(btn, true);
      var bx = $('#cmdOut');
      if (bx) bx.innerHTML = '<div class="sk" style="width:60%"></div>';
      return AR.shell(v).then(function (out) {
        btnLoad(btn, false);
        var b2 = $('#cmdOut');
        if (b2) { b2.textContent = out || '(无输出)'; b2.scrollTop = b2.scrollHeight; }
      });
    }),

    diag: guard(function () {
      return AR.call('diag').then(function (r) {
        sheet('诊断报告已生成', '路径: ' + r.path,
          '<div class="kv"><span class="k">大小</span><span class="v">' + (r.size / 1024).toFixed(1) + ' KB</span></div>' +
          '<div class="tip">可用 adb pull 导出, 或在终端中 cat 查看。</div>',
          '<div class="row" style="margin-top:14px"><button class="btn gh" onclick="ARUI.closeSheet()">关闭</button>' +
          '<button class="btn" onclick="ARUI.shell2(\'cat ' + r.path + '\')">查看内容</button></div>');
      });
    }, { title: '生成诊断报告', steps: ['采集设备信息', '收集模块状态', '导出最近日志', '写入报告文件'] }),

    shell2: guard(function (cmd) {
      return AR.shell(cmd).then(function (out) {
        sheet('命令输出', esc(cmd), '<div class="term" style="max-height:50vh">' + esc(out || '(空)') + '</div>');
      });
    }),

    audit: guard(function () {
      return AR.call('audit').then(function (r) {
        var items = String(r || '').split(';').filter(function (x) { return x.trim(); });
        sheet('模块风险体检', items.length ? '发现 ' + items.length + ' 条风险提示' : '未发现明显风险',
          items.length ? items.map(function (x) {
            var p = x.split(':');
            return '<div class="kv"><span class="k mono">' + esc(p[0]) + '</span><span class="v">' + esc(p[1] || '') + '</span></div>';
          }).join('') : '<div class="tip">当前启用的模块没有检出高危特征。</div>');
      });
    }, { title: '模块风险体检', steps: ['扫描已启用模块', '匹配风险特征', '汇总结果'] }),

    reboot: function (t, msg) {
      confirmSheet('重启', msg, function () { AR.call('reboot', t || '').catch(function () {}); toast('已发送重启指令'); }, '重启');
    }
  };

  /* ---------------- 启动 ---------------- */
  d.addEventListener('DOMContentLoaded', function () {
    $('#tabs').innerHTML = PAGES.map(function (t) {
      return '<button class="tb' + (t[0] === S.page ? ' on' : '') + '" data-p="' + t[0] + '">' +
        '<svg viewBox="0 0 24 24">' + t[2] + '</svg>' + t[1] + '</button>';
    }).join('');
    $$('#tabs .tb').forEach(function (b) {
      b.addEventListener('click', function () {
        $$('#tabs .tb').forEach(function (x) { x.classList.remove('on'); });
        b.classList.add('on');
        go(b.getAttribute('data-p'));
      }, { passive: true });
    });
    $('#refresh').addEventListener('click', function () { load(); }, { passive: true });
    $('#mask').addEventListener('click', function (e) { if (e.target.id === 'mask') closeSheet(); }, { passive: true });

    buildSections();
    go('dash');

    // 启动页: 关掉开关就直接跳过; 另设 3.5s 兜底, 避免接口异常时永远卡住
    var spV = $('#spVer');
    if (spV) spV.textContent = '正在连接模块…';
    if (!(lsGet('ar_splash') === '0')) {
      setTimeout(hideSplash, 3500);
    } else { hideSplash(); }

    loadFirst().catch(function (e) {
      BZ.hide();
      hideSplash();
      $('#app').innerHTML = '<div class="card"><div class="ch"><span class="dot" style="background:#f87171"></span><h2>无法连接模块</h2></div>' +
        '<div class="tip dg">' + esc(e && e.message ? e.message : e) + '</div>' +
        '<div class="tip" style="margin-top:10px">请确认: 1) 模块已安装并重启过; 2) 通过模块「执行」按钮打开本页面; 3) 授予了 root 权限。</div></div>';
    });
  });
})(window, document);
