/* ===========================================================
   AutoRescue · 执行桥接层
   自动适配: KernelSU WebUI / MMRL / APatch WebUI / 本地 HTTP CGI
   作者: 时尘  v2.0
   =========================================================== */
(function (w) {
  'use strict';

  var MODDIR = '/data/adb/modules/auto_rescue';
  var API = MODDIR + '/common/api.sh';

  function b64(s) {
    return btoa(unescape(encodeURIComponent(s)));
  }

  function detect() {
    try {
      if (typeof w.ksu !== 'undefined' && typeof w.ksu.exec === 'function') return 'ksu';
    } catch (e) {}
    try {
      if (typeof w.MMRL !== 'undefined' && typeof w.MMRL.exec === 'function') return 'mmrl';
    } catch (e) {}
    try {
      if (typeof w.APatch !== 'undefined' && typeof w.APatch.exec === 'function') return 'apatch';
    } catch (e) {}
    return 'web';
  }

  var MODE = detect();

  function q(s) {
    return "'" + String(s).replace(/'/g, "'\\''") + "'";
  }

  function token() {
    try { return w.__AR_TOKEN__ || (w.localStorage && localStorage.getItem('ar_token')) || ''; }
    catch (e) { return ''; }
  }

  function setToken(t) {
    try { w.localStorage && localStorage.setItem('ar_token', t); } catch (e) {}
  }

  /* 通过 root 桥执行命令 */
  function execRoot(cmd) {
    return new Promise(function (res, rej) {
      var p;
      if (MODE === 'ksu') p = w.ksu.exec(cmd);
      else if (MODE === 'mmrl') p = w.MMRL.exec(cmd);
      else p = w.APatch.exec(cmd);
      Promise.resolve(p).then(function (r) {
        var out;
        if (typeof r === 'string') out = r;
        else if (r && typeof r === 'object') out = r.stdout != null ? r.stdout : (r.result || '');
        else out = '';
        if (r && typeof r === 'object' && r.errno && String(r.errno) !== '0' && !out) {
          return rej(new Error(r.stderr || '执行失败 errno=' + r.errno));
        }
        res(out);
      }).catch(rej);
    });
  }

  /* 通过本地 HTTP CGI 执行 */
  function execWeb(args) {
    var body = 'p=' + b64(args.join('\n'));
    return fetch('cgi-bin/api?t=' + encodeURIComponent(token()), {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain' },
      body: body
    }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.text();
    }).then(function (t) {
      var i = t.indexOf('{');
      if (i < 0) throw new Error('返回内容异常');
      return t.slice(i);
    });
  }

  /* 统一入口: api('status') / api('toggle','id','1') */
  function api() {
    var args = Array.prototype.slice.call(arguments);
    if (MODE === 'web') return execWeb(args);
    var cmd = 'sh ' + API + ' ' + args.map(q).join(' ');
    return execRoot(cmd).then(function (out) {
      var i = out.indexOf('{');
      var j = out.lastIndexOf('}');
      if (i < 0 || j < 0) throw new Error('无 JSON 返回: ' + out.slice(0, 200));
      return out.slice(i, j + 1);
    });
  }

  /* 解析 JSON 结果 */
  function call() {
    return api.apply(null, arguments).then(function (s) {
      var o;
      try { o = JSON.parse(s); } catch (e) { throw new Error('解析失败: ' + s.slice(0, 160)); }
      if (!o.ok) throw new Error(o.error || '操作失败');
      return o.data;
    });
  }

  /* 原始命令执行(终端) */
  function shell(cmd) {
    return call('exec', cmd).then(function (d) { return d.stdout || ''; });
  }

  /* CGI 不可用时的只读降级: 读取 action.sh 预生成的静态快照 */
  function execStatic(args) {
    if (args[0] !== 'status') {
      return Promise.reject(new Error('当前为只读模式(该 busybox 不支持 CGI), 无法执行操作。请换用支持 WebUI 的面具 App, 或在终端执行: sh ' + MODDIR + '/tools/rescue.sh'));
    }
    return fetch('data/status.json?t=' + Date.now()).then(function (r) {
      if (!r.ok) throw new Error('静态快照不可用');
      return r.text();
    }).then(function (t) {
      var i = t.indexOf('{');
      if (i < 0) throw new Error('静态快照格式异常');
      readonly = true;
      return '{"ok":true,"data":' + t.slice(i) + '}';
    });
  }

  var readonly = false;

  w.AR = {
    MODDIR: MODDIR,
    mode: MODE,
    isWeb: MODE === 'web',
    api: api,
    call: function () {
      var args = Array.prototype.slice.call(arguments);
      var p = call.apply(null, args);
      if (MODE === 'web') {
        return p.catch(function (e) {
          var m = String(e && e.message || e);
          if (/JSON|解析|返回内容|HTTP|静态/.test(m)) return execStatic(args).then(function (s) {
            var o = JSON.parse(s);
            if (!o.ok) throw new Error(o.error);
            return o.data;
          });
          throw e;
        });
      }
      return p;
    },
    shell: shell,
    token: token,
    setToken: setToken,
    isReadonly: function () { return readonly; }
  };
})(window);
