把你的 LOGO 图片命名为 logo.png 放在本目录即可，WebUI 会自动使用它。
找不到 logo.png 时，界面会回落到内置的 SVG LOGO（盾牌 + 砖块 + 光环）。

建议：正方形、透明背景 PNG，512x512 左右，主体居中。
