#!/system/bin/sh
# =====================================================================
#  AutoRescue · Watchdog 常驻守护
#  职责: 启动完成超时救援 / 稳定确认 / system_server & zygote 崩溃监控
#        / 命令队列执行 / 新模块安装自动快照
#  作者: 时尘  v2.8
# =====================================================================

MODDIR="${MODDIR:-/data/adb/modules/auto_rescue}"
. "$MODDIR/common/functions.sh"
. "$MODDIR/common/rescue.sh"
. "$MODDIR/common/scan.sh"
. "$MODDIR/common/guard.sh"
. "$MODDIR/common/guard.sh" 2>/dev/null

AR_LOCK="$AR_TMP/watchdog.pid"
AR_QUEUE_FILE="$AR_QUEUE/pending.sh"
AR_QUEUE_LOG="$AR_QUEUE/last_result"

wl_log() { ar_log "$1" "[WD] ${2}"; }

# ---------- 单实例 ----------
if [ -f "$AR_LOCK" ]; then
    old=$(cat "$AR_LOCK" 2>/dev/null)
    # 注意: 不能靠 /proc/PID/cmdline 里是否含 "watchdog" 来判断。
    # 进程是 "sh .../watchdog.sh", cmdline 只有 argv[0]="sh", 脚本名并不在里面,
    # 旧逻辑因此永远判定为"没在跑", 每次开机都重复拉起一个实例(多实例并存)。
    # 改成: 进程存在 + 时间戳未过期(90s 内有过心跳) 就算存活。
    if [ -n "$old" ] && [ -d "/proc/$old" ]; then
        beat=$(ar_state_get watchdog_beat)
        now=$(ar_ts)
        case "$beat" in ''|*[!0-9]*) beat=0;; esac
        if [ $(( now - beat )) -lt 90 ]; then
            ar_log INFO "[WD] 守护已在运行 (pid=$old), 本次退出"
            exit 0
        fi
    fi
fi
mkdir -p "$AR_TMP" 2>/dev/null
echo $$ > "$AR_LOCK" 2>/dev/null

# ---------- 工具 ----------
uptime_sec() { awk '{printf "%d", $1}' /proc/uptime 2>/dev/null; }

boot_completed() {
    [ "$(getprop sys.boot_completed 2>/dev/null)" = "1" ] && return 0
    [ "$(getprop dev.bootcomplete 2>/dev/null)" = "1" ] && return 0
    return 1
}

pidof_bin() {
    local n="$1" p
    p=$(pidof "$n" 2>/dev/null | awk '{print $1}')
    [ -z "$p" ] && p=$(ps -A -o PID,NAME 2>/dev/null | awk -v n="$n" '$2==n{print $1; exit}')
    printf '%s' "$p"
}

# ---------- 命令队列 ----------
run_queue() {
    [ -s "$AR_QUEUE_FILE" ] || return 0
    mkdir -p "$AR_QUEUE" 2>/dev/null
    mv "$AR_QUEUE_FILE" "$AR_QUEUE/running.sh" 2>/dev/null || return 0
    wl_log INFO "执行命令队列"
    sh "$AR_QUEUE/running.sh" >> "$AR_QUEUE_LOG" 2>&1
    rm -f "$AR_QUEUE/running.sh" 2>/dev/null
}

# ---------- 模块目录变化 -> 自动快照 ----------
last_mod_sig=""
mod_signature() {
    ls -1t "$MODULES_DIR" 2>/dev/null | md5sum 2>/dev/null | cut -c1-12
}

# ---------- 新模块危险脚本扫描 ----------
ar_scan_new_modules() {
    local d id mark all s lvl f
    for d in $(ar_module_dirs); do
        id=$(basename "$d")
        [ "$(ar_module_enabled "$d")" = "1" ] || continue
        mark="$AR_STATE/scanned_$id"
        [ -f "$mark" ] && continue
        : > "$mark" 2>/dev/null
        all="$AR_SCANDIR/n.find"
        mkdir -p "$AR_SCANDIR" 2>/dev/null
        : > "$all" 2>/dev/null
        for f in $(find "$d" -maxdepth 3 -name '*.sh' 2>/dev/null | head -n 20); do
            ar_scan_file "$f" "$(basename "$f")" "$all"
        done
        s=$(ar_score_of "$all")
        lvl=$(ar_level_of "$s")
        [ "$s" = "0" ] && continue
        wl_log WARN "新模块脚本体检: $id 得分 $s ($lvl)"
        ar_guard_event "$([ "$s" -ge "$cfg_danger" ] && echo DANGER || echo SCAN)" "$id" \
            "模块 $(ar_prop "$d" name "$id") 脚本体检 $s 分 ($lvl)"
        if [ "$cfg_quar" = "1" ] && [ "$s" -ge "$cfg_danger" ]; then
            ar_disable_module "$d"
            ar_guard_event "BLOCK" "$id" "高危模块已被自动禁用"
            wl_log ERROR "高危模块已自动禁用: $id"
        fi
    done
    # 清理卸载模块的标记
    for m in "$AR_STATE"/scanned_*; do
        [ -e "$m" ] || continue
        id="${m##*scanned_}"
        [ -d "$MODULES_DIR/$id" ] || rm -f "$m" 2>/dev/null
    done
    return 0
}

# ---------- 主循环 ----------
wl_log INFO "守护启动 (pid=$$)"

boot_done=0
confirm_at=0
ss_pid="" ; ss_restarts=0 ; ss_last_change=0
zy_pid="" ; zy_restarts=0
tick=0
deadline=0
prot_at=0

cfg_prot=$(ar_conf_get guard_enable 1)
cfg_prot_iv=$(ar_conf_get guard_interval 30)
case "$cfg_prot_iv" in ''|*[!0-9]*) cfg_prot_iv=30;; esac
[ "$cfg_prot_iv" -lt 5 ] && cfg_prot_iv=5
cfg_autores=$(ar_conf_get guard_autobackup 1)
cfg_scannew=$(ar_conf_get auto_scan_new 1)
cfg_quar=$(ar_conf_get auto_quarantine_danger 0)
cfg_danger=$(ar_conf_get danger_score 60)
case "$cfg_danger" in ''|*[!0-9]*) cfg_danger=60;; esac

cfg_delay=$(ar_conf_get confirm_delay 90)
cfg_timeout=$(ar_conf_get boot_timeout 180)
case "$cfg_delay" in ''|*[!0-9]*) cfg_delay=90;; esac
case "$cfg_timeout" in ''|*[!0-9]*) cfg_timeout=180;; esac
[ "$cfg_timeout" -lt 60 ] && cfg_timeout=60

last_mod_sig=$(mod_signature)

while :; do
    tick=$((tick+1))
    # 心跳: 供单实例检测判断"这个进程还活着"
    ar_state_set watchdog_beat "$(ar_ts)"
    ar_state_set watchdog_pid "$$"

    # 1) 命令队列
    run_queue

    # 2) 模块安装感知 -> 自动快照
    # 降频: 每 3 个 tick(约 15 秒)比对一次, 不必每 5 秒遍历全部模块目录
    if [ "$(ar_conf_get module_auto_backup 1)" = "1" ] && [ $((tick % 3)) -eq 0 ]; then
        cur=$(mod_signature)
        if [ -n "$cur" ] && [ "$cur" != "$last_mod_sig" ]; then
            last_mod_sig="$cur"
            ar_snapshot_create "auto_module_change" >/dev/null 2>&1
            wl_log INFO "检测到模块列表变化, 已自动快照"
            if [ "$cfg_scannew" = "1" ]; then
                ar_scan_new_modules
            fi
        fi
    fi

    # 3) 启动完成检测
    if [ "$boot_done" = "0" ]; then
        if boot_completed; then
            boot_done=1
            confirm_at=$(( $(ar_ts) + cfg_delay ))
            ar_state_set last_stage "boot-completed"
            wl_log INFO "系统启动完成, ${cfg_delay}s 后确认稳定"
        else
            if [ "$deadline" = "0" ]; then deadline=$(( $(ar_ts) + cfg_timeout )); fi
            if [ "$(ar_ts)" -gt "$deadline" ]; then
                wl_log ERROR "启动超时 ${cfg_timeout}s 未完成 -> 判定启动失败"
                if [ "$(ar_conf_get auto_rescue 1)" = "1" ]; then
                    r=$(ar_state_get rescue_round); case "$r" in ''|*[!0-9]*) r=0;; esac
                    r=$((r+1)); ar_state_set rescue_round "$r"
                    ar_do_rescue "$r" "启动超时未完成 (${cfg_timeout}s)"
                    ar_state_set boot_count 0
                    if ar_circuit_breaker; then ar_reboot "boot_timeout"; fi
                    exit 0
                fi
                deadline=$(( $(ar_ts) + cfg_timeout ))
            fi
        fi
    fi

    # 4) 稳定确认
    if [ "$boot_done" = "1" ] && [ "$confirm_at" -gt 0 ] && [ "$(ar_ts)" -ge "$confirm_at" ]; then
        ar_confirm_success
        confirm_at=0
    fi

    # 4.5) 系统目录 / 重要文件防护巡检
    if [ "$cfg_prot" = "1" ] && [ "$boot_done" = "1" ]; then
        if [ "$prot_at" = "0" ] || [ "$(ar_ts)" -ge "$prot_at" ]; then
            prot_at=$(( $(ar_ts) + cfg_prot_iv ))
            gev=$(ar_guard_check)
            [ "${gev:-0}" -gt 0 ] && wl_log ERROR "防护巡检发现 ${gev} 项异常, 详见告警记录"
        fi
    fi

    # 5) system_server / zygote 崩溃监控
    if [ "$(ar_conf_get monitor_systemserver 1)" = "1" ] && [ "$boot_done" = "1" ]; then
        p=$(pidof_bin system_server)
        if [ -n "$p" ]; then
            if [ -n "$ss_pid" ] && [ "$p" != "$ss_pid" ]; then
                ss_restarts=$((ss_restarts+1))
                ss_last_change=$(ar_ts)
                wl_log WARN "system_server 重启 (第 $ss_restarts 次) pid $ss_pid -> $p"
            fi
            ss_pid="$p"
        fi
        # 60 秒内重启 >= 3 次 => 崩溃循环
        if [ "$ss_restarts" -ge 3 ]; then
            if [ "$(( $(ar_ts) - ss_last_change ))" -lt 60 ]; then
                wl_log ERROR "system_server 频繁崩溃 ($ss_restarts 次) -> 触发救援"
                if [ "$(ar_conf_get auto_rescue 1)" = "1" ]; then
                    r=$(ar_state_get rescue_round); case "$r" in ''|*[!0-9]*) r=3;; esac
                    r=$((r+1)); ar_state_set rescue_round "$r"
                    ar_do_rescue "$r" "system_server 崩溃循环 ($ss_restarts 次)"
                    ar_state_set boot_count 0
                    if ar_circuit_breaker; then ar_reboot "ss_crash"; fi
                    exit 0
                fi
            else
                ss_restarts=0
            fi
        fi
    fi

    if [ "$(ar_conf_get monitor_zygote 1)" = "1" ] && [ "$boot_done" = "1" ]; then
        p=$(pidof_bin zygote64); [ -z "$p" ] && p=$(pidof_bin zygote)
        if [ -n "$p" ]; then
            if [ -n "$zy_pid" ] && [ "$p" != "$zy_pid" ]; then
                zy_restarts=$((zy_restarts+1))
                wl_log WARN "zygote 重启 (第 $zy_restarts 次)"
            fi
            zy_pid="$p"
            if [ "$zy_restarts" -ge 4 ]; then
                wl_log ERROR "zygote 反复重启 -> 触发救援"
                if [ "$(ar_conf_get auto_rescue 1)" = "1" ]; then
                    r=$(ar_state_get rescue_round); case "$r" in ''|*[!0-9]*) r=3;; esac
                    r=$((r+1)); ar_state_set rescue_round "$r"
                    ar_do_rescue "$r" "zygote 崩溃循环"
                    ar_state_set boot_count 0
                    if ar_circuit_breaker; then ar_reboot "zygote_crash"; fi
                    exit 0
                fi
                zy_restarts=0
            fi
        fi
    fi

    # 6) 重要目录守护巡检
    # 注意: 这里原本还有一次独立的 ar_guard_check(每 60s), 与上面第 4.5 段
    # 的巡检(每 30s)重复 —— 同一批目录被两遍遍历, 开销翻倍。
    # 现在统一由第 4.5 段负责, 本段只做告警计数汇总, 不再重复巡检。
    if [ "$(ar_conf_get guard_enable 1)" = "1" ]; then
        gt=$((tick % 12))
        if [ "$gt" = "0" ]; then
            ev=$(ar_state_get guard_last_events)
            if [ -n "$ev" ] && [ "$ev" -gt 0 ] 2>/dev/null; then
                wl_log WARN "守护巡检累计发现 $ev 项异常"
                ar_state_set guard_alerts "$(( $(ar_state_get guard_alerts 2>/dev/null | sed 's/[^0-9]//g') + ev ))"
            fi
        fi
    fi

    # 7) tick 归零, 避免无限增长
    if [ "$tick" -gt 240 ]; then tick=0; fi

    sleep 5
done
