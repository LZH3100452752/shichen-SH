#!/system/bin/sh
# =====================================================================
#  AutoRescue · 卸载清理
#  卸载时会自动恢复由本模块禁用的其它模块, 避免"卸载后模块全没了"的困惑
#  作者: 时尘  v2.8
# =====================================================================

MODDIR=${0%/*}
export MODDIR
. "$MODDIR/common/functions.sh" 2>/dev/null

AR_DATA="/data/adb/auto_rescue"
AR_STATE="$AR_DATA/state"

ar_log WARN "模块正在卸载, 执行清理与恢复"

# 1) 恢复被本模块禁用的模块
if [ -f "$AR_STATE/disabled_by_us" ]; then
    while IFS= read -r id; do
        [ -z "$id" ] && continue
        [ -d "$MODULES_DIR/$id" ] && rm -f "$MODULES_DIR/$id/disable" 2>/dev/null
    done < "$AR_STATE/disabled_by_us"
    ar_log INFO "已恢复所有被自动禁用的模块"
fi

# 2) 解除隔离
for d in "$MODULES_DIR"/*.ar_quarantine; do
    [ -d "$d" ] || continue
    mv "$d" "${d%.ar_quarantine}" 2>/dev/null
done

# 3) 清理临时标记
rm -f "$AR_DATA/force_rescue" 2>/dev/null
rm -f "$AR_STATE/safe_mode" 2>/dev/null

# 4) 停止 WebUI 服务 (尽力)
for p in /proc/[0-9]*; do
    pid="${p#/proc/}"
    grep -q "httpd" "$p/cmdline" 2>/dev/null && grep -q "auto_rescue" "$p/cmdline" 2>/dev/null && kill "$pid" 2>/dev/null
done

# 5) 保留配置与日志, 方便重装后延续
ar_log INFO "配置与日志已保留在 $AR_DATA (可手动删除)"

exit 0
