/* =====================================================================
   AutoRescue · 多语言引擎 (i18n)  v2.8
   设计要点
   1) 每种语言一个独立 js 文件, 放在 assets/js/lang/<code>.js, 按需异步加载,
      中文为内置源文本(不加载额外文件), 首屏不受影响。
   2) 替换发生在「HTML 字符串写入 DOM 之前」, 用正则只替换标签之间的文本
      (>文本<), 因此绝不会破坏 onclick / data-* 等属性里的中文参数。
      (v2.7 用 TreeWalker 遍历文本节点, 在部分 WebView 上不触发,
       表现为"切了语言又变回中文", 已废弃。)
   3) 词条按长度降序匹配, 长句优先。
   4) 切换语言立即重绘当前页, 不退出界面; 语言写 localStorage + 模块配置。
   作者: 时尘  v2.8
   ===================================================================== */
(function (w) {
  'use strict';

  var LANGS = [
    ['zh-CN', '简体中文', '🇨🇳'],
    ['zh-TW', '繁體中文', '🇹🇼'],
    ['en', 'English', '🇺🇸'],
    ['ja', '日本語', '🇯🇵'],
    ['ko', '한국어', '🇰🇷'],
    ['ru', 'Русский', '🇷🇺'],
    ['fr', 'Français', '🇫🇷'],
    ['es', 'Español', '🇪🇸'],
    ['de', 'Deutsch', '🇩🇪'],
    ['vi', 'Tiếng Việt', '🇻🇳']
  ];
  w.ARLANG = w.ARLANG || {};

  var CUR = 'zh-CN';
  var DICT = null;      // 当前语言词典
  var KEYS = null;      // 按长度降序的 key 数组
  var LS_KEY = 'ar_lang';
  var loaded = {};      // 已加载的语言
  var pending = null;

  function valid(v) {
    for (var i = 0; i < LANGS.length; i++) if (LANGS[i][0] === v) return true;
    return false;
  }

  function lsGet() {
    try { var v = w.localStorage && w.localStorage.getItem(LS_KEY); if (v && valid(v)) return v; } catch (e) {}
    return '';
  }
  function lsSet(v) { try { w.localStorage && w.localStorage.setItem(LS_KEY, v); } catch (e) {} }

  function buildIndex(d) {
    var arr = [], k;
    for (k in d) if (Object.prototype.hasOwnProperty.call(d, k) && k !== '__end__') arr.push(k);
    arr.sort(function (a, b) { return b.length - a.length; });
    return arr;
  }

  /* 加载语言包。中文(zh-CN)无需加载文件。
     返回 Promise, 完成后再调用方重绘界面。 */
  function load(lang, cb) {
    lang = lang || 'zh-CN';
    if (!valid(lang)) lang = 'zh-CN';
    CUR = lang;
    lsSet(lang);
    if (lang === 'zh-CN') { DICT = null; KEYS = null; if (cb) cb(); return; }
    if (loaded[lang]) {
      DICT = w.ARLANG[lang]; KEYS = KEYS_BY[lang];
      if (cb) cb(); return;
    }
    var s = w.document.createElement('script');
    s.src = 'assets/js/lang/' + lang + '.js';
    s.onload = function () {
      loaded[lang] = 1;
      DICT = w.ARLANG[lang] || {};
      KEYS_BY[lang] = buildIndex(DICT);
      KEYS = KEYS_BY[lang];
      if (cb) cb();
      try { s.parentNode.removeChild(s); } catch (e) {}
    };
    s.onerror = function () {
      // 加载失败(比如文件缺失)则回落中文, 不至于界面空白
      CUR = 'zh-CN'; DICT = null; KEYS = null;
      if (cb) cb();
    };
    (w.document.head || w.document.documentElement).appendChild(s);
  }
  var KEYS_BY = {};

  /* ---------------- 核心: HTML 字符串替换 ----------------
     只替换 >文本< 之间的内容, 绝不动属性。 */
  function TH(html) {
    if (!html || typeof html !== 'string') return html;
    if (CUR === 'zh-CN' || !DICT || !KEYS) return html;
    // 先按标签切分: 只处理"标签之间"的片段
    return html.replace(/>([^<>]+)</g, function (m0, inner) {
      if (!/[\u4e00-\u9fff]/.test(inner)) return m0;
      var out = inner, i, k, v;
      for (i = 0; i < KEYS.length; i++) {
        k = KEYS[i];
        if (out.indexOf(k) < 0) continue;
        v = DICT[k];
        if (!v) continue;
        out = out.split(k).join(v);
      }
      return '>' + out + '<';
    });
  }

  /* 纯文本翻译(用于 toast / 遮罩标题等非 HTML 场景) */
  function T(text) {
    if (!text || typeof text !== 'string') return text;
    if (CUR === 'zh-CN' || !DICT || !KEYS) return text;
    var out = text, i, k, v;
    for (i = 0; i < KEYS.length; i++) {
      k = KEYS[i];
      if (out.indexOf(k) < 0) continue;
      v = DICT[k];
      if (!v) continue;
      out = out.split(k).join(v);
    }
    return out;
  }

  /* 静态 DOM(index.html 里的 h1 / 启动页文案)翻译一次 */
  function applyStatic() {
    if (CUR === 'zh-CN' || !DICT || !KEYS) return;
    var d = w.document;
    if (!d) return;
    var nodes = d.querySelectorAll('h1, .sp-t, .sp-s, .sp-hint, #devSub, title');
    for (var i = 0; i < nodes.length; i++) {
      var n = nodes[i];
      if (n && n.firstChild && n.firstChild.nodeType === 3) {
        var t = n.firstChild.nodeValue;
        var nt = T(t);
        if (nt !== t) n.firstChild.nodeValue = nt;
      } else if (n && n.textContent) {
        var t2 = n.textContent, nt2 = T(t2);
        if (nt2 !== t2) n.textContent = nt2;
      }
    }
    if (d.title) { var tt = T(d.title); if (tt !== d.title) d.title = tt; }
  }

  w.ARI18N = {
    LANGS: LANGS,
    list: function () { return LANGS; },
    get: function () { return CUR; },
    isZh: function () { return CUR === 'zh-CN'; },
    load: load,
    TH: TH,
    T: T,
    applyStatic: applyStatic,
    ready: function () { return CUR === 'zh-CN' || !!DICT; }
  };

  /* 启动时先按 localStorage 恢复, 避免界面闪一下中文 */
  var init = lsGet();
  if (init && init !== 'zh-CN') {
    // 同步尝试: 若文件已缓存则立刻生效; 否则异步加载
    try {
      var xhr = new XMLHttpRequest();
      xhr.open('GET', 'assets/js/lang/' + init + '.js', false);
      xhr.send();
      if (xhr.status === 200 || xhr.status === 0) {
        try { (new Function(xhr.responseText))(); } catch (e) {}
        if (w.ARLANG[init]) {
          CUR = init;
          DICT = w.ARLANG[init];
          KEYS_BY[init] = buildIndex(DICT);
          KEYS = KEYS_BY[init];
          loaded[init] = 1;
        }
      }
    } catch (e) {}
  }
})(typeof window !== 'undefined' ? window : this);
