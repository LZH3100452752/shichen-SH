/* =====================================================================
   AutoRescue · 多语言 (i18n)
   设计: 以「界面中文原文」为 key, 查不到就原样返回。
        渲染完成后对文本节点做一次替换, 因此无需改动业务代码,
        遗漏的词条会自动回落到中文, 不会破坏界面。
   作者: 时尘  v2.7
   ===================================================================== */
(function (w) {
  'use strict';

  var LANGS = [
    ['zh-CN', '简体中文', '🇨🇳'],
    ['zh-TW', '繁體中文', '🇹🇼'],
    ['en', 'English', '🇺🇸'],
    ['ja', '日本語', '🇯🇵'],
    ['ko', '한국어', '🇰🇷'],
    ['ru', 'Русский', '🇷🇺'],
    ['fr', 'Français', '🇫🇷'],
    ['es', 'Español', '🇪🇸'],
    ['de', 'Deutsch', '🇩🇪'],
    ['vi', 'Tiếng Việt', '🇻🇳']
  ];

  /* ---------------- 通用 / 导航 / 状态 ---------------- */
  var CORE = {
    '时尘自动救砖守护': {
      'zh-TW': '時塵自動救磚守護', en: 'Shichen Auto Rescue Guard',
      ja: '時塵 自動復旧ガード', ko: '시진 자동 복구 가드',
      ru: 'Shichen · Автоспасение', fr: 'Shichen · Protection Anti-Brick',
      es: 'Shichen · Protección Anti-Brick', de: 'Shichen · Rettungsschutz',
      vi: 'Shichen · Bảo Vệ Chống Brick'
    },
    '自动救砖守护': {
      'zh-TW': '自動救磚守護', en: 'Auto Rescue Guard', ja: '自動復旧ガード',
      ko: '자동 복구 가드', ru: 'Автоспасение', fr: 'Protection Anti-Brick',
      es: 'Protección Anti-Brick', de: 'Rettungsschutz', vi: 'Bảo Vệ Chống Brick'
    },
    '总览': { 'zh-TW': '總覽', en: 'Overview', ja: '概要', ko: '개요', ru: 'Обзор', fr: 'Aperçu', es: 'Resumen', de: 'Übersicht', vi: 'Tổng quan' },
    '救援': { 'zh-TW': '救援', en: 'Rescue', ja: '復旧', ko: '복구', ru: 'Спасение', fr: 'Sauvetage', es: 'Rescate', de: 'Rettung', vi: 'Cứu hộ' },
    '模块': { 'zh-TW': '模組', en: 'Modules', ja: 'モジュール', ko: '모듈', ru: 'Модули', fr: 'Modules', es: 'Módulos', de: 'Module', vi: 'Mô-đun' },
    '检测': { 'zh-TW': '檢測', en: 'Scan', ja: 'スキャン', ko: '검사', ru: 'Проверка', fr: 'Analyse', es: 'Análisis', de: 'Prüfung', vi: 'Quét' },
    '防护': { 'zh-TW': '防護', en: 'Guard', ja: '保護', ko: '보호', ru: 'Защита', fr: 'Protection', es: 'Protección', de: 'Schutz', vi: 'Bảo vệ' },
    '设置': { 'zh-TW': '設定', en: 'Settings', ja: '設定', ko: '설정', ru: 'Настройки', fr: 'Paramètres', es: 'Ajustes', de: 'Einstellungen', vi: 'Cài đặt' },
    '工具': { 'zh-TW': '工具', en: 'Tools', ja: 'ツール', ko: '도구', ru: 'Инструменты', fr: 'Outils', es: 'Herramientas', de: 'Werkzeuge', vi: 'Công cụ' },
    '快照': { 'zh-TW': '快照', en: 'Snapshot', ja: 'スナップショット', ko: '스냅샷', ru: 'Снимок', fr: 'Instantané', es: 'Instantánea', de: 'Schnappschuss', vi: 'Ảnh chụp' },
    '冲突': { 'zh-TW': '衝突', en: 'Conflicts', ja: '競合', ko: '충돌', ru: 'Конфликты', fr: 'Conflits', es: 'Conflictos', de: 'Konflikte', vi: 'Xung đột' },
    '日志': { 'zh-TW': '日誌', en: 'Logs', ja: 'ログ', ko: '로그', ru: 'Логи', fr: 'Journaux', es: 'Registros', de: 'Protokolle', vi: 'Nhật ký' },
    '终端': { 'zh-TW': '終端', en: 'Terminal', ja: 'ターミナル', ko: '터미널', ru: 'Терминал', fr: 'Terminal', es: 'Terminal', de: 'Terminal', vi: 'Terminal' },
    '刷新': { 'zh-TW': '刷新', en: 'Refresh', ja: '更新', ko: '새로고침', ru: 'Обновить', fr: 'Actualiser', es: 'Actualizar', de: 'Aktualisieren', vi: 'Làm mới' },
    '关闭': { 'zh-TW': '關閉', en: 'Close', ja: '閉じる', ko: '닫기', ru: 'Закрыть', fr: 'Fermer', es: 'Cerrar', de: 'Schließen', vi: 'Đóng' },
    '取消': { 'zh-TW': '取消', en: 'Cancel', ja: 'キャンセル', ko: '취소', ru: 'Отмена', fr: 'Annuler', es: 'Cancelar', de: 'Abbrechen', vi: 'Hủy' },
    '确认': { 'zh-TW': '確認', en: 'Confirm', ja: '確認', ko: '확인', ru: 'Подтвердить', fr: 'Confirmer', es: 'Confirmar', de: 'Bestätigen', vi: 'Xác nhận' },
    '确认执行': { 'zh-TW': '確認執行', en: 'Confirm', ja: '実行する', ko: '실행 확인', ru: 'Выполнить', fr: 'Confirmer', es: 'Confirmar', de: 'Bestätigen', vi: 'Xác nhận' },
    '删除': { 'zh-TW': '刪除', en: 'Delete', ja: '削除', ko: '삭제', ru: 'Удалить', fr: 'Supprimer', es: 'Eliminar', de: 'Löschen', vi: 'Xóa' },
    '移除': { 'zh-TW': '移除', en: 'Remove', ja: '削除', ko: '제거', ru: 'Удалить', fr: 'Retirer', es: 'Quitar', de: 'Entfernen', vi: 'Gỡ bỏ' },
    '启用': { 'zh-TW': '啟用', en: 'Enable', ja: '有効化', ko: '활성화', ru: 'Включить', fr: 'Activer', es: 'Activar', de: 'Aktivieren', vi: 'Bật' },
    '禁用': { 'zh-TW': '停用', en: 'Disable', ja: '無効化', ko: '비활성화', ru: 'Отключить', fr: 'Désactiver', es: 'Desactivar', de: 'Deaktivieren', vi: 'Tắt' },
    '已启用': { 'zh-TW': '已啟用', en: 'Enabled', ja: '有効', ko: '활성화됨', ru: 'Включён', fr: 'Activé', es: 'Activado', de: 'Aktiviert', vi: 'Đã bật' },
    '已禁用': { 'zh-TW': '已停用', en: 'Disabled', ja: '無効', ko: '비활성화됨', ru: 'Отключён', fr: 'Désactivé', es: 'Desactivado', de: 'Deaktiviert', vi: 'Đã tắt' },
    '保存': { 'zh-TW': '儲存', en: 'Save', ja: '保存', ko: '저장', ru: 'Сохранить', fr: 'Enregistrer', es: 'Guardar', de: 'Speichern', vi: 'Lưu' },
    '完成': { 'zh-TW': '完成', en: 'Done', ja: '完了', ko: '완료', ru: 'Готово', fr: 'Terminé', es: 'Hecho', de: 'Fertig', vi: 'Hoàn tất' },
    '处理中': { 'zh-TW': '處理中', en: 'Processing', ja: '処理中', ko: '처리 중', ru: 'Выполняется', fr: 'En cours', es: 'Procesando', de: 'Wird verarbeitet', vi: 'Đang xử lý' },
    '加载中': { 'zh-TW': '載入中', en: 'Loading', ja: '読み込み中', ko: '불러오는 중', ru: 'Загрузка', fr: 'Chargement', es: 'Cargando', de: 'Lädt', vi: 'Đang tải' },
    '正常': { 'zh-TW': '正常', en: 'OK', ja: '正常', ko: '정상', ru: 'Норма', fr: 'Normal', es: 'Normal', de: 'Normal', vi: 'Bình thường' },
    '无': { 'zh-TW': '無', en: 'None', ja: 'なし', ko: '없음', ru: 'Нет', fr: 'Aucun', es: 'Ninguno', de: 'Keine', vi: 'Không có' },
    '全部': { 'zh-TW': '全部', en: 'All', ja: 'すべて', ko: '전체', ru: 'Все', fr: 'Tous', es: 'Todos', de: 'Alle', vi: 'Tất cả' },
    '白名单': { 'zh-TW': '白名單', en: 'Whitelist', ja: 'ホワイトリスト', ko: '화이트리스트', ru: 'Белый список', fr: 'Liste blanche', es: 'Lista blanca', de: 'Whitelist', vi: 'Danh sách trắng' },
    '锁定': { 'zh-TW': '鎖定', en: 'Lock', ja: 'ロック', ko: '잠금', ru: 'Блокировка', fr: 'Verrouiller', es: 'Bloquear', de: 'Sperren', vi: 'Khóa' },
    '备份': { 'zh-TW': '備份', en: 'Backup', ja: 'バックアップ', ko: '백업', ru: 'Резервная копия', fr: 'Sauvegarde', es: 'Copia', de: 'Sicherung', vi: 'Sao lưu' },
    '还原': { 'zh-TW': '還原', en: 'Restore', ja: '復元', ko: '복원', ru: 'Восстановить', fr: 'Restaurer', es: 'Restaurar', de: 'Wiederherstellen', vi: 'Khôi phục' },
    '详情': { 'zh-TW': '詳情', en: 'Details', ja: '詳細', ko: '세부정보', ru: 'Подробнее', fr: 'Détails', es: 'Detalles', de: 'Details', vi: 'Chi tiết' },
    '体检': { 'zh-TW': '體檢', en: 'Health Check', ja: '検査', ko: '검진', ru: 'Проверка', fr: 'Diagnostic', es: 'Chequeo', de: 'Check', vi: 'Kiểm tra' },
    '重启': { 'zh-TW': '重啟', en: 'Reboot', ja: '再起動', ko: '재부팅', ru: 'Перезагрузка', fr: 'Redémarrer', es: 'Reiniciar', de: 'Neustart', vi: 'Khởi động lại' },
    '守护运行中': { 'zh-TW': '守護運行中', en: 'Guard Active', ja: '保護動作中', ko: '보호 실행 중', ru: 'Защита активна', fr: 'Protection active', es: 'Protección activa', de: 'Schutz aktiv', vi: 'Bảo vệ đang chạy' },
    '健康度': { 'zh-TW': '健康度', en: 'Health', ja: '健全性', ko: '건강도', ru: 'Состояние', fr: 'État', es: 'Salud', de: 'Zustand', vi: 'Sức khỏe' },
    '安全模式已激活': { 'zh-TW': '安全模式已啟用', en: 'Safe Mode Active', ja: 'セーフモード有効', ko: '안전 모드 활성', ru: 'Безопасный режим', fr: 'Mode sans échec', es: 'Modo seguro activo', de: 'Abgesicherter Modus', vi: 'Chế độ an toàn' },
    '救援已介入': { 'zh-TW': '救援已介入', en: 'Rescue Engaged', ja: '復旧が介入', ko: '복구 개입', ru: 'Спасение запущено', fr: 'Sauvetage en cours', es: 'Rescate activo', de: 'Rettung aktiv', vi: 'Đã kích hoạt cứu hộ' }
  };
  w.__AR_I18N_CORE = CORE;
  w.__AR_I18N_LANGS = LANGS;

  /* ---------------- 卡片标题 / 页面内容 / 云更新 ---------------- */
  var PAGES = {
    '设备信息': { 'zh-TW': '設備資訊', en: 'Device Info', ja: 'デバイス情報', ko: '기기 정보', ru: 'Устройство', fr: 'Appareil', es: 'Dispositivo', de: 'Gerät', vi: 'Thiết bị' },
    '模块概览': { 'zh-TW': '模組概覽', en: 'Modules Overview', ja: 'モジュール概要', ko: '모듈 개요', ru: 'Модули', fr: 'Modules', es: 'Módulos', de: 'Module', vi: 'Tổng quan mô-đun' },
    '通道信息': { 'zh-TW': '通道資訊', en: 'Channel', ja: 'チャネル情報', ko: '채널 정보', ru: 'Канал', fr: 'Canal', es: 'Canal', de: 'Kanal', vi: 'Kênh' },
    '救援状态': { 'zh-TW': '救援狀態', en: 'Rescue Status', ja: '復旧ステータス', ko: '복구 상태', ru: 'Статус спасения', fr: 'État du sauvetage', es: 'Estado de rescate', de: 'Rettungsstatus', vi: 'Trạng thái cứu hộ' },
    '启动计数': { 'zh-TW': '啟動計數', en: 'Boot Count', ja: '起動回数', ko: '부팅 횟수', ru: 'Счётчик загрузок', fr: 'Compteur de démarrage', es: 'Contador de arranque', de: 'Boot-Zähler', vi: 'Số lần khởi động' },
    '救援等级进度': { 'zh-TW': '救援等級進度', en: 'Rescue Level', ja: '復旧レベル', ko: '복구 단계', ru: 'Уровень спасения', fr: 'Niveau de sauvetage', es: 'Nivel de rescate', de: 'Rettungsstufe', vi: 'Cấp độ cứu hộ' },
    '上次救援': { 'zh-TW': '上次救援', en: 'Last Rescue', ja: '前回の復旧', ko: '마지막 복구', ru: 'Последнее спасение', fr: 'Dernier sauvetage', es: 'Último rescate', de: 'Letzte Rettung', vi: 'Cứu hộ gần nhất' },
    '救援原因': { 'zh-TW': '救援原因', en: 'Reason', ja: '理由', ko: '원인', ru: 'Причина', fr: 'Raison', es: 'Motivo', de: 'Grund', vi: 'Nguyên nhân' },
    '上次稳定': { 'zh-TW': '上次穩定', en: 'Last Stable', ja: '前回の安定', ko: '마지막 정상', ru: 'Последняя стабильность', fr: 'Dernière stabilité', es: 'Última estable', de: 'Zuletzt stabil', vi: 'Lần ổn định cuối' },
    '确认已稳定': { 'zh-TW': '確認已穩定', en: 'Mark as Stable', ja: '安定を確認', ko: '정상 확인', ru: 'Всё стабильно', fr: 'Marquer comme stable', es: 'Marcar estable', de: 'Als stabil markieren', vi: 'Đánh dấu ổn định' },
    '救援中心': { 'zh-TW': '救援中心', en: 'Rescue Center', ja: '復旧センター', ko: '복구 센터', ru: 'Центр спасения', fr: 'Centre de sauvetage', es: 'Centro de rescate', de: 'Rettungszentrale', vi: 'Trung tâm cứu hộ' },
    '模块总数': { 'zh-TW': '模組總數', en: 'Total Modules', ja: 'モジュール総数', ko: '전체 모듈', ru: 'Всего модулей', fr: 'Total modules', es: 'Total módulos', de: 'Module gesamt', vi: 'Tổng mô-đun' },
    '可用快照': { 'zh-TW': '可用快照', en: 'Snapshots', ja: 'スナップショット数', ko: '사용 가능 스냅샷', ru: 'Снимки', fr: 'Instantanés', es: 'Instantáneas', de: 'Schnappschüsse', vi: 'Ảnh chụp' },
    '累计救援': { 'zh-TW': '累計救援', en: 'Total Rescues', ja: '復旧回数', ko: '누적 복구', ru: 'Всего спасений', fr: 'Sauvetages', es: 'Rescates totales', de: 'Rettungen', vi: 'Tổng cứu hộ' },
    '云更新': { 'zh-TW': '雲端更新', en: 'Cloud Update', ja: 'クラウド更新', ko: '클라우드 업데이트', ru: 'Обновление', fr: 'Mise à jour', es: 'Actualización', de: 'Update', vi: 'Cập nhật' },
    '当前版本': { 'zh-TW': '目前版本', en: 'Current', ja: '現在のバージョン', ko: '현재 버전', ru: 'Текущая', fr: 'Actuelle', es: 'Actual', de: 'Aktuell', vi: 'Hiện tại' },
    '云端版本': { 'zh-TW': '雲端版本', en: 'Latest', ja: '最新バージョン', ko: '최신 버전', ru: 'Последняя', fr: 'Disponible', es: 'Disponible', de: 'Verfügbar', vi: 'Mới nhất' },
    '检测更新': { 'zh-TW': '檢查更新', en: 'Check Update', ja: '更新を確認', ko: '업데이트 확인', ru: 'Проверить', fr: 'Vérifier', es: 'Buscar', de: 'Prüfen', vi: 'Kiểm tra' },
    '立即更新': { 'zh-TW': '立即更新', en: 'Update Now', ja: '今すぐ更新', ko: '지금 업데이트', ru: 'Обновить', fr: 'Mettre à jour', es: 'Actualizar', de: 'Aktualisieren', vi: 'Cập nhật ngay' },
    '测试更新源': { 'zh-TW': '測試更新源', en: 'Test Sources', ja: 'ソースをテスト', ko: '소스 테스트', ru: 'Проверить источники', fr: 'Tester les sources', es: 'Probar fuentes', de: 'Quellen testen', vi: 'Kiểm tra nguồn' },
    '已是最新版本': { 'zh-TW': '已是最新版本', en: 'Up to Date', ja: '最新です', ko: '최신 버전', ru: 'Актуально', fr: 'À jour', es: 'Al día', de: 'Aktuell', vi: 'Đã mới nhất' },
    '发现新版本': { 'zh-TW': '發現新版本', en: 'New Version', ja: '新しいバージョン', ko: '새 버전 발견', ru: 'Новая версия', fr: 'Nouvelle version', es: 'Nueva versión', de: 'Neue Version', vi: 'Có bản mới' },
    '无需更新': { 'zh-TW': '無需更新', en: 'No Update Needed', ja: '更新不要', ko: '업데이트 불필요', ru: 'Обновление не нужно', fr: 'Aucune mise à jour', es: 'Sin actualización', de: 'Kein Update', vi: 'Không cần cập nhật' },
    '强制更新': { 'zh-TW': '強制更新', en: 'Forced Update', ja: '強制更新', ko: '강제 업데이트', ru: 'Принудительно', fr: 'Mise à jour forcée', es: 'Actualización forzada', de: 'Erzwungen', vi: 'Cập nhật bắt buộc' },
    '更新内容': { 'zh-TW': '更新內容', en: 'Changelog', ja: '更新内容', ko: '변경 사항', ru: 'Изменения', fr: 'Notes', es: 'Novedades', de: 'Änderungen', vi: 'Nội dung' },
    '版本号': { 'zh-TW': '版本號', en: 'Version Code', ja: 'バージョン番号', ko: '버전 번호', ru: 'Номер версии', fr: 'Numéro', es: 'Número', de: 'Versionsnummer', vi: 'Số phiên bản' },
    '下载工具': { 'zh-TW': '下載工具', en: 'Downloader', ja: 'ダウンロード手段', ko: '다운로드 도구', ru: 'Загрузчик', fr: 'Outil', es: 'Herramienta', de: 'Downloader', vi: 'Công cụ tải' },
    '连接失败': { 'zh-TW': '連線失敗', en: 'Failed', ja: '接続失敗', ko: '연결 실패', ru: 'Ошибка', fr: 'Échec', es: 'Fallido', de: 'Fehlgeschlagen', vi: 'Thất bại' },
    '内容异常': { 'zh-TW': '內容異常', en: 'Bad Content', ja: '内容異常', ko: '내용 오류', ru: 'Некорректно', fr: 'Contenu invalide', es: 'Contenido inválido', de: 'Ungültig', vi: 'Nội dung lỗi' },
    '模块备份': { 'zh-TW': '模組備份', en: 'Module Backup', ja: 'モジュールバックアップ', ko: '모듈 백업', ru: 'Резервная копия', fr: 'Sauvegarde', es: 'Copia de seguridad', de: 'Sicherung', vi: 'Sao lưu mô-đun' },
    '重启控制': { 'zh-TW': '重啟控制', en: 'Reboot', ja: '再起動', ko: '재부팅 제어', ru: 'Перезагрузка', fr: 'Redémarrage', es: 'Reinicio', de: 'Neustart', vi: 'Khởi động lại' },
    '诊断与维护': { 'zh-TW': '診斷與維護', en: 'Diagnostics', ja: '診断とメンテ', ko: '진단 및 유지보수', ru: 'Диагностика', fr: 'Diagnostic', es: 'Diagnóstico', de: 'Diagnose', vi: 'Chẩn đoán' },
    '问题反馈': { 'zh-TW': '問題回饋', en: 'Feedback', ja: 'フィードバック', ko: '문의하기', ru: 'Обратная связь', fr: 'Retour', es: 'Comentarios', de: 'Feedback', vi: 'Phản hồi' },
    '一键复制': { 'zh-TW': '一鍵複製', en: 'Copy', ja: 'コピー', ko: '복사', ru: 'Копировать', fr: 'Copier', es: 'Copiar', de: 'Kopieren', vi: 'Sao chép' },
    '导出诊断包': { 'zh-TW': '匯出診斷包', en: 'Export Diagnostics', ja: '診断を書き出し', ko: '진단 내보내기', ru: 'Экспорт', fr: 'Exporter', es: 'Exportar', de: 'Exportieren', vi: 'Xuất chẩn đoán' },
    '生成诊断报告': { 'zh-TW': '產生診斷報告', en: 'Generate Report', ja: 'レポート作成', ko: '보고서 생성', ru: 'Создать отчёт', fr: 'Générer', es: 'Generar', de: 'Bericht', vi: 'Tạo báo cáo' },
    '软件重启': { 'zh-TW': '軟體重啟', en: 'Soft Reboot', ja: 'ソフト再起動', ko: '소프트 재부팅', ru: 'Мягкая перезагрузка', fr: 'Redémarrage logiciel', es: 'Reinicio suave', de: 'Soft-Reboot', vi: 'Khởi động mềm' },
    'Recovery': { en: 'Recovery', ja: 'Recovery', ko: 'Recovery', ru: 'Recovery', fr: 'Recovery', es: 'Recovery', de: 'Recovery', vi: 'Recovery' },
    '紧急救援': { 'zh-TW': '緊急救援', en: 'Emergency Rescue', ja: '緊急復旧', ko: '긴급 복구', ru: 'Экстренное спасение', fr: 'Sauvetage urgent', es: 'Rescate urgente', de: 'Notrettung', vi: 'Cứu hộ khẩn cấp' },
    '恢复全部模块': { 'zh-TW': '恢復全部模組', en: 'Restore All', ja: '全て復元', ko: '전체 복원', ru: 'Восстановить все', fr: 'Tout restaurer', es: 'Restaurar todo', de: 'Alle wiederherstellen', vi: 'Khôi phục tất cả' },
    '创建快照': { 'zh-TW': '建立快照', en: 'Create Snapshot', ja: 'スナップショット作成', ko: '스냅샷 생성', ru: 'Создать снимок', fr: 'Créer', es: 'Crear', de: 'Erstellen', vi: 'Tạo ảnh chụp' },
    '救援演练': { 'zh-TW': '救援演練', en: 'Rescue Simulation', ja: '復旧シミュレーション', ko: '복구 시뮬레이션', ru: 'Симуляция', fr: 'Simulation', es: 'Simulación', de: 'Simulation', vi: 'Mô phỏng' },
    '系统健康检查': { 'zh-TW': '系統健康檢查', en: 'System Health', ja: 'システム診断', ko: '시스템 점검', ru: 'Проверка системы', fr: 'Santé système', es: 'Salud del sistema', de: 'Systemprüfung', vi: 'Kiểm tra hệ thống' },
    '守护目录': { 'zh-TW': '守護目錄', en: 'Guarded Paths', ja: '保護ディレクトリ', ko: '보호 디렉터리', ru: 'Защищённые пути', fr: 'Chemins protégés', es: 'Rutas protegidas', de: 'Geschützte Pfade', vi: 'Thư mục bảo vệ' },
    '添加': { 'zh-TW': '新增', en: 'Add', ja: '追加', ko: '추가', ru: 'Добавить', fr: 'Ajouter', es: 'Añadir', de: 'Hinzufügen', vi: 'Thêm' },
    '巡检': { 'zh-TW': '巡檢', en: 'Inspect', ja: '検査', ko: '점검', ru: 'Проверить', fr: 'Inspecter', es: 'Inspeccionar', de: 'Prüfen', vi: 'Kiểm tra' },
    '告警记录': { 'zh-TW': '告警記錄', en: 'Alerts', ja: 'アラート', ko: '경고 기록', ru: 'Оповещения', fr: 'Alertes', es: 'Alertas', de: 'Warnungen', vi: 'Cảnh báo' },
    '重置启动计数': { 'zh-TW': '重置啟動計數', en: 'Reset Counter', ja: 'カウントをリセット', ko: '카운터 초기화', ru: 'Сбросить счётчик', fr: 'Réinitialiser', es: 'Reiniciar contador', de: 'Zähler zurücksetzen', vi: 'Đặt lại' },
    '一键清理': { 'zh-TW': '一鍵清理', en: 'Cleanup', ja: 'クリーンアップ', ko: '정리', ru: 'Очистить', fr: 'Nettoyer', es: 'Limpiar', de: 'Aufräumen', vi: 'Dọn dẹp' },
    '清空救援历史': { 'zh-TW': '清空救援歷史', en: 'Clear History', ja: '履歴を削除', ko: '기록 삭제', ru: 'Очистить историю', fr: 'Effacer', es: 'Borrar historial', de: 'Verlauf löschen', vi: 'Xóa lịch sử' },
    '空闲': { 'zh-TW': '空閒', en: 'Idle', ja: 'アイドル', ko: '유휴', ru: 'Ожидание', fr: 'Inactif', es: 'Inactivo', de: 'Leerlauf', vi: 'Rảnh' },
    '高危': { 'zh-TW': '高風險', en: 'Critical', ja: '危険', ko: '위험', ru: 'Опасно', fr: 'Critique', es: 'Crítico', de: 'Kritisch', vi: 'Nguy hiểm' },
    '可疑': { 'zh-TW': '可疑', en: 'Suspicious', ja: '疑わしい', ko: '의심', ru: 'Подозрительно', fr: 'Suspect', es: 'Sospechoso', de: 'Verdächtig', vi: 'Nghi ngờ' },
    '安全': { 'zh-TW': '安全', en: 'Safe', ja: '安全', ko: '안전', ru: 'Безопасно', fr: 'Sûr', es: 'Seguro', de: 'Sicher', vi: 'An toàn' },
    '风险得分': { 'zh-TW': '風險得分', en: 'Risk Score', ja: 'リスクスコア', ko: '위험 점수', ru: 'Оценка риска', fr: 'Score', es: 'Puntuación', de: 'Risikowert', vi: 'Điểm rủi ro' },
    '开始扫描': { 'zh-TW': '開始掃描', en: 'Start Scan', ja: 'スキャン開始', ko: '스캔 시작', ru: 'Сканировать', fr: 'Analyser', es: 'Analizar', de: 'Scannen', vi: 'Bắt đầu quét' },
    '按模块': { 'zh-TW': '按模組', en: 'By Module', ja: 'モジュール別', ko: '모듈별', ru: 'По модулю', fr: 'Par module', es: 'Por módulo', de: 'Nach Modul', vi: 'Theo mô-đun' },
    '按路径': { 'zh-TW': '按路徑', en: 'By Path', ja: 'パス指定', ko: '경로별', ru: 'По пути', fr: 'Par chemin', es: 'Por ruta', de: 'Nach Pfad', vi: 'Theo đường dẫn' },
    '粘贴代码': { 'zh-TW': '貼上程式碼', en: 'Paste Code', ja: 'コード貼付', ko: '코드 붙여넣기', ru: 'Вставить код', fr: 'Coller', es: 'Pegar', de: 'Code einfügen', vi: 'Dán mã' },
    '界面语言': { 'zh-TW': '介面語言', en: 'Language', ja: '言語', ko: '언어', ru: 'Язык', fr: 'Langue', es: 'Idioma', de: 'Sprache', vi: 'Ngôn ngữ' }
  };
  w.__AR_I18N_PAGES = PAGES;


  /* ---------------- 设置项名称 / 常用短语 ---------------- */
  var SETS = {
    '自动救援总开关': { 'zh-TW': '自動救援總開關', en: 'Auto Rescue', ja: '自動復旧', ko: '자동 복구', ru: 'Автоспасение', fr: 'Sauvetage auto', es: 'Rescate auto', de: 'Auto-Rettung', vi: 'Tự động cứu hộ' },
    '启动失败阈值': { 'zh-TW': '啟動失敗閾值', en: 'Boot Threshold', ja: '起動失敗の閾値', ko: '부팅 실패 임계값', ru: 'Порог загрузок', fr: 'Seuil', es: 'Umbral', de: 'Schwelle', vi: 'Ngưỡng' },
    '进桌面后确认延时': { 'zh-TW': '進入桌面後確認延遲', en: 'Confirm Delay', ja: '確認待機時間', ko: '확인 지연', ru: 'Задержка', fr: 'Délai', es: 'Retardo', de: 'Verzögerung', vi: 'Độ trễ' },
    '开机超时判定': { 'zh-TW': '開機超時判定', en: 'Boot Timeout', ja: '起動タイムアウト', ko: '부팅 타임아웃', ru: 'Таймаут', fr: 'Délai démarrage', es: 'Tiempo espera', de: 'Zeitlimit', vi: 'Hết giờ' },
    '最大救援等级': { 'zh-TW': '最大救援等級', en: 'Max Level', ja: '最大レベル', ko: '최대 단계', ru: 'Макс. уровень', fr: 'Niveau max', es: 'Nivel máx', de: 'Max. Stufe', vi: 'Cấp tối đa' },
    '保护守护自身': { 'zh-TW': '保護守護自身', en: 'Protect Self', ja: '自身を保護', ko: '자기 보호', ru: 'Защита себя', fr: 'Auto-protection', es: 'Autoprotección', de: 'Selbstschutz', vi: 'Tự bảo vệ' },
    '救援前自动快照': { 'zh-TW': '救援前自動快照', en: 'Auto Snapshot', ja: '自動スナップショット', ko: '자동 스냅샷', ru: 'Автоснимок', fr: 'Instantané auto', es: 'Instantánea auto', de: 'Auto-Schnappschuss', vi: 'Tự động chụp' },
    '后台守护进程': { 'zh-TW': '背景守護行程', en: 'Watchdog', ja: '監視プロセス', ko: '워치독', ru: 'Сторож', fr: 'Surveillance', es: 'Vigilante', de: 'Watchdog', vi: 'Tiến trình' },
    '重要目录守护': { 'zh-TW': '重要目錄守護', en: 'Path Guard', ja: 'ディレクトリ保護', ko: '디렉터리 보호', ru: 'Защита путей', fr: 'Protection chemins', es: 'Protección rutas', de: 'Pfadschutz', vi: 'Bảo vệ thư mục' },
    '目录守护巡检间隔': { 'zh-TW': '目錄守護巡檢間隔', en: 'Guard Interval', ja: '保護の間隔', ko: '보호 주기', ru: 'Интервал', fr: 'Intervalle', es: 'Intervalo', de: 'Intervall', vi: 'Khoảng thời gian' },
    '危险进程扫描': { 'zh-TW': '危險行程掃描', en: 'Process Scan', ja: 'プロセススキャン', ko: '프로세스 검사', ru: 'Скан процессов', fr: 'Analyse processus', es: 'Análisis procesos', de: 'Prozessprüfung', vi: 'Quét tiến trình' },
    '新装模块自动体检': { 'zh-TW': '新裝模組自動體檢', en: 'Auto Scan New', ja: '新規を自動検査', ko: '신규 자동 검사', ru: 'Автопроверка', fr: 'Analyse auto', es: 'Análisis auto', de: 'Auto-Prüfung', vi: 'Tự kiểm tra' },
    '高危模块自动隔离': { 'zh-TW': '高危模組自動隔離', en: 'Auto Quarantine', ja: '自動隔離', ko: '자동 격리', ru: 'Автокарантин', fr: 'Quarantaine auto', es: 'Cuarentena auto', de: 'Auto-Quarantäne', vi: 'Cách ly tự động' },
    '危险判定分数线': { 'zh-TW': '危險判定分數線', en: 'Risk Threshold', ja: '危険スコア閾値', ko: '위험 임계값', ru: 'Порог риска', fr: 'Seuil risque', es: 'Umbral riesgo', de: 'Risikoschwelle', vi: 'Ngưỡng rủi ro' },
    '允许使用命令行': { 'zh-TW': '允許使用命令列', en: 'Allow Terminal', ja: 'ターミナル許可', ko: '터미널 허용', ru: 'Терминал', fr: 'Terminal', es: 'Terminal', de: 'Terminal', vi: 'Cho phép terminal' },
    '日志保留天数': { 'zh-TW': '日誌保留天數', en: 'Log Retention', ja: 'ログ保持日数', ko: '로그 보관', ru: 'Хранение логов', fr: 'Rétention', es: 'Retención', de: 'Aufbewahrung', vi: 'Lưu log' },
    '救援前二次确认': { 'zh-TW': '救援前二次確認', en: 'Confirm Rescue', ja: '復旧の確認', ko: '복구 확인', ru: 'Подтверждение', fr: 'Confirmation', es: 'Confirmación', de: 'Bestätigung', vi: 'Xác nhận' },
    '启动页': { 'zh-TW': '啟動頁', en: 'Splash', ja: 'スプラッシュ', ko: '스플래시', ru: 'Заставка', fr: 'Écran démarrage', es: 'Pantalla inicio', de: 'Startbildschirm', vi: 'Màn hình chờ' },
    '界面动效': { 'zh-TW': '介面動效', en: 'Animations', ja: 'アニメーション', ko: '애니메ーション', ru: 'Анимации', fr: 'Animations', es: 'Animaciones', de: 'Animationen', vi: 'Hiệu ứng' },
    '金属配色': { 'zh-TW': '金屬配色', en: 'Metal Theme', ja: 'メタルテーマ', ko: '메탈 테마', ru: 'Металл', fr: 'Thème métal', es: 'Tema metálico', de: 'Metall-Design', vi: 'Giao diện kim loại' },
    '紧凑模式': { 'zh-TW': '緊湊模式', en: 'Compact', ja: 'コンパクト', ko: '압축 모드', ru: 'Компактный', fr: 'Compact', es: 'Compacto', de: 'Kompakt', vi: 'Gọn' },
    '功能设置': { 'zh-TW': '功能設定', en: 'Settings', ja: '機能設定', ko: '기능 설정', ru: 'Настройки', fr: 'Paramètres', es: 'Ajustes', de: 'Einstellungen', vi: 'Cài đặt' },
    '基础救援': { 'zh-TW': '基礎救援', en: 'Basic Rescue', ja: '基本復旧', ko: '기본 복구', ru: 'Основное', fr: 'Base', es: 'Básico', de: 'Basis', vi: 'Cơ bản' },
    '进阶防护': { 'zh-TW': '進階防護', en: 'Advanced', ja: '高度な保護', ko: '고급 보호', ru: 'Дополнительно', fr: 'Avancé', es: 'Avanzado', de: 'Erweitert', vi: 'Nâng cao' },
    '界面外观': { 'zh-TW': '介面外觀', en: 'Appearance', ja: '外観', ko: '외관', ru: 'Вид', fr: 'Apparence', es: 'Apariencia', de: 'Aussehen', vi: 'Giao diện' },
    '守护策略': { 'zh-TW': '守護策略', en: 'Guard Policy', ja: '保護ポリシー', ko: '보호 정책', ru: 'Политика', fr: 'Politique', es: 'Política', de: 'Richtlinie', vi: 'Chính sách' },
    '设置已自动保存': { 'zh-TW': '設定已自動儲存', en: 'Settings Saved', ja: '保存しました', ko: '저장됨', ru: 'Сохранено', fr: 'Enregistré', es: 'Guardado', de: 'Gespeichert', vi: 'Đã lưu' },
    '保存失败': { 'zh-TW': '儲存失敗', en: 'Save Failed', ja: '保存失敗', ko: '저장 실패', ru: 'Ошибка', fr: 'Échec', es: 'Error', de: 'Fehler', vi: 'Lỗi' },
    '正在连接模块': { 'zh-TW': '正在連接模組', en: 'Connecting', ja: '接続中', ko: '연결 중', ru: 'Подключение', fr: 'Connexion', es: 'Conectando', de: 'Verbinden', vi: 'Đang kết nối' },
    '正在下载更新': { 'zh-TW': '正在下載更新', en: 'Downloading', ja: 'ダウンロード中', ko: '다운로드 중', ru: 'Загрузка', fr: 'Téléchargement', es: 'Descargando', de: 'Lädt', vi: 'Đang tải' },
    '正在安装更新': { 'zh-TW': '正在安裝更新', en: 'Installing', ja: 'インストール中', ko: '설치 중', ru: 'Установка', fr: 'Installation', es: 'Instalando', de: 'Installiert', vi: 'Đang cài' },
    '更新完成': { 'zh-TW': '更新完成', en: 'Update Complete', ja: '更新完了', ko: '업데이트 완료', ru: 'Обновлено', fr: 'Terminé', es: 'Completado', de: 'Fertig', vi: 'Hoàn tất' },
    '稍后重启': { 'zh-TW': '稍後重啟', en: 'Reboot Later', ja: '後で再起動', ko: '나중에 재부팅', ru: 'Позже', fr: 'Plus tard', es: 'Más tarde', de: 'Später', vi: 'Để sau' },
    '立即重启': { 'zh-TW': '立即重啟', en: 'Reboot Now', ja: '今すぐ再起動', ko: '지금 재부팅', ru: 'Перезагрузить', fr: 'Redémarrer', es: 'Reiniciar', de: 'Neu starten', vi: 'Khởi động lại' },
    '稍后再说': { 'zh-TW': '稍後再說', en: 'Later', ja: '後で', ko: '나중에', ru: 'Позже', fr: 'Plus tard', es: 'Más tarde', de: 'Später', vi: 'Để sau' },
    '更新失败': { 'zh-TW': '更新失敗', en: 'Update Failed', ja: '更新失敗', ko: '업데이트 실패', ru: 'Ошибка', fr: 'Échec', es: 'Falló', de: 'Fehlgeschlagen', vi: 'Thất bại' },
    '已是最新': { 'zh-TW': '已是最新', en: 'Up to Date', ja: '最新', ko: '최신', ru: 'Актуально', fr: 'À jour', es: 'Al día', de: 'Aktuell', vi: 'Mới nhất' },
    '此操作会立即修改设备状态, 建议先创建快照。': { 'zh-TW': '此操作會立即修改設備狀態, 建議先建立快照。', en: 'This changes device state immediately. Snapshot recommended.', ja: 'デバイスの状態を即座に変更します。スナップショット推奨。', ko: '기기 상태가 즉시 변경됩니다. 스냅샷 권장.', ru: 'Изменит состояние устройства. Рекомендуется снимок.', fr: 'Modifie l’appareil immédiatement. Instantané conseillé.', es: 'Cambia el estado del dispositivo. Se recomienda instantánea.', de: 'Ändert Gerätestatus sofort. Schnappschuss empfohlen.', vi: 'Thay đổi ngay trạng thái. Nên tạo ảnh chụp.' },
    '此操作会立即修改设备状态': { 'zh-TW': '此操作會立即修改設備狀態', en: 'Changes device state', ja: '状態を即座に変更', ko: '기기 상태 변경', ru: 'Изменит состояние', fr: 'Modifie l’appareil', es: 'Cambia el estado', de: 'Ändert Status', vi: 'Thay đổi trạng thái' }
  };
  w.__AR_I18N_SETS = SETS;

  /* ---------------- 引擎 ---------------- */
  var DICT = {};       // lang -> { 中文原文: 译文 }
  var KEYS = [];       // 按长度降序, 长句优先匹配

  function buildDict() {
    var all = [CORE, PAGES, SETS], i, j, k, lang, e, d;
    for (i = 0; i < LANGS.length; i++) {
      lang = LANGS[i][0];
      if (lang === 'zh-CN') continue;
      d = {};
      for (j = 0; j < all.length; j++) {
        e = all[j];
        for (k in e) {
          if (!Object.prototype.hasOwnProperty.call(e, k)) continue;
          if (e[k] && e[k][lang]) d[k] = e[k][lang];
        }
      }
      DICT[lang] = d;
    }
    // 词条按长度降序, 保证长句优先于短词被替换
    var seen = {};
    for (i = 0; i < all.length; i++) {
      for (k in all[i]) {
        if (!Object.prototype.hasOwnProperty.call(all[i], k)) continue;
        if (!seen[k]) { seen[k] = 1; KEYS.push(k); }
      }
    }
    KEYS.sort(function (a, b) { return b.length - a.length; });
  }

  var CUR = 'zh-CN';
  var LS_KEY = 'ar_lang';

  function load() {
    try {
      var v = w.localStorage && w.localStorage.getItem(LS_KEY);
      if (v) { for (var i = 0; i < LANGS.length; i++) if (LANGS[i][0] === v) { CUR = v; return CUR; } }
    } catch (e) {}
    CUR = 'zh-CN';
    return CUR;
  }
  function save(v) {
    CUR = v;
    try { w.localStorage && w.localStorage.setItem(LS_KEY, v); } catch (e) {}
  }
  function current() { return CUR; }
  function isZh() { return CUR === 'zh-CN'; }

  // 翻译单条文本(长句优先, 再退化为逐词替换)
  function tr(text) {
    if (!text || CUR === 'zh-CN') return text;
    var d = DICT[CUR];
    if (!d) return text;
    var out = text, i, k, v;
    for (i = 0; i < KEYS.length; i++) {
      k = KEYS[i];
      v = d[k];
      if (!v) continue;
      if (out.indexOf(k) < 0) continue;
      out = out.split(k).join(v);
    }
    return out;
  }

  /* 渲染后遍历文本节点做替换。
     只处理纯文本节点, 不动属性与脚本, 因此不会破坏界面。 */
  function apply(root) {
    if (CUR === 'zh-CN') return;
    var host = root || w.document;
    if (!host) return;
    var walker, node, txt, nt;
    try {
      walker = w.document.createTreeWalker(
        typeof host.getElementById === 'function' ? host.body || host : host,
        0x4 /* SHOW_TEXT */, null, false);
    } catch (e) { return; }
    var SKIP = { SCRIPT: 1, STYLE: 1, TEXTAREA: 1, CODE: 1, PRE: 1 };
    while ((node = walker.nextNode())) {
      if (SKIP[node.parentNode && node.parentNode.nodeName]) continue;
      txt = node.nodeValue;
      if (!txt || txt.indexOf('\u4e00') < 0 && txt.indexOf('\u4e2d') < 0) {
        // 无中日韩字符则跳过(提升性能); 中文 key 一定含这类字符
        if (!txt || !/[\u4e00-\u9fff]/.test(txt)) continue;
      }
      nt = tr(txt);
      if (nt !== txt) node.nodeValue = nt;
    }
  }

  buildDict();
  load();

  w.ARI18N = {
    LANGS: LANGS,
    list: function () { return LANGS; },
    get: current,
    set: save,
    tr: tr,
    apply: apply,
    isZh: isZh
  };

})(typeof window !== 'undefined' ? window : this);
